VARIANT B -- DLL PATCH  (Medicine contents)
===========================================

WHAT IS IN THIS FOLDER
  HardLockWrapper.dll   2,052,096 B  the VENDOR dll with one method patched
  patch_hardlock.py        4,797 B   the patcher (re-derive/re-apply the patch)
  il_check.py              3,279 B   independent IL verifier
  hardlock.ini             1,287 B   optional configuration

THE PATCH
  File    : bin\HardLockWrapper.dll   (mixed-mode C++/CLI, assembly 0.0.0.0)
  Method  : LVSIMWebCs.HardLockWrapper::check()
  Body at : file offset 0x10E1A4, 12 bytes, fat header 0x3003 at 0x10E198

    BEFORE  02 7b a4 02 00 04 28 63 00 00 06 2a
            ldarg.0 ; ldfld hardLock ; call HardLockSystem.Check ; ret
    AFTER   16 2a 00 00 00 00 00 00 00 00 00 00
            ldc.i4.0 ; ret ; nop x10

  Result  : check() returns the constant 0 == HASP_STATUS_OK == licensed.

WHY A RAW BYTE PATCH AND NOT Mono.Cecil
  HardLockWrapper.dll is mixed-mode. Cecil reads it fine but refuses to write:
      "Writing mixed-mode assemblies is not supported"
  The body is 12 bytes inside an RVA blob, so an in-place edit is exact and the
  file length does not change. Nothing else in the image is modified.

BLAST RADIUS -- measured
  bytes changed : 9 of 2,052,096
  file size     : unchanged (2,052,096)
  the ldfld and call tokens remain in the image but are no longer executed

  Not touched: LVSIMWebCs.dll, CalculsWrapper.dll, LVSimEmsCalc.dll, any page,
  Web.config, IIS, the registry.

CHECKSUMS
  vendor  (original)  0d81881100044727a1ba821aef9940c7520b48d6cbc9246943b48b5f0916e54f
  patched (this file) e07fef6ac8d56e4370231a48ddfda9acf237c142ca7d0b1ad947988a34d3f982

VERIFIED
  * patcher asserts the original bytes and token types before writing (no blind write)
  * independent verifier decodes the patched body back to ldc.i4.0 / ret
  * Cecil re-reads the patched image and reports the expected instructions
  * pefile parses the patched image; section table intact

CAVEAT
  The vendor DLL is mixed-mode, and Mono/Linux cannot execute mixed-mode IJW code
  (the ORIGINAL vendor dll crashes there identically), so the patch is proven at
  IL-equivalence level rather than by running the method on Windows. On Windows
  the CLR executes a 2-byte ldc.i4.0;ret body trivially.

REAPPLY AFTER AN UPDATE
  python3 patch_hardlock.py "<new vendor dll>" out.dll
  The patcher refuses if the bytes are not what it expects, so an updated vendor
  build cannot be silently mis-patched.
