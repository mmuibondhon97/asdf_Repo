VARIANT A -- DONGLE EMULATOR  (Medicine contents)
=================================================

WHAT IS IN THIS FOLDER
  HardLockWrapper.dll   5,120 B   managed front-end; forwards licence decisions
                                  to the emulator through the HASP API
  hasp_windows.dll     86,591 B   the software dongle emulator (i386 DLL, 11 exports)
  hasp_emu.c.txt                  full emulator source (rebuild without this kit)
  hasp_emu_portable.c.txt         same logic, portable C (used for the ABI proof)
  hardlock.ini                    optional configuration

WHAT "EMULATOR" MEANS HERE -- and why it is not a drop-in hasp_windows.dll
--------------------------------------------------------------------------
This was measured, not assumed. The vendor HardLockWrapper.dll is a mixed-mode
C++/CLI image that:
  * has NO PE export directory at all, and
  * declares its HASP calls as  pinvokeimpl( /* No map */ )
so the HASP runtime is linked INTO it and resolved internally. Nothing on disk
named hasp_windows.dll is ever loaded by the vendor binary.

The emulator is therefore reached through a licensing assembly that names it --
HardLockWrapper.dll in this folder. That assembly is the only replaced file, so
the app's own code (LVSIMWebCs.dll, the math engine, every page, Web.config,
IIS) is untouched.

THE EMULATOR ABI (11 exports, stdcall, i386)
  hasp_login(vendor, &feature, &handle)   -> 0 on success; accepts 0x133 and legacy 0x12C
  hasp_logout(handle)                     -> 0
  hasp_get_sessioninfo(handle, fmt, &out)-> 0, returns HASP-HL XML
  hasp_get_info(fmt, &out)                -> 0
  hasp_free(ptr)                          -> 0
  hasp_get_size(handle, &size)            -> 0
  hasp_get_rtc(handle, &rtc)              -> 0
  HL_AVAIL()                              -> 0
  HL_LOGIN(vendor, &feature)              -> 0
  HL_LOGOUT()                             -> 0
  HL_SELECT(vendor)                       -> 0

The HL_* family is NOT optional: HardLockSystem.Login() falls back to
HL_UniversalLogin() when HASP_Login() fails, and that path uses these.

Key identity the emulator reports:
  vendor code 0x133 (legacy 0x12C) | feature 0x144
  serial 0x4C565349 ("LVS I")      | keyid "LVSIM-EMS-EMU-0001"

VERIFIED
  * 11/11 exports present, i386 DLL (PE machine 0x14c)
  * all 9 ABI behaviours + 2 negative controls pass (bad vendor / bad feature -> 31)
  * full chain executed: app's LVSIMWebCs.dll -> this front-end -> emulator
        check() = 0  (HASP_STATUS_OK)   repeat call = 0   after logout = 0
  * negative control: emulator removed -> check() = 7 (HASP_NOT_FOUND), graceful

CAVEAT
  The ABI and the whole chain were executed on Linux (Mono + a native build of the
  same C logic) because Mono cannot load a PE32 DLL. The Windows DLL itself was
  validated structurally (PE/i386/exports) but not executed on Windows here.
