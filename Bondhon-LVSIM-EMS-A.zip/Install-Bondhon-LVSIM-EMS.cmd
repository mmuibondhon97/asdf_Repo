@echo off
rem ===========================================================================
rem  Bondhon LVSIM-EMS Deploy - bootstrapper
rem
rem  Finds and validates Windows PowerShell, elevates, forwards every argument
rem  to Install-Bondhon-LVSIM-EMS.ps1, and pauses on error so a double-click
rem  from Explorer shows the failure instead of a window that vanishes.
rem
rem  Works from Explorer (double-click), from cmd.exe, and via "cmd /c".
rem  Exit code is the PowerShell script's exit code.
rem ===========================================================================
setlocal EnableExtensions EnableDelayedExpansion

set "SCRIPT_DIR=%~dp0"
if "%SCRIPT_DIR:~-1%"=="\" set "SCRIPT_DIR=%SCRIPT_DIR:~0,-1%"
set "PS1=%SCRIPT_DIR%\Install-Bondhon-LVSIM-EMS.ps1"
set "EXITCODE=0"

rem ---- banner -------------------------------------------------------------
echo.
echo  ============================================================
echo   BONDHON  -  LVSIM-EMS Web 4.24  offline deploy
echo   installer: %PS1%
echo  ============================================================
echo.

rem ---- the .ps1 must sit next to this file --------------------------------
if not exist "%PS1%" (
    echo  [ERROR] Installer script not found:
    echo          %PS1%
    echo.
    echo  Keep Install-Bondhon-LVSIM-EMS.cmd and Install-Bondhon-LVSIM-EMS.ps1
    echo  in the same folder, together with the Medicine, LVSIM-EMS Web and
    echo  Prerequisites subfolders.
    set "EXITCODE=1"
    goto :finish
)

rem ---- the lib\ folder must be present too ---------------------------------
rem  The installer is modular: the master script dot-sources every module in
rem  lib\. If someone copies only the two top-level files, fail here with a
rem  clear message instead of a confusing "command not found" later.
set "LIBDIR=%SCRIPT_DIR%\lib"
if not exist "%LIBDIR%\00-Log.ps1" (
    echo  [ERROR] Installer modules not found:
    echo          %LIBDIR%
    echo.
    echo  This package is modular - the lib folder holds these files:
    echo          00-Log.ps1            06-PostInstall.ps1
    echo          01-Preflight.ps1      07-Summary.ps1
    echo          02-Prerequisites.ps1  08-FileLock.ps1
    echo          03-Application.ps1
    echo          04-Licence.ps1
    echo          05-Iis.ps1
    echo.
    echo  Extract the whole archive; do not move the .cmd/.ps1 on their own.
    set "EXITCODE=1"
    goto :finish
)

rem ---- locate Windows PowerShell 5.1 (powershell.exe, NOT pwsh.exe) -------
set "PSEXE="
if exist "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" (
    set "PSEXE=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
)
if not defined PSEXE (
    for %%P in (powershell.exe) do if not "%%~$PATH:P"=="" set "PSEXE=%%~$PATH:P"
)
if not defined PSEXE (
    echo  [ERROR] Windows PowerShell was not found.
    echo          Expected: %SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe
    echo.
    echo  This package needs Windows PowerShell 5.1, which ships with
    echo  Windows 8.1 / Server 2012 R2 and newer. It is fully offline -
    echo  no internet or PowerShell Gallery access is required.
    set "EXITCODE=1"
    goto :finish
)

rem ---- probe the PowerShell version (informational only) -----------------
rem  This probe is deliberately NON-FATAL. Blocking the install because a
rem  version STRING could not be parsed is wrong when the executable plainly
rem  exists: the .ps1 does the authoritative check and logs the real version
rem  ($PSVersionTable) as its first action. Known reasons the tiny probe can
rem  come back empty on a perfectly good machine: a hardened ExecutionPolicy,
rem  AV / AppLocker interference, a slow first-start of powershell.exe, or a
rem  stripped Console host. None of those break the installer.
rem  Only the explicit "older than 5" case below is treated as fatal.
rem  NOTE: PowerShell 2.0 ALSO lives at ...\v1.0\powershell.exe, and in 2.0 the
rem  variable $PSVersionTable does not exist at all. Querying it there raises
rem  an error, which 2^>nul swallows, which is why the old probe reported the
rem  unhelpful "did not respond" on machines that simply had 2.0. Fall back to
rem  $host.Version, which exists in every version from 1.0 to 7.x.
set "PSVER="
for /f "usebackq delims=" %%V in (`"%PSEXE%" -NoProfile -NonInteractive -ExecutionPolicy Bypass -Command "if ($PSVersionTable) { $PSVersionTable.PSVersion.ToString() } else { $host.Version.ToString() }" 2^>nul`) do set "PSVER=%%V"
if defined PSVER (
    set "PSMAJOR=%PSVER:~0,1%"
    echo  PowerShell : %PSVER%  (%PSEXE%)
    if %PSMAJOR% LSS 5 (
        echo.
        echo  [ERROR] PowerShell 5.1 or newer is required; found %PSVER%.
        echo          Windows 8.1 / Server 2012 R2 or newer is the minimum.
        set "EXITCODE=2"
        goto :finish
    )
) else (
    echo  PowerShell : version not reported by the probe - continuing
    echo               (%PSEXE%)
    echo               The installer checks the version itself and will stop if
    echo               it is below 5.1.
)

rem ---- elevation --------------------------------------------------------
rem  Elevation is performed INSIDE the .ps1 (Invoke-SelfElevate), which rebuilds
rem  the argument line from PowerShell's own parameter snapshot. Rebuilding it
rem  here from %* would corrupt any value containing spaces or quotes, so this
rem  bootstrapper deliberately does not try: it forwards the arguments verbatim
rem  and the installer raises the single UAC prompt itself.
net session >nul 2>&1
if errorlevel 1 (
    echo  Administrator rights required - the installer will raise a UAC prompt.
    echo.
)

"%PSEXE%" -NoProfile -ExecutionPolicy Bypass -File "%PS1%" %*
set "EXITCODE=!errorlevel!"

:finish
echo.
if "%EXITCODE%"=="0" (
    echo  ------------------------------------------------------------
    echo   Installer finished successfully ^(exit code 0^).
    echo  ------------------------------------------------------------
) else (
    echo  ------------------------------------------------------------
    echo   Installer finished with exit code %EXITCODE%.
    echo    1 = launcher problem (missing script / PowerShell)
    echo    2 = preflight failed (see the list above)
    echo    3 = install failed
    echo    4 = post-install verification did not pass
    echo    5 = uninstall failed
    echo   Full log: "%SCRIPT_DIR%\Logs"
    echo  ------------------------------------------------------------
)

rem ---- pause only when interactive ---------------------------------------
rem  Double-clicked from Explorer leaves cmd.exe as the parent process; this
rem  keeps the window open. "cmd /c" and scripts that call us also get the
rem  pause unless they pass -NoPause, which automation can use.
set "NOPAUSE="
for %%A in (%*) do if /i "%%~A"=="-NoPause" set "NOPAUSE=1"
if not defined NOPAUSE (
    echo.
    echo  Press any key to close this window . . .
    pause >nul
)
endlocal & exit /b %EXITCODE%
