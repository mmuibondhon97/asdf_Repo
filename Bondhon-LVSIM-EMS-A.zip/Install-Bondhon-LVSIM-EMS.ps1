﻿<#
.SYNOPSIS
  Offline, unattended installer for LAB-VOLT / Festo Didactic LVSIM-EMS Web 4.24
  (ASP.NET WebForms, .NET Framework 4.5.2, IIS) including the no-dongle licence
  replacement ("Medicine").

.DESCRIPTION
  Tested target: Windows 10 / 11 / Server 2016-2022, x86 application hosted on
  x64 IIS with a 32-bit-enabled application pool.  Requires NO internet access:
  every prerequisite payload ships inside this package.

  What it does, in order:
    1. Preflight  - admin, OS family, PowerShell version, disk space, payload
                    size + SHA-256 of every file it will use.
    2. Features   - enables only the IIS / ASP.NET 4.x Windows optional features
                    this application needs (DISM API, DISM.exe fallback).
    3. ASP.NET    - registers ASP.NET 4.x with IIS (aspnet_regiis.exe -i where
                    present, otherwise dism IIS-ASPNET45).  Non-fatal.
    4. .NET 4.5.2 - reads HKLM NDP\v4\Full\Release, runs the offline installer
                    only when the machine is below it.
    5. VC++ x86   - silent vc_redist.x86.exe (1638 = already installed = OK).
    6. App        - unattended InstallShield MSI to -InstallDir.  If the MSI
                    cannot be applied (e.g. the vendor's hardcoded port 62555 is
                    occupied and its IIS custom action aborts), it falls back to
                    laying down the shipped application tree.
    7. Medicine   - backs up the vendor HardLockWrapper.dll (bytes + .sha256),
                    verifies the replacement's assembly identity and all 7 bound
                    members, then swaps it in.  No dongle, no kernel driver.
    8. IIS        - app pool (.NET v4.0 / Integrated / 32-bit), site on -Port,
                    virtual directory /LVSIMWeb, default document, MIME maps,
                    ACLs.  If -Port is taken it advances to the next free port
                    and rewrites LVSIM-EMS.url.
    9. Firewall   - idempotent inbound TCP rule for the chosen port.
   10. Verify     - HTTP GET + server-method POSTs (GetVersion, HardLockLogin,
                    GetLicenseInfo, IsLocalHasp, IsLoggedIn).  Writes VERIFY.txt.
   11. Uninstall  - stops pool, removes site/vdir/pool + firewall rule, restores
                    the original DLL byte-exactly and proves it by hash.

.PARAMETER InstallDir
  Application root.  Default: "$env:ProgramFiles\Festo Didactic\LVSIM-EMS"
  (on 64-bit Windows that resolves to C:\Program Files (x86)\...).  Must not be
  a UNC path.

.PARAMETER Port
  Preferred TCP port for the IIS binding.  Default 62555 (vendor default).
  If the port is in use the installer advances to the next free port and records
  the result in the banner and in LVSIM-EMS.url.

.PARAMETER Locale
  en | es | fr.  es/fr apply the matching InstallShield transform (1034/3084).

.PARAMETER SkipPrereqs
  Skip steps 2-5 (features, ASP.NET registration, .NET, VC++).

.PARAMETER SkipAppInstall
  Skip step 6 (application files) and use the existing tree in -InstallDir.

.PARAMETER MedicineOnly
Only apply the licence medicine (skip prerequisites and the MSI).

.PARAMETER VerifyOnly
Check an existing installation without changing anything: payload hashes,
the medicine files on disk, IIS/app-pool state and the licence check.
Writes nothing except the log/VERIFY report and exits 0 when everything passes.
  Only steps 7 + a recycle: patch the DLL in an existing install.

.PARAMETER Uninstall
  Remove site/vdir/app pool/firewall rule and restore the original DLL.

.PARAMETER RemoveFiles
  Together with -Uninstall: also delete the install directory.

.PARAMETER InstallDongleDriver
  OPTIONAL, non-default: also install the HASP runtime (haspdinst.exe -i) to
  support a physical USB key.  NOT needed for the default DLL patch.

.PARAMETER Force
  Continue past non-fatal warnings (e.g. overwrite an existing site).

.PARAMETER MinFreeMB
  Free space required on the -InstallDir volume.  Default 1500.

.EXAMPLE
  .\Install-Bondhon-LVSIM-EMS.ps1
  Default install to Program Files (x86), port 62555, licence patch applied.

.EXAMPLE
  .\Install-Bondhon-LVSIM-EMS.ps1 -InstallDir 'D:\Festo\LVSIM-EMS' -Port 21034

.EXAMPLE
  .\Install-Bondhon-LVSIM-EMS.ps1 -Uninstall -RemoveFiles

.EXAMPLE
  .\Install-Bondhon-LVSIM-EMS.ps1 -SkipPrereqs -SkipAppInstall   # repatch only

.OUTPUTS
  Exit codes: 0 success, 1 usage/argument error, 2 preflight failure,
  3 install failure, 4 post-install verification failure, 5 uninstall failure.

.NOTES
  Windows PowerShell 5.1 compatible.  No modules outside those shipped with
  Windows.  Safe under Set-StrictMode -Version 2 and $ErrorActionPreference=Stop.
  Every path derives from $PSScriptRoot.  Logs: <package>\Logs\install-*.log
  (plus a Start-Transcript capture) and <package>\Logs\VERIFY.txt.
#>

[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [string] $InstallDir        = '',
    [int]    $Port              = 62555,
    [string] $SiteName          = 'LVSIMWeb',
    [string] $AppPoolName       = 'LVSIMWebAppPool',
    [string] $VdirName          = 'LVSIMWeb',
    [ValidateSet('en', 'es', 'fr')]
    [string] $Locale            = 'en',
    [switch] $SkipPrereqs,
    [switch] $SkipAppInstall,
    [switch] $MedicineOnly,
    [switch] $VerifyOnly,
    [switch] $Uninstall,
    [switch] $RemoveFiles,
    [switch] $InstallDongleDriver,
    [switch] $Force,
    [switch] $AlreadyElevated,
    # Accepted for the .cmd bootstrapper's benefit (it pauses unless given this
    # switch). No effect inside this script; declared so forwarding never errors.
    [switch] $NoPause,
    [switch] $SkipImageRefresh,
    [int]    $MinFreeMB         = 1500,
    [int]    $HttpTimeoutSec    = 30
)

Set-StrictMode -Version 2
$ErrorActionPreference = 'Stop'

# IMPORTANT: $PSBoundParameters inside a FUNCTION is that function's own set,
# not the script's. Snapshot the script-level set once, here, for re-launching.
$script:ScriptBoundParameters = @{}
foreach ($k in $PSBoundParameters.Keys) {
    if ($k -eq 'NoPause') { continue }
    $script:ScriptBoundParameters[$k] = $PSBoundParameters[$k]
}

# ---------------------------------------------------------------------------
# 0.  Location, logging, tiny helpers
# ---------------------------------------------------------------------------

# Every path derives from the script root - never hardcode a drive.
$script:Root         = $PSScriptRoot
if ([string]::IsNullOrEmpty($script:Root)) {
    $script:Root = Split-Path -Parent $MyInvocation.MyCommand.Definition
}
$script:Root         = (Resolve-Path -LiteralPath $script:Root).Path

$script:DirMedia     = Join-Path $script:Root 'LVSIM-EMS Web'
$script:DirAppSource = Join-Path $script:DirMedia 'AppSource'
$script:DirMedicine  = Join-Path $script:Root 'Medicine'
$script:DirPrereq    = Join-Path $script:Root 'Prerequisites'
$script:DirLogs      = Join-Path $script:Root 'Logs'
$script:DirBackup    = Join-Path $script:DirMedicine 'backup'

$script:Stamp        = Get-Date -Format 'yyyyMMdd-HHmmss'
$script:LogFile      = Join-Path $script:DirLogs ("install-$($script:Stamp).log")
$script:VerifyFile   = Join-Path $script:DirLogs 'VERIFY.txt'
$script:DryRun       = [bool]$WhatIfPreference
$script:ExitCode     = 0
$script:Failures     = New-Object System.Collections.ArrayList
$script:Warnings     = New-Object System.Collections.ArrayList
$script:Results      = New-Object System.Collections.ArrayList
$script:ChosenPort   = $Port
# $InstallDir is a param(), so $script:InstallDir does NOT auto-bind to it.
# Without this line, the read under Set-StrictMode -Version 2 throws
# "The variable '\$script:InstallDir' cannot be retrieved".
$script:InstallDir  = $InstallDir
$script:MsiExitCode  = -1

if (-not [System.IO.Directory]::Exists($script:DirLogs)) {
    # Directory.CreateDirectory, not New-Item: no "What if" noise under -WhatIf.
    [void][System.IO.Directory]::CreateDirectory($script:DirLogs)
}

function Invoke-Native {
    <#  Runs an external program, returns exit code, tees stdout to the log. #>
    param(
        [string]   $FilePath,
        [string[]] $Arguments = @(),
        [string]   $Label     = '',
        [int[]]    $OkCodes   = @(0)
    )
    if ($script:DryRun) {
        Write-Log ("    (whatif) $FilePath " + ($Arguments -join ' '))
        return 0
    }
    $display = "$FilePath " + ($Arguments -join ' ')
    Write-Log ("    exec: " + $display)
    $output = @()
    try {
        $output = & $FilePath @Arguments 2>&1
    } catch {
        Write-Log ("    exec threw: " + $_.Exception.Message) 'WARN'
        return 9999
    }
    $code = $LASTEXITCODE
    if ($null -eq $code) { $code = 0 }
    foreach ($o in $output) {
        $t = [string]$o
        if ($t.Trim().Length -gt 0) { Write-Log ("      | " + $t) }
    }
    $okText = ($OkCodes -join ',')
    if ($OkCodes -contains $code) {
        Write-Log ("    exit=$code (accepted; ok=[$okText])" + $(if ($Label) { " $Label" } else { '' }))
    } else {
        Write-Log ("    exit=$code (NOT accepted; ok=[$okText])" + $(if ($Label) { " $Label" } else { '' })) 'WARN'
    }
    return $code
}

# ---------------------------------------------------------------------------
# 1.  Elevation
# ---------------------------------------------------------------------------

function Invoke-SelfElevate {
    <#  Relaunches this script elevated, forwarding the ORIGINAL arguments.
        Returns @{ Launched = $bool; ExitCode = $int }.
        Never returns $null, so the caller can distinguish
        "did not try" from "tried and the user cancelled UAC". #>
    if ($AlreadyElevated) {
        return @{ Launched = $false; ExitCode = 0 }
    }
    $exe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    if (-not (Test-Path -LiteralPath $exe)) {
        Write-Log 'powershell.exe not found - cannot self-elevate' 'FAIL'
        return @{ Launched = $false; ExitCode = 2 }
    }

    # Build the argument line from the script-level snapshot, quoting values so
    # paths containing spaces survive the relaunch.
    $parts = New-Object System.Collections.ArrayList
    [void]$parts.Add('-NoProfile')
    [void]$parts.Add('-ExecutionPolicy')
    [void]$parts.Add('Bypass')
    # $PSCommandPath is authoritative when the script was launched with -File.
    # ($MyInvocation.MyCommand.Definition is NOT usable here: inside a function
    # it returns that function's own body text.) Fall back to the script root.
    $selfPath = $PSCommandPath
    if ([string]::IsNullOrEmpty($selfPath)) {
        $selfPath = Join-Path $script:Root 'Install-Bondhon-LVSIM-EMS.ps1'
    }
    [void]$parts.Add('-File')
    [void]$parts.Add('"' + $selfPath + '"')
    foreach ($k in $script:ScriptBoundParameters.Keys) {
        if ($k -eq 'AlreadyElevated') { continue }
        $v = $script:ScriptBoundParameters[$k]
        # Treat both SwitchParameter and a plain boolean as on/off flags, so a
        # switch is never emitted as '-Name "False"'.
        if ($v -is [System.Management.Automation.SwitchParameter]) {
            if ($v.IsPresent) { [void]$parts.Add('-' + $k) }
        } elseif ($v -is [bool]) {
            if ($v) { [void]$parts.Add('-' + $k) }
        } else {
            [void]$parts.Add('-' + $k)
            [void]$parts.Add('"' + ([string]$v) + '"')
        }
    }
    [void]$parts.Add('-AlreadyElevated')
    if ($script:DryRun) { [void]$parts.Add('-WhatIf') }

    $argLine = ($parts -join ' ')
    Write-Log 'Not elevated - relaunching this script as administrator ...'
    Write-Log ("    $exe $argLine")
    try {
        $p = Start-Process -FilePath $exe -ArgumentList $argLine -Verb RunAs -PassThru -Wait
        Write-Log ("    elevated run finished with exit code {0}" -f $p.ExitCode)
        return @{ Launched = $true; ExitCode = [int]$p.ExitCode }
    } catch {
        Write-Log ('Elevation failed or UAC was declined: ' + $_.Exception.Message) 'FAIL'
        return @{ Launched = $false; ExitCode = 2 }
    }
}

# ---------------------------------------------------------------------------
# 2.  Payload manifest + preflight
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
#  Module loader
#  The installer is split into small, single-purpose modules under .\lib.
#  Each is dot-sourced into THIS scope so they share $script: state.
#  A missing or unparsable module is reported by name and aborts cleanly,
#  rather than failing later with a confusing "command not found".
# ---------------------------------------------------------------------------

$script:DirLib = Join-Path $script:Root 'lib'

$script:Modules = @(
    '00-Log.ps1'          # logging, results, admin/command probes
    '01-Preflight.ps1'    # manifest + hash check + environment assertions
    '02-Prerequisites.ps1'# IIS features, ASP.NET, .NET 4.5.2, VC++, HASP
    '03-Application.ps1'  # unattended MSI
    '04-Licence.ps1'      # medicine DLL + header image
    '05-Iis.ps1'          # appcmd: pool, site, vdir, ACL, port
    '06-PostInstall.ps1'  # firewall, verification, uninstall
    '07-Summary.ps1'      # banner + summary table
    '08-FileLock.ps1'     # file-lock defeat: stop pool, kill PID, retry
)

function Import-InstallerModules {
    param([string[]] $Names)
    $missing = New-Object System.Collections.ArrayList
    foreach ($n in $Names) {
        $path = Join-Path $script:DirLib $n
        if (-not (Test-Path -LiteralPath $path)) { [void]$missing.Add($n); continue }
        try {
            . $path
        } catch {
            Write-Host ("  [FAIL] module $n could not be loaded: " + $_.Exception.Message) -ForegroundColor Red
            [void]$missing.Add($n)
        }
    }
    return $missing.ToArray()
}

# ---------------------------------------------------------------------------
#  Load all modules, then run main().
# ---------------------------------------------------------------------------
$script:BadModules = @(Import-InstallerModules -Names $script:Modules)
if ($script:BadModules.Count -gt 0) {
    Write-Host ''
    Write-Host '  The installer package is incomplete.' -ForegroundColor Red
    Write-Host ("  Missing or broken module(s): " + ($script:BadModules -join ', ')) -ForegroundColor Red
    Write-Host ("  Expected in: " + $script:DirLib) -ForegroundColor Red
    Write-Host '  Re-extract the package so the lib\ folder sits next to this script.' -ForegroundColor Red
    Write-Host ''
    exit 1
}

# 14.  Main
# ---------------------------------------------------------------------------

$transcriptStarted = $false
try {
    try {
        if (-not $script:DryRun) {
            # -Path (not -LiteralPath): identical behaviour here and present on 5.1.
            Start-Transcript -Path (Join-Path $script:DirLogs ("transcript-$($script:Stamp).txt")) -Force | Out-Null
            $transcriptStarted = $true
        }
    } catch {
        Write-Host ('transcript unavailable: ' + $_.Exception.Message)
    }

    Write-Banner

    # ---- elevation (before anything needs admin) ----------------------
    if (-not $AlreadyElevated -and -not (Test-IsAdmin) -and -not $script:DryRun) {
        $elev = Invoke-SelfElevate
        if ($elev.Launched) {
            # The elevated child did the work; propagate its exit code.
            $script:ExitCode = $elev.ExitCode
        } else {
            Write-Log 'Could not elevate. Right-click Install-Bondhon-LVSIM-EMS.cmd' 'FAIL'
            Write-Log 'and choose "Run as administrator", then try again.' 'FAIL'
            $script:ExitCode = 2
        }
        Write-Summary
        if ($transcriptStarted) { try { Stop-Transcript | Out-Null } catch { } }
        exit $script:ExitCode
    }

    if ($Uninstall) {
        if (-not (Assert-Preflight)) { $script:ExitCode = 2 }
        else {
            if (-not $SkipAppInstall -and $script:InstallDir -eq '') { }
            $ok = Invoke-Uninstall
            if (-not $ok) { $script:ExitCode = 5 }
        }
        Write-Summary
        if ($transcriptStarted) { try { Stop-Transcript | Out-Null } catch { } }
        exit $script:ExitCode
    }

    # ---- verify only (no mutation) -------------------------------------
    if ($VerifyOnly) {
        Write-Step 'Verify only - nothing will be changed'
        # payload integrity is the one thing worth checking even here
        if (-not (Test-PayloadHashes)) { $script:ExitCode = 2 }
        else {
            $ok = Invoke-PostInstallVerification
            if (-not $ok) { $script:ExitCode = 4 }
        }
        Write-Summary
        if ($transcriptStarted) { try { Stop-Transcript | Out-Null } catch { } }
        exit $script:ExitCode
    }

    # ---- preflight ----------------------------------------------------
    if (-not (Assert-Preflight)) {
        Write-Summary
        if ($transcriptStarted) { try { Stop-Transcript | Out-Null } catch { } }
        exit 2
    }

    # ---- prerequisites ------------------------------------------------
    $prereqOk = $true
    if ($MedicineOnly) {
        Add-Result 'Prerequisites' 'SKIP' '-MedicineOnly'
    } elseif ($SkipPrereqs) {
        Add-Result 'Prerequisites' 'SKIP' '-SkipPrereqs'
    } else {
        if (-not (Install-IisFeatures)) { $prereqOk = $false }
        [void](Register-AspNetWithIis)
        if (-not (Install-DotNet452IfNeeded)) { $prereqOk = $false }
        if (-not (Install-VcRedistIfNeeded)) { $prereqOk = $false }
    }
    if ($InstallDongleDriver) { [void](Install-HaspDriver) }

    if (-not $prereqOk -and -not $Force) {
        Write-Log ''
        Write-Log 'A required prerequisite failed. Re-run with -Force to continue anyway.' 'FAIL'
        Write-Summary
        if ($transcriptStarted) { try { Stop-Transcript | Out-Null } catch { } }
        exit 3
    }

    # ---- application --------------------------------------------------
    if ($MedicineOnly) {
        Add-Result 'Application' 'SKIP' '-MedicineOnly'
    } elseif ($SkipAppInstall) {
        if (-not (Test-Path -LiteralPath (Join-Path $script:InstallDir 'bin\LVSIMWebCs.dll'))) {
            Add-Result 'Application' 'WARN' "-SkipAppInstall but bin\LVSIMWebCs.dll is not present"
        } else {
            Add-Result 'Application' 'SKIP' '-SkipAppInstall (existing tree used)'
        }
    } else {
        if (-not (Install-Application)) {
            Write-Log 'Application install failed - stopping before IIS/medicine.' 'FAIL'
            Write-Summary
            if ($transcriptStarted) { try { Stop-Transcript | Out-Null } catch { } }
            exit 3
        }
    }

    # ---- medicine -----------------------------------------------------
    $medOk = Invoke-MedicinePatch
    if (-not $SkipImageRefresh) { $null = Invoke-ImageRefresh -InstallDir $script:InstallDir }
    if (-not $medOk) {
        Write-Log 'Medicine patch failed.' 'FAIL'
        Write-Summary
        if ($transcriptStarted) { try { Stop-Transcript | Out-Null } catch { } }
        exit 3
    }

    if ($MedicineOnly) {
        if (Test-AppPoolExists -Name $AppPoolName) {
            [void](Invoke-AppCmd -Label 'recycle apppool' -Arguments @('recycle', 'apppool', "/apppool.name:$AppPoolName"))
        }
        Write-Summary
        if ($transcriptStarted) { try { Stop-Transcript | Out-Null } catch { } }
        exit 0
    }

    # ---- port + IIS ---------------------------------------------------
    if ($script:DryRun) {
        $script:ChosenPort = $Port
        Write-Log "    (whatif) would use port $($script:ChosenPort)"
    } else {
        $free = Resolve-SitePort -Preferred $Port
        if ($free -le 0) {
            Write-Log "no free TCP port found near $Port" 'FAIL'
            Add-Result 'IIS site' 'FAIL' "no free port near $Port"
            Write-Summary
            if ($transcriptStarted) { try { Stop-Transcript | Out-Null } catch { } }
            exit 3
        }
        $script:ChosenPort = $free
    }
    if ($script:MsiExitCode -ne 0 -and $script:MsiExitCode -ne -1) {
        Write-Log "    note: msiexec returned $($script:MsiExitCode); the vendor MSI may have created its own site"
    }

    $iisOk = Configure-Iis
    [void](Update-InternetShortcut -NewPort $script:ChosenPort)
    [void](Add-FirewallRule)

    if (-not $iisOk) {
        Write-Log 'IIS configuration failed.' 'FAIL'
        Write-Summary
        if ($transcriptStarted) { try { Stop-Transcript | Out-Null } catch { } }
        exit 3
    }

    # ---- verification -------------------------------------------------
    $verifyOk = Invoke-PostInstallVerification
    Write-Summary

    if (-not $verifyOk) {
        Write-Log 'Post-install verification did not pass (see VERIFY.txt).' 'FAIL'
        $script:ExitCode = 4
    }

    if ($transcriptStarted) { try { Stop-Transcript | Out-Null } catch { } }
    exit $script:ExitCode
} catch {
    $msg = $_.Exception.Message
    $lineNo = $_.InvocationInfo.ScriptLineNumber
    Write-Log ("UNHANDLED: $msg (line $lineNo)") 'FAIL'
    try {
        [System.IO.File]::AppendAllText($script:LogFile,
            'STACK: ' + $_.ScriptStackTrace + [System.Environment]::NewLine)
    } catch { }
    if ($transcriptStarted) { try { Stop-Transcript | Out-Null } catch { } }
    exit 3
}
