# Installer modules (lib\)

`Install-Bondhon-LVSIM-EMS.ps1` is a thin **master**: it declares parameters,
creates the shared state, dot-sources every module below into its own scope,
then runs the phases in order. Each module is one job and can be edited without
touching the others.

| Module | Lines | Responsibility |
|---|---|---|
| `00-Log.ps1` | ~44 | `Write-Log`, `Write-Step`, `Add-Result`, admin/command probes |
| `01-Preflight.ps1` | ~192 | payload manifest, SHA-256 verification, environment assertions |
| `02-Prerequisites.ps1` | ~250 | IIS features, ASP.NET, .NET 4.5.2, VC++ 2013, HASP driver |
| `03-Application.ps1` | ~101 | unattended MSI run |
| `04-Licence.ps1` | ~462 | medicine DLL replacement + header image |
| `05-Iis.ps1` | ~359 | appcmd: app pool, site, vdir, ACLs, port |
| `06-PostInstall.ps1` | ~388 | firewall, HTTP verification, uninstall |
| `07-Summary.ps1` | ~48 | banner + result table |
| `08-FileLock.ps1` | ~231 | **file-lock defeat**: stop pool, force-kill holding PID, retry |

## How a locked file is handled (08-FileLock.ps1)

The Medicine step replaces `bin\HardLockWrapper.dll`. If IIS is already serving
the app, `w3wp.exe` keeps that file mapped and `Copy-Item` fails with
*"being used by another process"*. `Copy-ItemWithLockHandling` escalates:

1. `Test-FileWritable` — opens the file with `FileShare.None`; this is the exact
   "can I overwrite it?" test, cheaper and more reliable than guessing.
2. If locked → stop `LVSIMWebAppPool`, poll up to 20 s for the mapping to drop.
3. Attempt 3 → find the holder with `Get-FileLockingProcess` and
   `Stop-Process -Force` that PID.
4. Attempts 4-5 → recycle the pool, re-kill, retry.
5. `Restore-SiteAfterFileUpdate` always runs afterwards (even on failure), so
   IIS is never left stopped.

If the file is already writable the pool is **not touched at all** — a fresh
install is unaffected.

## Constraints honoured

* Windows PowerShell **5.1** on Windows 10 / 11 and Server 2016-2022.
* No external modules (`WebAdministration` is optional, `appcmd.exe` is primary),
  no Sysinternals, no internet.
* Safe under `Set-StrictMode -Version 2` and `$ErrorActionPreference = 'Stop'`.
* Files are UTF-8 **with BOM** and CRLF, so 5.1 parses them correctly.
* A missing or unparsable module is reported by name and aborts with exit 1
  instead of failing later with an obscure error.
