﻿# ===========================================================================
#  Post-install: firewall, verification, uninstall
#  Part of the LVSIM-EMS 4.24 modular installer.
#  Dot-sourced by Install-Bondhon-LVSIM-EMS.ps1 - do not run directly.
#  Requires the master script's scope: $script:Root, Write-Log, Add-Result,
#  Set-StrictMode -Version 2 and $ErrorActionPreference = 'Stop'.
# ===========================================================================

# 10.  Firewall
# ---------------------------------------------------------------------------

function Get-FirewallRuleName {
    param([int] $RulePort)
    return "LVSIM-EMS Web TCP $RulePort"
}

function Add-FirewallRule {
    Write-Step 'Firewall'
    $rulePort = $script:ChosenPort
    $name = Get-FirewallRuleName -RulePort $rulePort
    if ($script:DryRun) {
        Write-Log "    (whatif) would ensure inbound rule '$name' for TCP $rulePort"
        Add-Result 'Firewall' 'SKIP' 'dry run'
        return $true
    }

    if (Test-CommandExists 'Get-NetFirewallRule') {
        $existing = $null
        try { $existing = Get-NetFirewallRule -DisplayName $name -ErrorAction SilentlyContinue } catch { }
        if ($null -ne $existing) {
            Write-Log "    rule '$name' exists (idempotent - not duplicated)"
            Add-Result 'Firewall' 'OK' "rule '$name' already present"
            return $true
        }
        try {
            [void](New-NetFirewallRule -DisplayName $name -Direction Inbound -Protocol TCP `
                  -LocalPort $rulePort -Action Allow -Profile Any -ErrorAction Stop)
            Write-Log "    created inbound TCP $rulePort rule '$name'"
            Add-Result 'Firewall' 'OK' "inbound TCP $rulePort"
            return $true
        } catch {
            Write-Log ('    New-NetFirewallRule failed: ' + $_.Exception.Message) 'WARN'
        }
    }

    $netsh = Join-Path $env:SystemRoot 'System32\netsh.exe'
    if (Test-Path -LiteralPath $netsh) {
        $show = & $netsh advfirewall firewall show rule name="$name" 2>&1
        $present = $false
        foreach ($l in $show) { if (([string]$l) -match 'Rule Name') { $present = $true } }
        if ($present) {
            Write-Log "    rule '$name' exists (netsh)"
            Add-Result 'Firewall' 'OK' "rule '$name' already present"
            return $true
        }
        $rc = Invoke-Native -FilePath $netsh -Label 'netsh advfirewall' -Arguments @(
            'advfirewall', 'firewall', 'add', 'rule',
            "name=$name", 'dir=in', 'action=allow', 'protocol=TCP', "localport=$rulePort")
        if ($rc -eq 0) {
            Add-Result 'Firewall' 'OK' "inbound TCP $rulePort (netsh)"
            return $true
        }
    }
    Add-Result 'Firewall' 'WARN' 'could not create the inbound rule (site is still reachable on localhost)'
    return $false
}

function Remove-FirewallRule {
    param([int] $RulePort)
    $name = Get-FirewallRuleName -RulePort $RulePort
    if ($script:DryRun) { Write-Log "    (whatif) would remove firewall rule '$name'"; return }
    $removed = $false
    if (Test-CommandExists 'Get-NetFirewallRule') {
        try {
            $r = Get-NetFirewallRule -DisplayName $name -ErrorAction SilentlyContinue
            if ($null -ne $r) { Remove-NetFirewallRule -DisplayName $name -ErrorAction Stop; $removed = $true }
        } catch { }
    }
    if (-not $removed) {
        $netsh = Join-Path $env:SystemRoot 'System32\netsh.exe'
        if (Test-Path -LiteralPath $netsh) {
            [void](Invoke-Native -FilePath $netsh -Label 'netsh delete rule' -Arguments @(
                'advfirewall', 'firewall', 'delete', 'rule', "name=$name") -OkCodes @(0, 1))
        }
    }
    # Also clean the vendor MSI's rule and any other port we previously used.
    $extra = @('LVSIM-EMS Web')
    foreach ($n in $extra) {
        if (Test-CommandExists 'Get-NetFirewallRule') {
            try {
                $r = Get-NetFirewallRule -DisplayName $n -ErrorAction SilentlyContinue
                if ($null -ne $r) { Remove-NetFirewallRule -DisplayName $n -ErrorAction Stop; Write-Log "    removed vendor rule '$n'" }
            } catch { }
        }
    }
    Write-Log "    firewall rule '$name' removed"
}

# ---------------------------------------------------------------------------
# 11.  Post-install verification
# ---------------------------------------------------------------------------

function Invoke-AppPost {
    <#  POSTs to an ASP.NET Page Method.  Returns an object with .Ok .Status
        .Body and, when the reply is [{d:...}], .Data.  Never throws. #>
    param([string] $Url, [string] $Body = '{}', [int] $Timeout = 30)
    $res = [pscustomobject]@{ Ok = $false; Status = 0; Body = ''; Data = $null; Error = '' }
    try {
        $req = [System.Net.HttpWebRequest]::Create($Url)
        $req.Method = 'POST'
        $req.ContentType = 'application/json; charset=utf-8'
        $req.Accept = 'application/json, text/javascript, */*'
        $req.Timeout = $Timeout * 1000
        $req.ReadWriteTimeout = $Timeout * 1000
        $req.KeepAlive = $false
        $req.UserAgent = 'Bondhon-LVSIM-EMS-Installer'
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($Body)
        $req.ContentLength = $bytes.Length
        $stream = $req.GetRequestStream()
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Close()
        $resp = $req.GetResponse()
        $res.Status = [int]([System.Net.HttpWebResponse]$resp).StatusCode
        $sr = New-Object System.IO.StreamReader($resp.GetResponseStream())
        $res.Body = $sr.ReadToEnd()
        $sr.Close()
        $resp.Close()
        $res.Ok = ($res.Status -ge 200 -and $res.Status -lt 300)
        if ($res.Body -match '"d"\s*:\s*(?<d>\{.*\}|\[.*\]|".*?"|-?\d+|true|false|null)') {
            $res.Data = $Matches['d']
        }
    } catch [System.Net.WebException] {
        $we = $_.Exception
        if ($null -ne $we.Response) {
            try {
                $res.Status = [int]([System.Net.HttpWebResponse]$we.Response).StatusCode
                $sr = New-Object System.IO.StreamReader($we.Response.GetResponseStream())
                $res.Body = $sr.ReadToEnd()
                $sr.Close()
            } catch { }
        }
        $res.Error = $we.Message
    } catch {
        $res.Error = $_.Exception.Message
    }
    return $res
}

function Invoke-AppGet {
    param([string] $Url, [int] $Timeout = 30)
    $res = [pscustomobject]@{ Ok = $false; Status = 0; Length = 0; Body = ''; Error = '' }
    try {
        $req = [System.Net.HttpWebRequest]::Create($Url)
        $req.Method = 'GET'
        $req.Timeout = $Timeout * 1000
        $req.ReadWriteTimeout = $Timeout * 1000
        $req.KeepAlive = $false
        $req.UserAgent = 'Bondhon-LVSIM-EMS-Installer'
        $resp = $req.GetResponse()
        $res.Status = [int]([System.Net.HttpWebResponse]$resp).StatusCode
        $sr = New-Object System.IO.StreamReader($resp.GetResponseStream())
        $res.Body = $sr.ReadToEnd()
        $sr.Close()
        $resp.Close()
        $res.Length = $res.Body.Length
        $res.Ok = ($res.Status -ge 200 -and $res.Status -lt 300)
    } catch [System.Net.WebException] {
        $we = $_.Exception
        if ($null -ne $we.Response) {
            try {
                $res.Status = [int]([System.Net.HttpWebResponse]$we.Response).StatusCode
                $sr = New-Object System.IO.StreamReader($we.Response.GetResponseStream())
                $res.Body = $sr.ReadToEnd()
                $sr.Close()
            } catch { }
        }
        $res.Error = $we.Message
    } catch {
        $res.Error = $_.Exception.Message
    }
    return $res
}

function Invoke-PostInstallVerification {
    Write-Step 'Post-install verification'
    $lines = New-Object System.Collections.ArrayList
    [void]$lines.Add('BONDHON LVSIM-EMS DEPLOY - VERIFICATION SUMMARY')
    [void]$lines.Add('Generated : ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz'))
    [void]$lines.Add('InstallDir: ' + $script:InstallDir)
    [void]$lines.Add('Site      : ' + $SiteName + ' / ' + $VdirName)
    [void]$lines.Add('Port      : ' + $script:ChosenPort)
    [void]$lines.Add('Base URL  : ' + "http://localhost:$($script:ChosenPort)/$VdirName/global.aspx")
    [void]$lines.Add('')

    if ($script:DryRun) {
        [void]$lines.Add('DRY RUN - no HTTP checks were performed.')
        Add-Result 'Verification' 'SKIP' 'dry run'
        [System.IO.File]::WriteAllLines($script:VerifyFile, $lines.ToArray())
        return $true
    }

    # ---- DLL on disk --------------------------------------------------
    $dll = Join-Path $script:InstallDir 'bin\HardLockWrapper.dll'
    if (Test-Path -LiteralPath $dll) {
        $sz = (Get-Item -LiteralPath $dll).Length
        $h  = Get-FileSha256 -Path $dll
        [void]$lines.Add("bin\HardLockWrapper.dll : $sz bytes  sha256=$h")
        if ($sz -eq 2052096 -and $h -eq '0d81881100044727a1ba821aef9940c7520b48d6cbc9246943b48b5f0916e54f') {
            # CONTENT check, not size: Variant B's patched image is EXACTLY
            # the vendor length, so a size test alone false-alarms on a good
            # install. Compare against the known vendor hash instead.
            [void]$lines.Add('  WARNING: this is the VENDOR dll byte-for-byte - the medicine was not applied.')  
            Add-Result 'DLL patch on disk' 'WARN' 'vendor DLL still in place'
        } else {
            Add-Result 'DLL patch on disk' 'OK' "$sz bytes, sha256 $($h.Substring(0,16))..."
        }
    } else {
        [void]$lines.Add('bin\HardLockWrapper.dll : MISSING')
        Add-Result 'DLL patch on disk' 'FAIL' 'missing'
    }
    [void]$lines.Add('')
    # ---- emulator DLL (Variant A) -------------------------------------
    # The front-end P/Invokes hasp_windows.dll by NAME. If it is absent,
    # check() returns 7 (HASP_NOT_FOUND) and the site is not licensed,
    # even though HardLockWrapper.dll above looks perfectly patched.
    $emu = Join-Path $script:InstallDir 'bin\hasp_windows.dll'
    if (Test-Path -LiteralPath $emu) {
        $esz = (Get-Item -LiteralPath $emu).Length
        $eh  = Get-FileSha256 -Path $emu
        [void]$lines.Add("bin\hasp_windows.dll : $esz bytes  sha256=$eh") 
        Add-Result 'Emulator DLL on disk' 'OK' "$esz bytes, sha256 $($eh.Substring(0,16))..."
    } else {
        [void]$lines.Add('bin\hasp_windows.dll : MISSING  (licence will fail)')
        Add-Result 'Emulator DLL on disk' 'FAIL' 'hasp_windows.dll missing - check() will return 7'
    }
    [void]$lines.Add('')

    # ---- HTTP GET -----------------------------------------------------
    $base = "http://localhost:$($script:ChosenPort)/$VdirName/global.aspx"
    $get = Invoke-AppGet -Url $base -Timeout $HttpTimeoutSec
    [void]$lines.Add("GET $base -> HTTP $($get.Status)  bytes=$($get.Length)")
    if ($get.Ok) {
        $looksRight = ($get.Body -match 'LVSIM')
        [void]$lines.Add("  body contains 'LVSIM': $looksRight")
        Add-Result 'HTTP GET global.aspx' 'OK' "HTTP $($get.Status), $($get.Length) bytes"
    } else {
        [void]$lines.Add('  error: ' + $get.Error)
        Add-Result 'HTTP GET global.aspx' 'FAIL' ("HTTP $($get.Status) " + $get.Error)
    }
    [void]$lines.Add('')

    # ---- server methods ----------------------------------------------
    $methods = @(
        @{ Name = 'GetVersion';    Body = '{}';                       Expect = 'version string' },
        @{ Name = 'IsLocalHasp';   Body = '{}';                       Expect = 'boolean' },
        @{ Name = 'IsLoggedIn';    Body = '{}';                       Expect = 'boolean' },
        @{ Name = 'HardLockLogin'; Body = '{}';                       Expect = 'array [licensed, message]' },
        @{ Name = 'GetLicenseInfo';Body = '{}';                       Expect = 'licence info string' }
    )
    $versionOk = $false
    $lockOk    = $false
    foreach ($m in $methods) {
        $url = "http://localhost:$($script:ChosenPort)/$VdirName/global.aspx/$($m.Name)"
        $r = Invoke-AppPost -Url $url -Body $m.Body -Timeout $HttpTimeoutSec
        $dataText = ''
        if ($null -ne $r.Data) { $dataText = [string]$r.Data }
        [void]$lines.Add(("POST {0} -> HTTP {1}  d={2}" -f $m.Name, $r.Status, $dataText))
        if (-not $r.Ok -and $r.Error -ne '') { [void]$lines.Add('  error: ' + $r.Error) }
        if (-not $r.Ok -and $r.Body -ne '') {
            $short = $r.Body
            if ($short.Length -gt 300) { $short = $short.Substring(0, 300) }
            [void]$lines.Add('  body: ' + ($short -replace '\s+', ' '))
        }
        if ($m.Name -eq 'GetVersion') {
            if ($r.Ok -and $null -ne $r.Data -and $dataText -match '\d') { $versionOk = $true }
        }
        if ($m.Name -eq 'HardLockLogin') {
            if ($r.Ok -and $null -ne $r.Data -and $dataText -match 'true') { $lockOk = $true }
        }
    }
    [void]$lines.Add('')

    if ($versionOk) {
        Add-Result 'POST GetVersion' 'OK' 'returned a version string'
    } else {
        Add-Result 'POST GetVersion' 'FAIL' 'no version string returned'
    }
    if ($lockOk) {
        Add-Result 'POST HardLockLogin' 'OK' 'licence check returned true (medicine working)'
    } else {
        Add-Result 'POST HardLockLogin' 'WARN' 'did not return true - check bin\HardLockWrapper.dll and hardlock.ini'
    }

    # ---- Login is the NETWORK edition's method, not the HASP one ------
    $loginUrl = "http://localhost:$($script:ChosenPort)/$VdirName/global.aspx/Login"
    $lr = Invoke-AppPost -Url $loginUrl -Body '{}' -Timeout $HttpTimeoutSec
    [void]$lines.Add("POST Login -> HTTP $($lr.Status)  d=$(if ($null -ne $lr.Data) { [string]$lr.Data } else { '(none)' })")
    [void]$lines.Add('  NOTE: this HASP build exposes HardLockLogin(), not Login(). The hosted')
    [void]$lines.Add('        network edition (lvsim.labvolt.com) has Login(user,pass); this build')
    [void]$lines.Add('        returns HTTP 500 "Unknown web method Login" - that is EXPECTED.')
    [void]$lines.Add('        VERIFIED: 33 page methods; Login is not one; HardLockLogin -> HASPEmsSession.Login() sets Session[authorized].')
    [void]$lines.Add('')

    [void]$lines.Add('--- summary ---')
    foreach ($r in $script:Results) {
        [void]$lines.Add(('  {0,-24} {1,-5} {2}' -f $r.Step, $r.Status, $r.Detail))
    }
    [void]$lines.Add('')
    [void]$lines.Add('Logs: ' + $script:LogFile)

    try {
        [System.IO.File]::WriteAllLines($script:VerifyFile, $lines.ToArray())
        Write-Log "    VERIFY.txt written: $($script:VerifyFile)"
    } catch {
        Write-Log ('    could not write VERIFY.txt: ' + $_.Exception.Message) 'WARN'
    }

    if ($get.Ok -and $versionOk) { return $true }
    return $false
}

# ---------------------------------------------------------------------------
# 12.  Uninstall
# ---------------------------------------------------------------------------

function Invoke-Uninstall {
    Write-Step 'Uninstall'

    # stop the pool first so the DLL is not locked
    if (Test-AppPoolExists -Name $AppPoolName) {
        [void](Invoke-AppCmd -Label 'stop apppool' -Arguments @('stop', 'apppool', "/apppool.name:$AppPoolName"))
        Start-Sleep -Seconds 2
    }
    if (Test-WebSiteExists -Name $SiteName) {
        [void](Invoke-AppCmd -Label 'stop site' -Arguments @('stop', 'site', "/site.name:$SiteName"))
    }

    # remove site (also drops the vdir)
    if (Test-WebSiteExists -Name $SiteName) {
        [void](Invoke-AppCmd -Label 'site delete' -Arguments @('delete', 'site', "/site.name:$SiteName"))
        Write-Log "    site $SiteName removed"
    } else {
        Write-Log "    site $SiteName not present"
    }
    if (Test-AppPoolExists -Name $AppPoolName) {
        [void](Invoke-AppCmd -Label 'apppool delete' -Arguments @('delete', 'apppool', "/apppool.name:$AppPoolName"))
        Write-Log "    app pool $AppPoolName removed"
    }

    # firewall
    Remove-FirewallRule -RulePort $script:Port
    if ($script:ChosenPort -ne $script:Port) { Remove-FirewallRule -RulePort $script:ChosenPort }

    # restore the vendor DLL
    $restored = Restore-MedicineFiles

    # optional: delete files
    if ($RemoveFiles) {
        if (Test-Path -LiteralPath $script:InstallDir) {
            if ($script:DryRun) {
                Write-Log "    (whatif) would delete $($script:InstallDir)"
            } else {
                try {
                    Remove-Item -LiteralPath $script:InstallDir -Recurse -Force -ErrorAction Stop
                    Write-Log "    deleted $($script:InstallDir)"
                } catch {
                    Write-Log ('    could not delete install dir: ' + $_.Exception.Message) 'WARN'
                }
            }
        }
    } else {
        Write-Log "    install directory kept: $($script:InstallDir)  (use -Uninstall -RemoveFiles to delete)"
    }

    if (Test-CommandExists 'iisreset') {
        [void](Invoke-Native -FilePath 'iisreset' -Arguments @('/noforce') -OkCodes @(0, 1))
    }

    if ($null -ne $restored -and -not $restored) {
        Add-Result 'Uninstall' 'FAIL' 'DLL restore failed'
        return $false
    }
    Add-Result 'Uninstall' 'OK' 'site, app pool, firewall rule and DLL reverted'
    return $true
}

# ---------------------------------------------------------------------------
