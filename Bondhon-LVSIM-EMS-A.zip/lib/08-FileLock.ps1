﻿# ===========================================================================
#  File-lock handling: detect who holds a file, stop the app pool, force-kill
#  the holding w3wp.exe by PID, then copy with escalating retries.
#
#  This is the module that fixes:
#    "The process cannot access the file ... because it is being used by
#     another process." during the Medicine DLL replacement.
#
#  Strategy (escalating, each step only if the previous one failed):
#    1. Test writability with FileShare.None  - the exact overwrite test.
#    2. Stop LVSIMWebAppPool (if it exists) and wait up to N seconds.
#    3. Find the PID that holds the file and Stop-Process it (force).
#    4. Retry the copy; recycle the pool between attempts.
#    5. Always restart the pool afterwards (finally), even on failure.
#
#  Windows 10 / 11 and Server 2016-2022: uses only appcmd.exe, Get-Process and
#  .NET file APIs - no WebAdministration module, no handle.exe, no Sysinternals.
# ===========================================================================

function Test-FileWritable {
    <#  $true when the file can be opened for exclusive write, i.e. it is safe
        to overwrite. A missing file counts as writable (nothing to lock). #>
    param([Parameter(Mandatory)][string] $Path)
    if (-not (Test-Path -LiteralPath $Path)) { return $true }
    try {
        $fs = [System.IO.File]::Open($Path, [System.IO.FileMode]::Open,
                                     [System.IO.FileAccess]::ReadWrite,
                                     [System.IO.FileShare]::None)
        $fs.Close(); $fs.Dispose()
        return $true
    } catch [System.IO.IOException] {
        return $false
    } catch [System.UnauthorizedAccessException] {
        return $false
    } catch {
        return $false
    }
}

function Get-FileLockingProcess {
    <#  Best-effort: return the processes that are likely holding $Path.
        Primary signal is the IIS worker processes (w3wp) whose command line or
        loaded modules reference the file. Falls back to any process named
        w3wp/dotnet that has the file's directory as its working set.
        Never throws - returns @() when nothing can be determined. #>
    param([Parameter(Mandatory)][string] $Path)

    $found = New-Object System.Collections.ArrayList
    try {
        $candidates = @(Get-Process -Name 'w3wp','dotnet','LVSIMWebCs','iisexpress' -ErrorAction SilentlyContinue)
    } catch { return @() }

    foreach ($p in $candidates) {
        $hit = $false
        # (a) loaded module with the same file name
        try {
            foreach ($m in $p.Modules) {
                if ($m.FileName -and ([string]::Equals($m.FileName, $Path, [StringComparison]::OrdinalIgnoreCase))) { $hit = $true; break }
            }
        } catch { }   # access denied on a 64-bit process from 32-bit PS, etc.

        # (b) command line mentions the file or its folder (WMI, still offline)
        if (-not $hit) {
            try {
                $cl = (Get-CimInstance -ClassName Win32_Process -Filter ("ProcessId=$($p.Id)") -ErrorAction Stop).CommandLine
                if ($cl -and ($cl -match [regex]::Escape((Split-Path -Parent $Path)))) { $hit = $true }
            } catch { }
        }

        if ($hit) {
            [void]$found.Add([pscustomobject]@{
                Id        = $p.Id
                Name      = $p.ProcessName
                StartTime = $(try { $p.StartTime } catch { $null })
            })
        }
    }
    return $found.ToArray()
}

function Invoke-StopProcessForFile {
    <#  Force-stop the processes holding $Path. Returns the count stopped. #>
    param(
        [Parameter(Mandatory)][string] $Path,
        [int] $WaitSeconds = 5
    )
    $procs = @(Get-FileLockingProcess -Path $Path)
    if ($procs.Count -eq 0) { return 0 }

    $stopped = 0
    foreach ($pr in $procs) {
        # never kill the installer itself: compare the PID only.
        # ($PSProcessName does not exist - referencing it under StrictMode throws.)
        if ([int]$pr.Id -eq $PID) { continue }
        try {
            Write-Log ("    force-stopping {0} (PID {1}) which holds the file" -f $pr.Name, $pr.Id) 'WARN'
            Stop-Process -Id $pr.Id -Force -ErrorAction Stop
            $stopped++
        } catch {
            Write-Log ("    could not stop PID {0}: {1}" -f $pr.Id, $_.Exception.Message) 'WARN'
        }
    }
    if ($stopped -gt 0) { Start-Sleep -Seconds $WaitSeconds }
    return $stopped
}

function Wait-FileWritable {
    <#  Poll until the file is writable. Returns $true if it became writable. #>
    param(
        [Parameter(Mandatory)][string] $Path,
        [int] $TimeoutSeconds = 20
    )
    for ($i = 1; $i -le $TimeoutSeconds; $i++) {
        if (Test-FileWritable -Path $Path) { return $true }
        Start-Sleep -Seconds 1
    }
    return (Test-FileWritable -Path $Path)
}

function Invoke-RecycleAppPool {
    <#  Recycle the app pool so the next request reloads bin\*.dll from disk.
        Used between copy retries and after the pool was stopped. #>
    param([string] $Label = 'recycle apppool')
    if (-not (Test-AppPoolExists -Name $AppPoolName)) { return }
    [void](Invoke-AppCmd -Label $Label -Arguments @('recycle', 'apppool', "/apppool.name:$AppPoolName"))
}

function Stop-SiteForFileUpdate {
    <#  Stop LVSIMWebAppPool and wait until $FilePath can be opened for writing.
        Returns a snapshot for Restore-SiteAfterFileUpdate. Never throws. #>
    param([Parameter(Mandatory)][string] $FilePath)

    $snap = [pscustomobject]@{ PoolStopped = $false; PoolExisted = $false; PoolWasStarted = $true }
    if (-not (Test-Path -LiteralPath $FilePath)) { return $snap }
    if (Test-FileWritable -Path $FilePath) { return $snap }

    $snap.PoolExisted = Test-AppPoolExists -Name $AppPoolName
    if ($snap.PoolExisted) {
        try {
            $state = Get-AppCmdText -Arguments @('list', 'apppool', "/apppool.name:$AppPoolName")
            $snap.PoolWasStarted = -not (($state -join ' ') -match 'Stopped')
        } catch { }
        Write-Log "    '$AppPoolName' is holding the DLL - stopping it"
        [void](Invoke-AppCmd -Label 'stop apppool' -Arguments @('stop', 'apppool', "/apppool.name:$AppPoolName"))
        $snap.PoolStopped = $true
    }
    if (Wait-FileWritable -Path $FilePath -TimeoutSeconds 20) { Write-Log '    file released by the app pool' }
    else { Write-Log '    file still locked 20s after stopping the pool' 'WARN' }
    return $snap
}

function Restore-SiteAfterFileUpdate {
    <#  Always put the site back the way it was. Called from every path,
        including failure, so the installer never leaves IIS stopped. #>
    param($Snapshot)
    if ($null -eq $Snapshot) { return }
    if ($Snapshot.PoolStopped -and $Snapshot.PoolExisted) {
        [void](Invoke-AppCmd -Label 'start apppool' -Arguments @('start', 'apppool', "/apppool.name:$AppPoolName"))
        Write-Log "    '$AppPoolName' restarted"
    } elseif ($Snapshot.PoolExisted -and $Snapshot.PoolWasStarted) {
        Invoke-RecycleAppPool -Label 'recycle apppool'
    }
}

function Copy-ItemWithLockHandling {
    <#  The workhorse: copy $Source over $Target, defeating file locks.

        Escalation, per attempt:
          attempt 1  - plain copy
          attempt 2  - stop app pool, wait
          attempt 3  - force-kill holding PID, wait
          attempt 4+ - force-kill + recycle pool, wait

        $Snapshot is restored by Restore-SiteAfterFileUpdate in the caller's
        finally block, so the site always ends up started. #>
    param(
        [Parameter(Mandatory)][string] $Source,
        [Parameter(Mandatory)][string] $Target,
        [int] $MaxAttempts = 5,
        [int] $WaitSeconds = 20
    )

    if ($script:DryRun) {
        Write-Log "    (whatif) would copy $Source -> $Target"
        return $true
    }

    $snap = [pscustomobject]@{ PoolStopped = $false; PoolExisted = $false; PoolWasStarted = $true }

    if (Test-FileWritable -Path $Target) {
        # fast path - nothing is holding it
        try { Copy-Item -LiteralPath $Source -Destination $Target -Force; return $true }
        catch { Write-Log ("    copy failed unexpectedly: " + $_.Exception.Message) 'WARN' }
    } else {
        $snap.PoolExisted = Test-AppPoolExists -Name $AppPoolName
        if ($snap.PoolExisted) {
            $snap.PoolWasStarted = $true
            Write-Log "    '$AppPoolName' is holding the DLL - stopping it"
            [void](Invoke-AppCmd -Label 'stop apppool' -Arguments @('stop', 'apppool', "/apppool.name:$AppPoolName"))
            $snap.PoolStopped = $true
        }
    }

    for ($try = 1; $try -le $MaxAttempts; $try++) {
        # escalate before the later attempts
        if ($try -eq 3) {
            $n = Invoke-StopProcessForFile -Path $Target -WaitSeconds 3
            if ($n -eq 0) { Write-Log '    no holding process could be identified' 'WARN' }
        }
        if ($try -ge 4) {
            Invoke-RecycleAppPool -Label 'recycle apppool (retry)'
            [void](Invoke-StopProcessForFile -Path $Target -WaitSeconds 3)
        }

        if (-not (Wait-FileWritable -Path $Target -TimeoutSeconds $WaitSeconds)) {
            Write-Log ("    attempt {0}: file still locked after {1}s" -f $try, $WaitSeconds) 'WARN'
        }

        try {
            Copy-Item -LiteralPath $Source -Destination $Target -Force
            Write-Log ("    copied on attempt {0}" -f $try) 'OK'
            $script:LastCopySnapshot = $snap
            return $true
        } catch {
            Write-Log ("    copy attempt {0} failed: {1}" -f $try, $_.Exception.Message) 'WARN'
            Start-Sleep -Seconds 2
        }
    }

    $script:LastCopySnapshot = $snap
    return $false
}
