﻿# ===========================================================================
#  IIS: app pool, site, vdir, ACLs, port selection
#  Part of the LVSIM-EMS 4.24 modular installer.
#  Dot-sourced by Install-Bondhon-LVSIM-EMS.ps1 - do not run directly.
#  Requires the master script's scope: $script:Root, Write-Log, Add-Result,
#  Set-StrictMode -Version 2 and $ErrorActionPreference = 'Stop'.
# ===========================================================================

# 9.  IIS configuration (appcmd; WebAdministration as a secondary check)
# ---------------------------------------------------------------------------

function Get-AppCmdPath {
    $sr = $env:SystemRoot; if ([string]::IsNullOrEmpty($sr)) { $sr = 'C:\Windows' }
    $p = Join-Path $sr 'System32\inetsrv\appcmd.exe'
    if (Test-Path -LiteralPath $p) { return $p }
    return $null
}

function Invoke-AppCmd {
    param([string[]] $Arguments, [string] $Label = '', [int[]] $OkCodes = @(0))
    $appcmd = Get-AppCmdPath
    if ($null -eq $appcmd) { return 127 }
    return (Invoke-Native -FilePath $appcmd -Arguments $Arguments -Label $Label -OkCodes $OkCodes)
}

function Get-AppCmdText {
    param([string[]] $Arguments)
    $appcmd = Get-AppCmdPath
    if ($null -eq $appcmd) { return @() }
    try {
        $out = & $appcmd @Arguments 2>&1
        return $out
    } catch {
        return @()
    }
}

function Test-AppPoolExists {
    param([string] $Name)
    if (Test-CommandExists 'Get-WebAppPoolState') {
        try { $null = Get-WebAppPoolState -Name $Name -ErrorAction Stop; return $true } catch { }
    }
    $t = Get-AppCmdText -Arguments @('list', 'apppool', $Name)
    return ($t.Count -gt 0 -and ([string]($t[0])).Length -gt 0)
}

# ---------------------------------------------------------------------------
#  Release the lock on bin\HardLockWrapper.dll.
#
#  ASP.NET loads the licence assembly into w3wp.exe on the first request, and a
#  running worker process keeps the file mapped. A plain Copy-Item then fails
#  with "being used by another process" - which is exactly what happened on a
#  machine where LVSIM-EMS was already being served by IIS (or had just been
#  started by the MSI). Stop the pool, wait for the file to become writable,
#  and restart it afterwards so the site is live again.
#
#  Returns $true if the file is writable (or does not exist yet).
# ---------------------------------------------------------------------------
function Test-WebSiteExists {
    param([string] $Name)
    if (Test-CommandExists 'Get-Website') {
        try { $null = Get-Website -Name $Name -ErrorAction Stop; return $true } catch { }
    }
    $t = Get-AppCmdText -Arguments @('list', 'site', $Name)
    return ($t.Count -gt 0 -and ([string]($t[0])).Length -gt 0)
}

function Get-UsedTcpPorts {
    $used = New-Object 'System.Collections.Generic.HashSet[int]'
    $appcmd = Get-AppCmdPath
    if ($null -ne $appcmd) {
        $lines = Get-AppCmdText -Arguments @('list', 'site', '/text:bindings')
        foreach ($line in $lines) {
            foreach ($m in [regex]::Matches([string]$line, ':(?<p>\d{1,5}):')) {
                $v = 0
                if ([int]::TryParse($m.Groups['p'].Value, [ref]$v)) { [void]$used.Add($v) }
            }
        }
    }
    if (Test-CommandExists 'Get-NetTCPConnection') {
        try {
            foreach ($c in (Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue)) {
                [void]$used.Add([int]$c.LocalPort)
            }
        } catch { }
    } else {
        try {
            $ns = & (Join-Path $env:SystemRoot 'System32\netstat.exe') -ano -p tcp 2>$null
            foreach ($l in $ns) {
                $s = [string]$l
                if ($s -match 'LISTENING') {
                    $parts = @($s -split '\s+' | Where-Object { $_ -ne '' })
                    if ($parts.Count -ge 2) {
                        $m = [regex]::Match($parts[1], ':(?<p>\d{1,5})$')
                        $v = 0
                        if ($m.Success -and [int]::TryParse($m.Groups['p'].Value, [ref]$v)) { [void]$used.Add($v) }
                    }
                }
            }
        } catch { }
    }
    return $used
}

function Resolve-SitePort {
    param([int] $Preferred)
    if ($script:DryRun) { return $Preferred }
    $used = Get-UsedTcpPorts
    if (-not $used.Contains($Preferred)) { return $Preferred }
    Write-Log "    port $Preferred is already in use - searching for the next free port" 'WARN'
    for ($p = $Preferred + 1; $p -le 65535 -and $p -lt ($Preferred + 400); $p++) {
        if (-not $used.Contains($p)) {
            Write-Log "    selected free port $p"
            return $p
        }
    }
    return 0
}

function Set-FolderAcl {
    param([string] $Path, [string] $Identity, [string] $Rights, [string] $Label)
    if (-not (Test-Path -LiteralPath $Path)) {
        Write-Log "    ACL: $Path does not exist - skipped ($Label)" 'WARN'
        return $false
    }
    $icacls = Join-Path $env:SystemRoot 'System32\icacls.exe'
    if (-not (Test-Path -LiteralPath $icacls)) {
        Write-Log '    icacls.exe not found' 'WARN'
        return $false
    }
    # grant is idempotent in icacls: re-granting the same ACE does not duplicate it
    $rc = Invoke-Native -FilePath $icacls -Label "icacls $Label" `
          -Arguments @($Path, '/grant', ('"' + $Identity + ':' + $Rights + '"'), '/T', '/C', '/Q') `
          -OkCodes @(0)
    return ($rc -eq 0)
}

function Configure-Iis {
    Write-Step "IIS: app pool '$AppPoolName', site '$SiteName' on port $($script:ChosenPort), vdir /$VdirName"

    $appcmd = Get-AppCmdPath
    if ($null -eq $appcmd) {
        if ($script:DryRun) {
            Add-Result 'IIS site' 'SKIP' '-WhatIf: appcmd.exe not reachable on this preview host'
            return $true
        }
        Add-Result 'IIS site' 'FAIL' 'appcmd.exe not found - IIS management tools are not installed'
        return $false
    }
    if (-not (Test-Path -LiteralPath $script:InstallDir)) {
        if ($script:DryRun) {
            Add-Result 'IIS site' 'SKIP' "-WhatIf: install dir not created yet ($($script:InstallDir))"
            return $true
        }
        Add-Result 'IIS site' 'FAIL' "install directory missing: $($script:InstallDir)"
        return $false
    }

    # ---- app pool -----------------------------------------------------
    if (Test-AppPoolExists -Name $AppPoolName) {
        Write-Log "    app pool $AppPoolName exists - reusing"
        [void](Invoke-AppCmd -Label 'apppool set' -Arguments @(
            'set', 'apppool', "/apppool.name:$AppPoolName",
            '/managedRuntimeVersion:v4.0',
            '/managedPipelineMode:Integrated',
            '/enable32BitAppOnWin64:true'))
    } else {
        [void](Invoke-AppCmd -Label 'apppool add' -OkCodes @(0) -Arguments @(
            'add', 'apppool', "/name:$AppPoolName",
            '/managedRuntimeVersion:v4.0',
            '/managedPipelineMode:Integrated',
            '/enable32BitAppOnWin64:true'))
        # Belt and braces: 'add' does not always honour enable32BitAppOnWin64.
        [void](Invoke-AppCmd -Label 'apppool set 32bit' -Arguments @(
            'set', 'apppool', "/apppool.name:$AppPoolName", '/enable32BitAppOnWin64:true'))
    }
    if (Test-AppPoolExists -Name $AppPoolName) {
        Write-Log "    app pool $AppPoolName present (.NET v4.0, Integrated, 32-bit enabled)"
    } else {
        Write-Log "    app pool $AppPoolName could NOT be created" 'FAIL'
    }

    # ---- site ---------------------------------------------------------
    $siteExisted = Test-WebSiteExists -Name $SiteName
    if ($siteExisted) {
        Write-Log "    site $SiteName already exists - reconciling"
        # Remove every binding on the site except the one we want, then add ours.
        $binds = Get-AppCmdText -Arguments @('list', 'site', $SiteName, '/text:bindings')
        foreach ($b in $binds) {
            $txt = ([string]$b).Trim()
            if ($txt.Length -eq 0) { continue }
            $m = [regex]::Match($txt, '^(?<proto>[a-z]+)/(?<ip>[^:]*):(?<port>\d+):(?<host>.*)$')
            if (-not $m.Success) { continue }
            $bp = 0
            [void][int]::TryParse($m.Groups['port'].Value, [ref]$bp)
            $want = "http/*:$($script:ChosenPort):"
            if ($bp -ne $script:ChosenPort) {
                Write-Log "    removing stale binding $txt"
                [void](Invoke-AppCmd -Label 'binding delete' -Arguments @(
                    'set', 'site', "/site.name:$SiteName",
                    ('-bindings.[protocol=''' + $m.Groups['proto'].Value + ''',bindingInformation=''' + $m.Groups['ip'].Value + ':' + $m.Groups['port'].Value + ':' + $m.Groups['host'].Value + ''']')))
            }
        }
        $hasWanted = $false
        foreach ($b in (Get-AppCmdText -Arguments @('list', 'site', $SiteName, '/text:bindings'))) {
            if (([string]$b) -match ('\*:' + $script:ChosenPort + ':')) { $hasWanted = $true }
        }
        if (-not $hasWanted) {
            [void](Invoke-AppCmd -Label 'binding add' -Arguments @(
                'set', 'site', "/site.name:$SiteName", ('/+bindings.[protocol=''http'',bindingInformation=''*:' + $script:ChosenPort + ':'' ]')))
        }
        [void](Invoke-AppCmd -Label 'site physicalPath/apppool' -Arguments @(
            'set', 'site', "/site.name:$SiteName",
            ('/physicalPath:"' + $script:InstallDir + '"'),
            "/[path='/'].applicationPool:$AppPoolName"))
    } else {
        [void](Invoke-AppCmd -Label 'site add' -OkCodes @(0) -Arguments @(
            'add', 'site', "/name:$SiteName",
            ('/bindings:http/*:' + $script:ChosenPort + ':'),
            ('/physicalPath:"' + $script:InstallDir + '"')))
        [void](Invoke-AppCmd -Label 'site apppool' -Arguments @(
            'set', 'app', "/app.name:$SiteName/", "/applicationPool:$AppPoolName"))
    }

    if (-not (Test-WebSiteExists -Name $SiteName)) {
        Add-Result 'IIS site' 'FAIL' "site $SiteName could not be created on port $($script:ChosenPort)"
        return $false
    }

    # ---- virtual directory /LVSIMWeb -> install dir --------------------
    $appName = "$SiteName/"
    $vdirPath = "/$VdirName"
    $existing = Get-AppCmdText -Arguments @('list', 'vdir', "$SiteName$vdirPath")
    if ($existing.Count -gt 0 -and ([string]($existing[0])).Length -gt 0) {
        Write-Log "    vdir $VdirName exists - repointing"
        [void](Invoke-AppCmd -Label 'vdir set' -Arguments @(
            'set', 'vdir', "/vdir.name:$SiteName$vdirPath",
            ('/physicalPath:"' + $script:InstallDir + '"')))
    } else {
        [void](Invoke-AppCmd -Label 'vdir add' -Arguments @(
            'add', 'vdir', "/app.name:$appName", "/path:$vdirPath",
            ('/physicalPath:"' + $script:InstallDir + '"')))
    }
    [void](Invoke-AppCmd -Label 'app apppool' -Arguments @(
        'set', 'app', "/app.name:$appName", "/applicationPool:$AppPoolName"))

    # ---- default document --------------------------------------------
    $def = Get-AppCmdText -Arguments @('list', 'config', "$SiteName$vdirPath", '/section:defaultDocument')
    $hasDefault = $false
    foreach ($l in $def) { if (([string]$l) -match 'global\.aspx') { $hasDefault = $true } }
    if ($hasDefault) {
        Write-Log '    default document global.aspx already configured'
    } else {
        [void](Invoke-AppCmd -Label 'defaultDocument' -Arguments @(
            'set', 'config', "$SiteName$vdirPath", '/section:defaultDocument',
            "/+files.[value='global.aspx']"))
        Write-Log '    default document global.aspx added'
    }

    # ---- MIME maps ----------------------------------------------------
    # The shipped Web.config already declares .sdt / .lvsimweb / .woff.  Adding
    # them again at site level creates duplicate entries and a 500, so only add
    # what is missing from both the app's Web.config and the site config.
    $cfgPath = Join-Path $script:InstallDir 'Web.config'
    $cfgText = ''
    if (Test-Path -LiteralPath $cfgPath) {
        $cfgText = [System.IO.File]::ReadAllText($cfgPath)
    }
    $mimes = @(
        @{ Ext = '.sdt';      Type = 'application/octet-stream' },
        @{ Ext = '.lvsimweb'; Type = 'application/octet-stream' },
        @{ Ext = '.woff';     Type = 'application/font-woff' }
    )
    foreach ($m in $mimes) {
        if ($cfgText.IndexOf($m.Ext, [System.StringComparison]::OrdinalIgnoreCase) -ge 0) {
            Write-Log "    MIME $($m.Ext) declared in Web.config - no site-level change"
            continue
        }
        [void](Invoke-AppCmd -Label "mime $($m.Ext)" -Arguments @(
            'set', 'config', "$SiteName$vdirPath", '/section:staticContent',
            ("/+[fileExtension='" + $m.Ext + "',mimeType='" + $m.Type + "']")))
        Write-Log "    MIME $($m.Ext) added at site level"
    }

    # ---- ACLs ---------------------------------------------------------
    $poolId  = "IIS AppPool\$AppPoolName"
    $targets = @(
        @{ Dir = $script:InstallDir; Id = 'IIS_IUSRS';     Rights = '(OI)(CI)(RX)'; Label = 'app read' },
        @{ Dir = (Join-Path $script:InstallDir 'save'); Id = $poolId; Rights = '(OI)(CI)(M)'; Label = 'save write' },
        @{ Dir = (Join-Path $script:InstallDir 'log');  Id = $poolId; Rights = '(OI)(CI)(M)'; Label = 'log write' },
        @{ Dir = (Join-Path $script:InstallDir 'load'); Id = $poolId; Rights = '(OI)(CI)(M)'; Label = 'load write' },
        @{ Dir = (Join-Path $script:InstallDir 'save'); Id = 'IIS_IUSRS'; Rights = '(OI)(CI)(M)'; Label = 'save IIS_IUSRS' },
        @{ Dir = (Join-Path $script:InstallDir 'log');  Id = 'IIS_IUSRS'; Rights = '(OI)(CI)(M)'; Label = 'log IIS_IUSRS' },
        @{ Dir = (Join-Path $script:InstallDir 'load'); Id = 'IIS_IUSRS'; Rights = '(OI)(CI)(M)'; Label = 'load IIS_IUSRS' }
    )
    $aclFail = 0
    foreach ($t in $targets) {
        if (-not (Set-FolderAcl -Path $t.Dir -Identity $t.Id -Rights $t.Rights -Label $t.Label)) {
            $aclFail++
        }
    }
    if ($aclFail -eq 0) {
        Write-Log '    ACLs applied to save\, log\, load\ and the app root'
    } else {
        Write-Log "    $aclFail ACL operation(s) failed" 'WARN'
    }

    # ---- start --------------------------------------------------------
    [void](Invoke-AppCmd -Label 'start apppool' -Arguments @('start', 'apppool', "/apppool.name:$AppPoolName"))
    [void](Invoke-AppCmd -Label 'start site'    -Arguments @('start', 'site', "/site.name:$SiteName"))

    $detail = "site $SiteName / $appName$VdirName on http://localhost:$($script:ChosenPort)"
    if ($aclFail -gt 0) {
        Add-Result 'IIS site' 'WARN' "$detail (ACL warnings)"
        return $true
    }
    Add-Result 'IIS site' 'OK' $detail
    return $true
}

function Update-InternetShortcut {
    <#  Rewrites the single place the port is written down. #>
    param([int] $NewPort)
    $url = Join-Path $script:InstallDir 'LVSIM-EMS.url'
    if (-not (Test-Path -LiteralPath $url)) {
        Write-Log "    LVSIM-EMS.url not found at $url - skipped" 'WARN'
        return $false
    }
    $newTarget = "http://localhost:$NewPort/$VdirName/global.aspx"
    if ($script:DryRun) {
        Write-Log "    (whatif) would set LVSIM-EMS.url URL=$newTarget"
        return $true
    }
    $lines = [System.IO.File]::ReadAllLines($url)
    $out = New-Object System.Collections.ArrayList
    $changed = $false
    foreach ($l in $lines) {
        if ($l -match '^URL=') {
            if ($l -ne "URL=$newTarget") {
                [void]$out.Add("URL=$newTarget")
                $changed = $true
            } else {
                [void]$out.Add($l)
            }
        } else {
            [void]$out.Add($l)
        }
    }
    if ($changed) {
        [System.IO.File]::WriteAllLines($url, $out.ToArray())
        Write-Log "    LVSIM-EMS.url -> $newTarget"
    } else {
        Write-Log "    LVSIM-EMS.url already points at $newTarget"
    }
    return $true
}

# ---------------------------------------------------------------------------
