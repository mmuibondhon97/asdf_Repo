﻿# ===========================================================================
#  Summary: banner + result table
#  Part of the LVSIM-EMS 4.24 modular installer.
#  Dot-sourced by Install-Bondhon-LVSIM-EMS.ps1 - do not run directly.
#  Requires the master script's scope: $script:Root, Write-Log, Add-Result,
#  Set-StrictMode -Version 2 and $ErrorActionPreference = 'Stop'.
# ===========================================================================

# 13.  Banner + summary
# ---------------------------------------------------------------------------

function Write-Banner {
    Write-Log ''
    Write-Log '  ============================================================'
    Write-Log '   BONDHON  -  LVSIM-EMS Web 4.24  offline deploy'
    Write-Log '   LAB-VOLT / Festo Didactic  |  ASP.NET 4.5.2  |  IIS'
    Write-Log '  ============================================================'
    Write-Log ("   package : " + $script:Root)
    Write-Log ("   log     : " + $script:LogFile)
    if ($script:DryRun) { Write-Log '   mode    : DRY RUN (-WhatIf) - nothing will be changed' }
}

function Write-Summary {
    Write-Log ''
    Write-Log '  ------------------------------------------------------------'
    Write-Log '   SUMMARY'
    Write-Log '  ------------------------------------------------------------'
    foreach ($r in $script:Results) {
        $pad = $r.Step.PadRight(26)
        $txt = "   {0} {1,-5} {2}" -f $pad, $r.Status, $r.Detail
        switch ($r.Status) {
            'OK'   { Write-Log $txt 'OK' }
            'FAIL' { Write-Log $txt 'FAIL' }
            'WARN' { Write-Log $txt 'WARN' }
            default { Write-Host $txt }
        }
    }
    Write-Log '  ------------------------------------------------------------'
    if (-not $Uninstall) {
        Write-Log ("   open: http://localhost:{0}/{1}/global.aspx" -f $script:ChosenPort, $VdirName)
        Write-Log  '        (from another machine use the server name/IP and the same port)'
    }
    Write-Log ("   log : " + $script:LogFile)
    Write-Log ''
}

# ---------------------------------------------------------------------------
