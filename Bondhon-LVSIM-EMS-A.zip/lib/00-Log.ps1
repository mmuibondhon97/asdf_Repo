﻿# ===========================================================================
#  Shared state, logging and result collection.
#  Dot-sourced FIRST by the master (after init) - every other module uses these.
# ===========================================================================

function Write-Log {
    param([string] $Message, [ValidateSet('INFO','OK','WARN','FAIL')] [string] $Level = 'INFO')
    $stamp = Get-Date -Format 'HH:mm:ss'
    $line  = "$stamp [$Level] $Message"
    switch ($Level) {
        'FAIL' { try { [System.IO.File]::AppendAllText($script:LogFile, $line + [Environment]::NewLine) } catch { } ; Write-Host $line -ForegroundColor Red }
        'WARN' { try { [System.IO.File]::AppendAllText($script:LogFile, $line + [Environment]::NewLine) } catch { } ; Write-Host $line -ForegroundColor Yellow }
        'OK'   { try { [System.IO.File]::AppendAllText($script:LogFile, $line + [Environment]::NewLine) } catch { } ; Write-Host $line -ForegroundColor Green }
        default{ try { [System.IO.File]::AppendAllText($script:LogFile, $line + [Environment]::NewLine) } catch { } ; Write-Host $line }
    }
    if ($Level -eq 'FAIL') { [void]$script:Failures.Add($Message) }
    if ($Level -eq 'WARN') { [void]$script:Warnings.Add($Message) }
}

function Write-Step {
    param([string] $Title)
    Write-Host ''
    Write-Host ("--- $Title") -ForegroundColor Cyan
    try { [System.IO.File]::AppendAllText($script:LogFile, ("`n--- $Title" + [Environment]::NewLine)) } catch { }
}

function Add-Result {
    param([string] $Step, [string] $Status, [string] $Detail = '')
    [void]$script:Results.Add([pscustomobject]@{ Step = $Step; Status = $Status; Detail = $Detail })
    $lvl = switch ($Status) { 'OK' { 'OK' } 'WARN' { 'WARN' } 'FAIL' { 'FAIL' } default { 'INFO' } }
    Write-Log ("  [ $Status ] $Step" + $(if ($Detail) { " - $Detail" } else { '' })) $lvl
}

function Test-IsAdmin {
    $id = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $pr = New-Object System.Security.Principal.WindowsPrincipal($id)
    return $pr.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Test-CommandExists {
    param([string] $Name)
    return ($null -ne (Get-Command -Name $Name -ErrorAction SilentlyContinue))
}
