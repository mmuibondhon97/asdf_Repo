﻿# ===========================================================================
#  Preflight: payload manifest + hash verification + environment assertions
#  Part of the LVSIM-EMS 4.24 modular installer.
#  Dot-sourced by Install-Bondhon-LVSIM-EMS.ps1 - do not run directly.
#  Requires the master script's scope: $script:Root, Write-Log, Add-Result,
#  Set-StrictMode -Version 2 and $ErrorActionPreference = 'Stop'.
# ===========================================================================

function Get-PayloadManifest {
    # Sizes were measured from the media; SHA-256 is the authoritative check.
    $items = @(
        @{ Rel = 'LVSIM-EMS Web\LVSIM-EMS.msi';                       Size = 1573888;   Hash = 'cfc1e0cabde32a9f3cf48e56ee162f89a5642c4ba63c7fb9c0c9c00eaa95ba80'; Need = (-not $SkipAppInstall) },
        @{ Rel = 'LVSIM-EMS Web\Data1.cab';                           Size = 156250460; Hash = '3613a08e7e7ea5e480a668816ca1e193e5e85bd13847c85e03b662c405cc319e'; Need = (-not $SkipAppInstall) },
        @{ Rel = 'LVSIM-EMS Web\ISSetup.dll';                         Size = 2445553;   Hash = 'b914c61c9c701c561d7b489fd9b1432dcc1ceefdae3f8286bfba53ad01b85771'; Need = (-not $SkipAppInstall) },
        @{ Rel = 'LVSIM-EMS Web\setup.exe';                           Size = 3813967;   Hash = '85a6e8d4c767ce36624d4f31628a87fb6c44999cb69b8f15995ea74900e02812'; Need = (-not $SkipAppInstall) },
        @{ Rel = 'Prerequisites\dotnetfx45_full_x86_x64.exe';         Size = 50352408;  Hash = 'a04d40e217b97326d46117d961ec4eda455e087b90637cb33dd6cc4a2c228d83'; Need = (-not $SkipPrereqs) },
        @{ Rel = 'Prerequisites\vc_redist.x86.exe';                   Size = 13767776;  Hash = 'fdd1e1f0dcae2d0aa0720895eff33b927d13076e64464bb7c7e5843b7667cd14'; Need = (-not $SkipPrereqs) },
        @{ Rel = 'Prerequisites\haspdinst.exe';                       Size = 24621064;  Hash = 'c058e09c86ccdd6d46b714cd4803841bea5067182a2c631b2fba2acb22d18f73'; Need = $false }
    )
        @{ Rel = 'Medicine\HardLockWrapper.dll';                  Size = 5120; Hash = 'bb1eb57661078c1fa6933ce8833e68ab222b677aecc8ffab2f74a16da63e909f'; Need = $true }
        @{ Rel = 'Medicine\hasp_windows.dll';                     Size = 86591; Hash = '6cf3e282317b9aaa62ff2875205eaf5c3630ff1b9e1a4733627f0af0701cc7f8'; Need = $true }
        @{ Rel = 'Medicine\hardlock.ini';                         Size = 1287; Hash = '66a5780b1174d1dbfac05b61e0feea6824016fa5daa23783b26157005a8eb1c4'; Need = $true }
    if ($Locale -eq 'es') {
        $items += @{ Rel = 'LVSIM-EMS Web\1034.mst'; Size = 94208; Hash = '46baff15cdc5a37248a0f79109001012b4fa61cf2240d0accdd84f6b98d54549'; Need = $true }
    }
    if ($Locale -eq 'fr') {
        $items += @{ Rel = 'LVSIM-EMS Web\3084.mst'; Size = 94208; Hash = '9c7987cb3a6cb1a19a038902151b40e978c3ef24460f9dd202632d33b5963203'; Need = $true }
    }
    return $items
}

function Test-PayloadHashes {
    param([switch] $IncludeOptional)
    $bad = New-Object System.Collections.ArrayList
    # @() keeps this iterable even if the function returns one scalar item.
    $manifest = @(Get-PayloadManifest)
    $hasher = $null
    if (Test-CommandExists 'Get-FileHash') {
        $hasher = $true
    } else {
        Write-Log 'Get-FileHash unavailable (PowerShell < 4) - size-only verification' 'WARN'
    }
    foreach ($item in $manifest) {
        $need = [bool]$item.Need
        if ($IncludeOptional) { $need = $true }
        if (-not $need) { continue }
        $full = Join-Path $script:Root $item.Rel
        if (-not (Test-Path -LiteralPath $full)) {
            [void]$bad.Add("MISSING: $($item.Rel)")
            continue
        }
        $len = (Get-Item -LiteralPath $full).Length
        if ($len -ne [int64]$item.Size) {
            [void]$bad.Add("SIZE: $($item.Rel) expected $($item.Size) got $len")
            continue
        }
        if ($hasher) {
            $h = (Get-FileHash -LiteralPath $full -Algorithm SHA256).Hash.ToLowerInvariant()
            if ($h -ne $item.Hash) {
                [void]$bad.Add("HASH: $($item.Rel) expected $($item.Hash) got $h")
            }
        }
    }
    # Unary comma: return the ArrayList ITSELF. Plain 'return $bad' unrolls an
    # empty collection to $null, and $null.Count throws under StrictMode 2.
    return ,$bad
}

function Assert-Preflight {
    Write-Step 'Preflight'
    $fatal = New-Object System.Collections.ArrayList

    # -- OS family ------------------------------------------------------
    # $IsWindows is an automatic variable that only exists on PS6+ and is
    # CONSTANT there, so it must never be assigned. Probe it read-only.
    $onWindowsOs = $true
    $autoIsWindows = Get-Variable -Name 'IsWindows' -ValueOnly -ErrorAction SilentlyContinue
    if ($null -ne $autoIsWindows) { $onWindowsOs = [bool]$autoIsWindows }
    if (-not $onWindowsOs) {
        [void]$fatal.Add('This host is not Windows: IIS/.NET Framework/MSI steps cannot run.')
    }
    $osVersion = ''
    try {
        $os = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction Stop
        $osVersion = "$($os.Caption) $($os.Version)"
    } catch {
        try {
            $osVersion = [string][System.Environment]::OSVersion.Version
        } catch { $osVersion = 'unknown' }
    }
    Write-Log "    OS: $osVersion"

    # -- PowerShell version ---------------------------------------------
    # $PSVersionTable does not exist on PowerShell 2.0, so fall back to
    # $host.Version (present in 1.0 - 7.x) instead of tripping over StrictMode.
    if (Get-Variable -Name PSVersionTable -ErrorAction SilentlyContinue) {
        $psv = $PSVersionTable.PSVersion
    } else {
        $psv = $host.Version
    }
    $edition = if (Get-Variable -Name PSVersionTable -ErrorAction SilentlyContinue) { $PSVersionTable.PSEdition } else { 'Desktop' }
    Write-Log "    PowerShell: $psv  (edition=$edition)"
    if ($psv.Major -lt 5) {
        [void]$fatal.Add("Windows PowerShell 5.1 or newer required (found $psv).")
    }
    if ($psv.Major -eq 5 -and $psv.Minor -lt 1) {
        Write-Log "    PowerShell 5.1 recommended (found $psv); continuing." 'WARN'
    }

    # -- admin ----------------------------------------------------------
    $admin = Test-IsAdmin
    Write-Log "    Elevated: $admin"
    if (-not $admin) { [void]$fatal.Add('Administrator rights are required.') }

    # -- architecture ---------------------------------------------------
    $x64 = $env:PROCESSOR_ARCHITECTURE -eq 'AMD64' -or $env:PROCESSOR_ARCHITEW6432 -eq 'AMD64'
    Write-Log "    OS x64: $x64  (app is x86; pool will be 32-bit enabled)"

    # -- install dir sanity ---------------------------------------------
    if ([string]::IsNullOrEmpty($script:InstallDir)) {
        # $env:ProgramFiles is empty off-Windows; fall back so preflight can
        # still report cleanly instead of throwing on a null Join-Path.
        $pf = $env:ProgramFiles
        if ([string]::IsNullOrEmpty($pf)) {
            $sysDrive = $env:SystemDrive
            if ([string]::IsNullOrEmpty($sysDrive)) { $sysDrive = $env:HOMEDRIVE }
            if ([string]::IsNullOrEmpty($sysDrive)) { $sysDrive = '/' }
            $pf = Join-Path $sysDrive 'Program Files'
            if ($onWindowsOs -and $x64) {
                $pfx = Join-Path $sysDrive 'Program Files (x86)'
                if (Test-Path -LiteralPath $pfx) { $pf = $pfx }
            }
        } elseif ($onWindowsOs -and $x64 -and $pf -notmatch '\(x86\)') {
            $pfx = Join-Path $env:SystemDrive 'Program Files (x86)'
            if (Test-Path -LiteralPath $pfx) { $pf = $pfx }
        }
        $script:InstallDir = Join-Path $pf 'Festo Didactic/LVSIM-EMS'
    }
    if ($script:InstallDir.StartsWith('\\')) {
        [void]$fatal.Add("UNC install paths are not supported for IIS content roots: $($script:InstallDir)")
    }
    Write-Log "    Target: $($script:InstallDir)"

    # -- disk space -----------------------------------------------------
    try {
        $probe = $script:InstallDir
        while ($probe.Length -gt 3 -and -not (Test-Path -LiteralPath $probe)) {
            $probe = Split-Path -Parent $probe
            if ([string]::IsNullOrEmpty($probe)) { break }
        }
        if ([string]::IsNullOrEmpty($probe)) { $probe = $env:SystemDrive + '\' }
        $driveName = (Get-Item -LiteralPath $probe).PSDrive.Name
        $freeMb = [math]::Round((Get-PSDrive -Name $driveName).Free / 1MB)
        Write-Log "    Free space on ${driveName}: $freeMb MB (need $MinFreeMB MB)"
        if ($freeMb -lt $MinFreeMB) {
            [void]$fatal.Add("Insufficient free space on ${driveName}: ${freeMb} MB < ${MinFreeMB} MB.")
        }
    } catch {
        Write-Log ('    disk space probe failed: ' + $_.Exception.Message) 'WARN'
    }

    # -- required payload bytes -----------------------------------------
    $bad = Test-PayloadHashes
    if ($bad.Count -gt 0) {
        foreach ($b in $bad) { [void]$fatal.Add($b) }
        Write-Log '    Payload problems:' 'FAIL'
        foreach ($b in $bad) { Write-Log "      - $b" 'FAIL' }
    } else {
        Write-Log '    All required payload files present with expected size + SHA-256'
    }

    # -- the app tree we may fall back to -------------------------------
    if (-not $SkipAppInstall) {
        $marker = Join-Path $script:DirAppSource 'Web.config'
        if (-not (Test-Path -LiteralPath $marker)) {
            Write-Log "    AppSource fallback tree not present at $($script:DirAppSource) (MSI path only)" 'WARN'
        }
    }

    if ($fatal.Count -gt 0) {
        Write-Log ''
        Write-Log 'PREFLIGHT FAILED - nothing was changed:' 'FAIL'
        foreach ($f in $fatal) { Write-Log "  * $f" 'FAIL' }
        Add-Result 'Preflight' 'FAIL' ($fatal -join ' | ')
        return $false
    }
    Add-Result 'Preflight' 'OK' "OS=$osVersion; PS=$psv; admin=$admin"
    return $true
}

# ---------------------------------------------------------------------------
