﻿# ===========================================================================
#  Prerequisites: IIS features, ASP.NET, .NET 4.5.2, VC++ 2013, HASP driver
#  Part of the LVSIM-EMS 4.24 modular installer.
#  Dot-sourced by Install-Bondhon-LVSIM-EMS.ps1 - do not run directly.
#  Requires the master script's scope: $script:Root, Write-Log, Add-Result,
#  Set-StrictMode -Version 2 and $ErrorActionPreference = 'Stop'.
# ===========================================================================

# 3.  Windows optional features (offline, no Web Platform Installer)
# ---------------------------------------------------------------------------

$script:IisFeatures = @(
    'IIS-WebServerRole',
    'IIS-WebServer',
    'IIS-CommonHttpFeatures',
    'IIS-DefaultDocument',
    'IIS-StaticContent',
    'IIS-HttpErrors',
    'IIS-ApplicationDevelopment',
    'IIS-NetFxExtensibility45',
    'IIS-ASPNET45',
    'IIS-ISAPIExtensions',
    'IIS-ISAPIFilter',
    'IIS-WebServerManagementTools',
    'IIS-ManagementConsole'
)

function Get-FeatureState {
    param([string] $Name)
    try {
        $f = Get-WindowsOptionalFeature -Online -FeatureName $Name -ErrorAction Stop
        return [string]$f.State
    } catch {
        return 'Unknown'
    }
}

function Enable-OptionalFeatureEx {
    <#  Tries Enable-WindowsOptionalFeature, then DISM.exe, then pkgmgr legacy.
        Returns $true when the feature reports Enabled afterwards. #>
    param([string] $Name, [switch] $NonFatal)

    $state = Get-FeatureState -Name $Name
    if ($state -eq 'Enabled') {
        Write-Log "      $Name : already Enabled"
        return $true
    }

    $done = $false
    if (Test-CommandExists 'Enable-WindowsOptionalFeature') {
        try {
            if (-not $script:DryRun) {
                $r = Enable-WindowsOptionalFeature -Online -FeatureName $Name -All -NoRestart -ErrorAction Stop
                Write-Log "      $Name : Enable-WindowsOptionalFeature returned RestartNeeded=$($r.RestartNeeded)"
            } else {
                Write-Log "      (whatif) Enable-WindowsOptionalFeature -Online -FeatureName $Name -All -NoRestart"
            }
            $done = $true
        } catch {
            Write-Log "      $Name : cmdlet failed ($($_.Exception.Message)) - trying DISM.exe" 'WARN'
        }
    }

    if (-not $done) {
        $sysRoot2 = $env:SystemRoot; if ([string]::IsNullOrEmpty($sysRoot2)) { $sysRoot2 = 'C:\Windows' }
        $dism = Join-Path $sysRoot2 'System32\dism.exe'
        if (Test-Path -LiteralPath $dism) {
            $rc = Invoke-Native -FilePath $dism -Label "dism $Name" `
                  -Arguments @('/online', '/enable-feature', "/featurename:$Name", '/all', '/norestart') `
                  -OkCodes @(0, 3010)
            if ($rc -eq 0 -or $rc -eq 3010) { $done = $true }
        } else {
            Write-Log "      $Name : dism.exe not found" 'WARN'
        }
    }

    # Trust the post-state over the return code when we can read it.
    if (-not $script:DryRun) {
        $after = Get-FeatureState -Name $Name
        if ($after -eq 'Enabled') {
            Write-Log "      $Name : now Enabled"
            return $true
        }
        if ($after -eq 'Unknown') {
            # Cannot read state (rare SKU) - fall back to the action result.
            return $done
        }
        Write-Log "      $Name : still '$after'" 'WARN'
        # Non-fatal features are reported as WARN by the caller; returning
        # $true keeps them out of the critical-missing list.
        if ($NonFatal) { return $true }
        return $false
    }
    return $done
}

function Install-IisFeatures {
    Write-Step 'Offline IIS features'
    if (-not ([System.Environment]::OSVersion.Platform -eq 'Win32NT')) {
        # A skip is NOT a failure: returning $false here made the run abort with
        # 'A required prerequisite failed' even though nothing had failed.
        Add-Result 'IIS features' 'SKIP' 'not Windows'
        return $true
    }
    $missing = New-Object System.Collections.ArrayList
    foreach ($f in $script:IisFeatures) {
        # IIS-ASPNET45 is missing on a few SKUs; it must never abort the run.
        $nonFatal = ($f -eq 'IIS-ASPNET45' -or $f -eq 'IIS-NetFxExtensibility45')
        if (-not (Enable-OptionalFeatureEx -Name $f -NonFatal:$nonFatal)) {
            [void]$missing.Add($f)
        }
    }
    if ($missing.Count -eq 0) {
        Add-Result 'IIS features' 'OK' 'all 13 features enabled'
        return $true
    }
    $criticalMissing = @($missing | Where-Object { $_ -ne 'IIS-ASPNET45' -and $_ -ne 'IIS-NetFxExtensibility45' })
    if ($criticalMissing.Count -eq 0) {
        Add-Result 'IIS features' 'WARN' ("non-critical still disabled: " + ($missing -join ', '))
        return $true
    }
    Add-Result 'IIS features' 'FAIL' ("still disabled: " + ($missing -join ', '))
    return $false
}

# ---------------------------------------------------------------------------
# 4.  ASP.NET 4.x registration
# ---------------------------------------------------------------------------

function Register-AspNetWithIis {
    Write-Step 'Register ASP.NET 4.x with IIS'
    $sysRoot = $env:SystemRoot
    if ([string]::IsNullOrEmpty($sysRoot)) { $sysRoot = 'C:\Windows' }
    $regiis = Join-Path $sysRoot 'Microsoft.NET\Framework\v4.0.30319\aspnet_regiis.exe'
    if (Test-Path -LiteralPath $regiis) {
        $rc = Invoke-Native -FilePath $regiis -Label 'aspnet_regiis -i' -Arguments @('-i') -OkCodes @(0)
        if ($rc -eq 0) {
            Add-Result 'ASP.NET registration' 'OK' 'aspnet_regiis.exe -i'
            return $true
        }
        Write-Log '    aspnet_regiis returned a non-zero code on this OS (deprecated); trying DISM' 'WARN'
    } else {
        Write-Log '    aspnet_regiis.exe not present (normal on Windows 8+/Server 2012+); using DISM'
    }
    $dism = Join-Path $sysRoot 'System32\dism.exe'
    if (Test-Path -LiteralPath $dism) {
        $rc = Invoke-Native -FilePath $dism -Label 'dism IIS-ASPNET45' `
              -Arguments @('/online', '/enable-feature', '/featurename:IIS-ASPNET45', '/all', '/norestart') `
              -OkCodes @(0, 3010)
        if ($rc -eq 0 -or $rc -eq 3010) {
            Add-Result 'ASP.NET registration' 'OK' 'dism IIS-ASPNET45'
            return $true
        }
    }
    # Detect-and-continue: never abort the whole install on this step alone.
    Add-Result 'ASP.NET registration' 'WARN' 'could not confirm registration; ASP.NET may already be registered'
    return $false
}

# ---------------------------------------------------------------------------
# 5.  .NET Framework 4.5.2 (release 378389) - offline
# ---------------------------------------------------------------------------

function Get-DotNetRelease {
    $key = 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full'
    try {
        $v = Get-ItemProperty -Path $key -Name 'Release' -ErrorAction Stop
        $rel = $v.Release
        if ($null -eq $rel) { return -1 }
        return [int]$rel
    } catch {
        return -1
    }
}

function Install-DotNet452IfNeeded {
    Write-Step '.NET Framework 4.5.2'
    $minRelease = 378389          # .NET Framework 4.5
    $rel = Get-DotNetRelease
    if ($rel -lt 0) {
        Write-Log "    HKLM NDP\v4\Full\Release not readable - will run the offline installer"
    } else {
        Write-Log ("    Installed release = {0} (need >= {1})" -f $rel, $minRelease)
    }
    if ($rel -ge $minRelease) {
        Add-Result '.NET Framework 4.5.2' 'OK' "release $rel already present"
        return $true
    }

    $exe = Join-Path $script:DirPrereq 'dotnetfx45_full_x86_x64.exe'
    if (-not (Test-Path -LiteralPath $exe)) {
        Add-Result '.NET Framework 4.5.2' 'FAIL' "missing $exe"
        return $false
    }
    # 0 = ok, 3010/1641 = ok-with-reboot, 5100 = already installed (newer)
    $rc = Invoke-Native -FilePath $exe -Label 'dotnetfx45' -Arguments @('/q', '/norestart') -OkCodes @(0, 3010, 1641, 5100)
    if ($rc -eq 0) {
        Add-Result '.NET Framework 4.5.2' 'OK' 'offline installer returned 0'
        return $true
    }
    if ($rc -eq 3010 -or $rc -eq 1641) {
        Add-Result '.NET Framework 4.5.2' 'OK' "installed, reboot pending (exit $rc)"
        return $true
    }
    if ($rc -eq 5100) {
        Add-Result '.NET Framework 4.5.2' 'OK' 'a newer .NET 4.x is already installed (5100)'
        return $true
    }
    Add-Result '.NET Framework 4.5.2' 'FAIL' "installer exit code $rc"
    return $false
}

# ---------------------------------------------------------------------------
# 6.  Visual C++ 2013 x86 redistributable - offline
# ---------------------------------------------------------------------------

function Install-VcRedistIfNeeded {
    Write-Step 'Visual C++ 2013 x86 redistributable'
    $exe = Join-Path $script:DirPrereq 'vc_redist.x86.exe'
    if (-not (Test-Path -LiteralPath $exe)) {
        Add-Result 'VC++ 2013 x86' 'FAIL' "missing $exe"
        return $false
    }
    # 0 = installed, 1638 = another version already installed, 3010/1641 = reboot
    $rc = Invoke-Native -FilePath $exe -Label 'vc_redist.x86' `
          -Arguments @('/install', '/quiet', '/norestart') -OkCodes @(0, 1638, 3010, 1641)
    if ($rc -eq 0)        { Add-Result 'VC++ 2013 x86' 'OK' 'installed'; return $true }
    if ($rc -eq 1638)     { Add-Result 'VC++ 2013 x86' 'OK' 'already installed (1638)'; return $true }
    if ($rc -eq 3010 -or $rc -eq 1641) {
        Add-Result 'VC++ 2013 x86' 'OK' "installed, reboot pending ($rc)"; return $true
    }
    Add-Result 'VC++ 2013 x86' 'FAIL' "exit code $rc"
    return $false
}

function Install-HaspDriver {
    Write-Step 'HASP runtime (optional, only with -InstallDongleDriver)'
    $exe = Join-Path $script:DirPrereq 'haspdinst.exe'
    if (-not (Test-Path -LiteralPath $exe)) {
        Add-Result 'HASP runtime' 'FAIL' "missing $exe"
        return $false
    }
    $rc = Invoke-Native -FilePath $exe -Label 'haspdinst -i' -Arguments @('-i', '-nomsg') -OkCodes @(0)
    if ($rc -eq 0) { Add-Result 'HASP runtime' 'OK' 'haspdinst -i'; return $true }
    Add-Result 'HASP runtime' 'WARN' "haspdinst exit $rc (not needed for the DLL patch)"
    return $false
}

# ---------------------------------------------------------------------------
