﻿# ===========================================================================
#  Application: unattended MSI + assembly identity checks
#  Part of the LVSIM-EMS 4.24 modular installer.
#  Dot-sourced by Install-Bondhon-LVSIM-EMS.ps1 - do not run directly.
#  Requires the master script's scope: $script:Root, Write-Log, Add-Result,
#  Set-StrictMode -Version 2 and $ErrorActionPreference = 'Stop'.
# ===========================================================================

# 7.  Unattended InstallShield MSI
# ---------------------------------------------------------------------------

function Install-Application {
    Write-Step "Install LVSIM-EMS 4.24 -> $($script:InstallDir)"

    $msi = Join-Path $script:DirMedia 'LVSIM-EMS.msi'
    if (-not (Test-Path -LiteralPath $msi)) {
        Add-Result 'Application' 'FAIL' "missing $msi"
        return $false
    }
    if ($script:DryRun) {
        Write-Log "    (whatif) would create $($script:InstallDir) and apply $msi"
        Add-Result 'Application' 'SKIP' 'dry run'
        return $true
    }

    if (-not (Test-Path -LiteralPath $script:InstallDir)) {
        New-Item -ItemType Directory -Path $script:InstallDir -Force | Out-Null
    }

    $msiLog = Join-Path $script:DirLogs ("msi-$($script:Stamp).log")
    $transforms = ''
    if ($Locale -eq 'es') { $transforms = Join-Path $script:DirMedia '1034.mst' }
    if ($Locale -eq 'fr') { $transforms = Join-Path $script:DirMedia '3084.mst' }

    # ISSETUPDRIVEN=1 is REQUIRED when invoking msiexec directly.  The MSI's
    # InstallUISequence seq 1 action ISVerifyScriptingRuntime is a Type-19 error
    # dialog that fires unless ISSETUPDRIVEN is set, and it terminates the
    # install with "This installation cannot be run by directly launching the
    # MSI package. You must run setup.exe."  Setting it is the documented
    # equivalent of what the vendor's setup.exe bootstrap does.
    $argsList = @(
        '/i', ('"' + $msi + '"'),
        '/qn', '/norestart',
        '/l*v', ('"' + $msiLog + '"'),
        ('INSTALLDIR="' + $script:InstallDir + '"'),
        'ALLUSERS=1',
        'REBOOT=Suppress',
        'ISSETUPDRIVEN=1'
    )
    if ($transforms -ne '') {
        $argsList += ('TRANSFORMS="' + $transforms + '"')
        Write-Log "    applying transform: $transforms"
    }

    $rc = Invoke-Native -FilePath (Join-Path $env:SystemRoot 'System32\msiexec.exe') `
          -Label 'msiexec /i LVSIM-EMS.msi' -Arguments $argsList `
          -OkCodes @(0, 3010, 1641)
    $script:MsiExitCode = $rc

    $installed = Test-Path -LiteralPath (Join-Path $script:InstallDir 'bin\LVSIMWebCs.dll')
    if (($rc -eq 0 -or $rc -eq 3010 -or $rc -eq 1641) -and $installed) {
        $detail = "msiexec exit $rc"
        if ($rc -ne 0) { $detail += ' (reboot pending)' }
        Add-Result 'Application' 'OK' $detail
        return $true
    }

    Write-Log "    MSI did not produce a usable install (exit $rc, LVSIMWebCs.dll present=$installed)" 'WARN'

    # Fallback: lay down the shipped application tree.  The MSI's own IIS custom
    # action binds the hardcoded vendor port 62555 and can abort the whole
    # install when that port is occupied; step 8 configures IIS properly anyway.
    $srcCfg = Join-Path $script:DirAppSource 'Web.config'
    if (-not (Test-Path -LiteralPath $srcCfg)) {
        Add-Result 'Application' 'FAIL' "msiexec exit $rc and no AppSource fallback available"
        return $false
    }
    Write-Log "    falling back to the shipped application tree: $($script:DirAppSource)"
    $robocopy = Join-Path $env:SystemRoot 'System32\robocopy.exe'
    if (Test-Path -LiteralPath $robocopy) {
        # /E = all subdirs incl. empty, /NFL /NDL quiet, /R:1 /W:1 bounded retries
        $rc2 = Invoke-Native -FilePath $robocopy -Label 'robocopy AppSource' `
               -Arguments @($script:DirAppSource, $script:InstallDir, '/E', '/NFL', '/NDL', '/NJH', '/NJS', '/R:1', '/W:1') `
               -OkCodes @(0, 1, 2, 3, 4, 5, 6, 7)
        if ($rc2 -ge 8) {
            Add-Result 'Application' 'FAIL' "robocopy exit $rc2"
            return $false
        }
    } else {
        Copy-Item -LiteralPath (Join-Path $script:DirAppSource '*') -Destination $script:InstallDir -Recurse -Force
    }
    if (Test-Path -LiteralPath (Join-Path $script:InstallDir 'bin\LVSIMWebCs.dll')) {
        Add-Result 'Application' 'WARN' "MSI exit $rc; used AppSource tree instead (IIS configured in step 8)"
        return $true
    }
    Add-Result 'Application' 'FAIL' 'neither MSI nor AppSource produced bin\LVSIMWebCs.dll'
    return $false
}

# ---------------------------------------------------------------------------
