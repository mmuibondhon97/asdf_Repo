﻿# ===========================================================================
#  Licence (Medicine): DLL replacement, image refresh, safe file-replace
#  Part of the LVSIM-EMS 4.24 modular installer.
#  Dot-sourced by Install-Bondhon-LVSIM-EMS.ps1 - do not run directly.
#  Requires the master script's scope: $script:Root, Write-Log, Add-Result,
#  Set-StrictMode -Version 2 and $ErrorActionPreference = 'Stop'.
# ===========================================================================

# 8.  Medicine - licence replacement DLL
# ---------------------------------------------------------------------------

function Get-FileSha256 {
    param([string] $Path)
    if (Test-CommandExists 'Get-FileHash') {
        return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
    }
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $fs = [System.IO.File]::OpenRead($Path)
    try { $bytes = $sha.ComputeHash($fs) } finally { $fs.Dispose(); $sha.Dispose() }
    return (($bytes | ForEach-Object { $_.ToString('x2') }) -join '')
}

function Read-AssemblyMetadataFallback {
    <#  Minimal PE/CLI metadata reader: returns assembly name, version, whether
        LVSIMWebCs.HardLockWrapper exists, and which member names appear in the
        #Strings heap.  Used only for mixed-mode images where Assembly.Load fails. #>
    param([string] $Path)
    try { $b = [System.IO.File]::ReadAllBytes($Path) } catch { return $null }
    if ($b.Length -lt 512) { return $null }
    $pe = [BitConverter]::ToInt32($b, 0x3C)
    if ($pe -le 0 -or ($pe + 24) -ge $b.Length) { return $null }
    if ($b[$pe] -ne 0x50 -or $b[$pe+1] -ne 0x45) { return $null }   # 'PE'
    $optMagic = [BitConverter]::ToUInt16($b, $pe + 24)
    $nrva     = if ($optMagic -eq 0x20b) { [BitConverter]::ToInt32($b,$pe+24+108) } else { [BitConverter]::ToInt32($b,$pe+24+92) }
    $ddOff    = if ($optMagic -eq 0x20b) { $pe+24+112 } else { $pe+24+96 }
    if ($nrva -le 14) { return $null }
    $cliRva = [BitConverter]::ToInt32($b, $ddOff + 14*8)
    if ($cliRva -le 0) { return $null }
    $nsec = [BitConverter]::ToUInt16($b, $pe + 6)
    $optSize = [BitConverter]::ToUInt16($b, $pe + 20)
    $secOff = $pe + 24 + $optSize
    $cliOff = -1
    for ($i=0; $i -lt $nsec; $i++) {
        $o = $secOff + $i*40
        if ($o+40 -gt $b.Length) { break }
        $vsz=[BitConverter]::ToInt32($b,$o+8); $va=[BitConverter]::ToInt32($b,$o+12); $rsz=[BitConverter]::ToInt32($b,$o+16); $rp=[BitConverter]::ToInt32($b,$o+20)
        if ($cliRva -ge $va -and $cliRva -lt ($va + [Math]::Max($vsz,$rsz))) { $cliOff = $rp + ($cliRva - $va); break }
    }
    if ($cliOff -le 0 -or ($cliOff + 24) -ge $b.Length) { return $null }
    $metaRva = [BitConverter]::ToInt32($b, $cliOff + 8)
    $metaOff = -1
    for ($i=0; $i -lt $nsec; $i++) {
        $o = $secOff + $i*40
        if ($o+40 -gt $b.Length) { break }
        $vsz=[BitConverter]::ToInt32($b,$o+8); $va=[BitConverter]::ToInt32($b,$o+12); $rp=[BitConverter]::ToInt32($b,$o+20)
        if ($metaRva -ge $va -and $metaRva -lt ($va + $vsz)) { $metaOff = $rp + ($metaRva - $va); break }
    }
    if ($metaOff -le 0 -or ($metaOff + 20) -ge $b.Length) { return $null }
    $verLen = [BitConverter]::ToInt32($b, $metaOff + 12)
    $ver    = [Text.Encoding]::ASCII.GetString($b, $metaOff + 16, [Math]::Min($verLen,64)).Trim([char]0)
    $verTxt = ($ver -split '\s+')[0..3] -join '.'
    $verTxt = ($verTxt -replace '[^0-9.]','')
    # crude but sufficient: the #Strings heap sits in this image and holds these names
    $ascii = [Text.Encoding]::ASCII.GetString($b)
    $hasType = $ascii.Contains('HardLockWrapper')
    $members = @('check','logout','getStatusMessageFromCode','GetDaysToLicenseExpiration','IsTrialLicense','IsTrialLicenseExpired') | Where-Object { $ascii.Contains($_) }
    return [pscustomobject]@{ Name='HardLockWrapper'; ClrVersion=$verTxt; HasHardLockWrapperType=$hasType; Members=@($members) }
}

function Test-HardLockAssembly {
    <#  Verifies, by reflection, that a HardLockWrapper.dll has the exact
        assembly identity and the 7 members LVSIMWebCs.dll binds.
        Returns $true/$false and writes what it observed. #>
    param([string] $Path, [string] $Label)

    $required = @('check', 'logout', 'getStatusMessageFromCode',
                  'GetDaysToLicenseExpiration', 'IsTrialLicense', 'IsTrialLicenseExpired')
    $ok = $true
    # HardLockWrapper.dll is MIXED-MODE (C++/CLI). Assembly.Load(byte[]) cannot
    # load mixed-mode images, so try it with a metadata-only fallback that works
    # for BOTH variants. Verified: Variant B (2,052,096 B, mscoree.dll) fails
    # Load(byte[]) but succeeds with ReflectionOnlyLoadFrom.
    $asm   = $null
    $roAsm = $null
    try {
        $bytes = [System.IO.File]::ReadAllBytes($Path)
        $asm = [System.Reflection.Assembly]::Load($bytes)
    } catch {
        $asm = $null
    }
    if ($null -eq $asm) {
        # metadata-only read; never executes code. ReflectionOnlyLoadFrom is the
        # precise tool for mixed-mode, but it is unavailable on .NET Core, so fall
        # back to a raw PE/CLI header read that works on every PowerShell.
        try {
            $roAsm = [System.Reflection.Assembly]::ReflectionOnlyLoadFrom($Path)
        } catch { $roAsm = $null }
        if ($null -eq $roAsm) {
            $meta = Read-AssemblyMetadataFallback -Path $Path
            if ($null -eq $meta) {
                Write-Log ("    $Label : cannot read assembly metadata (not a .NET image?)") 'FAIL'
                return $false
            }
            Write-Log ("    $Label : mixed-mode image - metadata name='$($meta.Name)' CLR=v$($meta.ClrVersion)")
            if ($meta.Name -ne 'HardLockWrapper') { Write-Log "    $Label : assembly name is '$($meta.Name)', expected 'HardLockWrapper'" 'FAIL'; $ok = $false }
            # This path reads the CLI metadata ROOT version, which is the *runtime*
            # version (4.0.30319 for .NET Framework 4.x), NOT the assembly version.
            # The exact assembly version is proven on the tier-2 path
            # (ReflectionOnlyLoadFrom), which Windows PowerShell 5.1 always provides.
            if (-not ($meta.ClrVersion -match '^4\.')) {
                Write-Log "    $Label : CLR version is $($meta.ClrVersion), expected a .NET Framework 4.x image" 'FAIL'; $ok = $false
            }
            if (-not $meta.HasHardLockWrapperType) { Write-Log "    $Label : type LVSIMWebCs.HardLockWrapper not found in metadata" 'FAIL'; return $false }
            foreach ($m in $required) {
                if ($meta.Members -contains $m) { Write-Log ("    $Label : {0} present (metadata)" -f $m) }
                else { Write-Log "    $Label : member $m() MISSING" 'FAIL'; $ok = $false }
            }
            return $ok
        }
        Write-Log "    $Label : mixed-mode image - verified from metadata (not loaded)"
    }
    $probe = if ($null -ne $asm) { $asm } else { $roAsm }
    try {
        $name = $probe.GetName()
        $full = $probe.FullName
    } catch {
        Write-Log ("    $Label : cannot read assembly name - " + $_.Exception.Message) 'FAIL'
        return $false
    }
    Write-Log "    $Label : $full"

    if ($name.Name -ne 'HardLockWrapper') {
        Write-Log "    $Label : assembly name is '$($name.Name)', expected 'HardLockWrapper'" 'FAIL'
        $ok = $false
    }
    if ($name.Version -ne [Version]'0.0.0.0') {
        Write-Log "    $Label : version is $($name.Version), expected 0.0.0.0 (binding identity)" 'FAIL'
        $ok = $false
    }
    $tok = $name.GetPublicKeyToken()
    if ($null -ne $tok -and $tok.Length -gt 0) {
        Write-Log "    $Label : has a public key token, expected none" 'FAIL'
        $ok = $false
    }

    $t = $probe.GetType('LVSIMWebCs.HardLockWrapper', $false)
    if ($null -eq $t) {
        Write-Log "    $Label : type LVSIMWebCs.HardLockWrapper not found" 'FAIL'
        return $false
    }
    $ctor = $t.GetConstructor([Type[]]@())
    if ($null -eq $ctor) {
        Write-Log "    $Label : .ctor() missing" 'FAIL'
        $ok = $false
    } else {
        Write-Log "    $Label : .ctor() present"
    }
    foreach ($m in $required) {
        $mi = $t.GetMethod($m)
        if ($null -eq $mi) {
            Write-Log "    $Label : member $m() MISSING" 'FAIL'
            $ok = $false
        } else {
            $ps = @()
            foreach ($p in $mi.GetParameters()) { $ps += ($p.ParameterType.Name + ' ' + $p.Name) }
            Write-Log ("    $Label : {0} -> {1}({2})" -f $m, $mi.ReturnType.Name, ($ps -join ', '))
        }
    }
    $enumT = $probe.GetType('LVSIMWebCs.HardLockStatus', $false)
    if ($null -eq $enumT) {
        Write-Log "    $Label : enum LVSIMWebCs.HardLockStatus missing" 'FAIL'
        $ok = $false
    } else {
        try {
            $okVal = [int][Enum]::Parse($enumT, 'HASP_STATUS_OK')
            Write-Log "    $Label : HardLockStatus.HASP_STATUS_OK = $okVal"
            if ($okVal -ne 0) { Write-Log "    $Label : HASP_STATUS_OK is not 0" 'FAIL'; $ok = $false }
        } catch {
            Write-Log "    $Label : HardLockStatus.HASP_STATUS_OK missing" 'FAIL'
            $ok = $false
        }
    }
    return $ok
}

function Invoke-ImageRefresh {
    param([string] $InstallDir)

    # Refreshes images/logo_festo.png in place from the staged application tree.
    # Filename, dimensions and alpha are kept so no markup or CSS has to change
    # and the header cell cannot reflow.

    Write-Step 'Image assets'

    $imgDir = Join-Path $InstallDir 'images'
    if (-not (Test-Path -LiteralPath $imgDir)) {
        Add-Result 'Image assets' 'WARN' "no images directory at $imgDir - skipped"
        return
    }

    # Single source of truth: the application tree that ships in this package.
    $src = Join-Path $script:DirAppSource 'images\logo_festo.png'
    if (-not (Test-Path -LiteralPath $src)) {
        # fall back to whatever the MSI just laid down (means: keep vendor logo)
        $src = Join-Path $imgDir 'logo_festo.png'
        Write-Log '    no packaged logo found - keeping the installed image' 'WARN'
    }

    $dst = Join-Path $imgDir 'logo_festo.png'
    $hSrc = Get-FileSha256 -Path $src
    $hDst = $null
    if (Test-Path -LiteralPath $dst) { $hDst = Get-FileSha256 -Path $dst }

    if ($hDst -eq $hSrc) {
        Add-Result 'Image assets' 'OK' ("already applied (logo_festo.png sha256 {0}...)" -f $hSrc.Substring(0,16))
    } else {
        try {
            Copy-Item -LiteralPath $src -Destination $dst -Force
            $hNow = Get-FileSha256 -Path $dst
            if ($hNow -eq $hSrc) {
                Add-Result 'Image assets' 'OK' ("logo_festo.png replaced in place (sha256 {0}...)" -f $hNow.Substring(0,16))
            } else {
                Add-Result 'Image assets' 'FAIL' "post-copy hash mismatch: $hNow vs $hSrc"
                return
            }
        } catch {
            Add-Result 'Image assets' 'FAIL' "could not write $dst : $($_.Exception.Message)"
            return
        }
    }

    # Prove the size contract: the slot expects an 83x15 lockup.
    # Parse the PNG IHDR directly (bytes 16..24 are width/height, big-endian).
    # Done without System.Drawing so it behaves identically on Windows PowerShell
    # and PowerShell 6/7 on any OS.
    try {
        $bytes = [System.IO.File]::ReadAllBytes($dst)
        if ($bytes.Length -ge 24 -and
            $bytes[0] -eq 0x89 -and $bytes[1] -eq 0x50 -and
            $bytes[2] -eq 0x4E -and $bytes[3] -eq 0x47) {
            $w = ($bytes[16] -shl 24) -bor ($bytes[17] -shl 16) -bor ($bytes[18] -shl 8) -bor $bytes[19]
            $h = ($bytes[20] -shl 24) -bor ($bytes[21] -shl 16) -bor ($bytes[22] -shl 8) -bor $bytes[23]
            # The lockup is 139x15: the artwork's own 9.24:1 aspect at the same
            # 15 px cap height as the original 83x15 mark, so the glyphs are not
            # squashed. .logoCell is 20% of an 80%-wide table, so 139 px + the 19 px
            # margin still fits at a 1024 px viewport.
            if ($h -eq 15 -and $w -ge 120 -and $w -le 160) {
                Add-Result 'Image size' 'OK' "${w}x${h} lockup (15 px cap height preserved)"
            } else {
                Add-Result 'Image size' 'WARN' "${w} x ${h} (expected ~139 x 15)"
            }
        } else {
            Add-Result 'Image size' 'WARN' 'logo_festo.png is not a PNG'
        }
    } catch {
        Write-Log ('    could not read image size: ' + $_.Exception.Message) 'WARN'
    }

    # Count the references that must still resolve. If a future vendor build
    # renames the file this count drops, and we want that visible, not silent.
    $aspx = Get-ChildItem -LiteralPath $InstallDir -Filter '*.aspx' -File -ErrorAction SilentlyContinue
    $refs = 0
    foreach ($f in $aspx) {
        $t = Get-Content -LiteralPath $f.FullName -Raw -ErrorAction SilentlyContinue
        if ($t) { $refs += ([regex]::Matches($t, 'logo_festo\.png')).Count }
    }
    if ($refs -gt 0) {
        Add-Result 'Image refs' 'OK' "$refs logo_festo.png references across $($aspx.Count) pages still resolve"
    } else {
        Add-Result 'Image refs' 'WARN' 'no logo_festo.png references found in *.aspx - header image may not be visible'
    }
}

function Invoke-MedicinePatch {
    Write-Step 'Medicine - licence replacement (HardLockWrapper.dll)'

    $bin     = Join-Path $script:InstallDir 'bin'
    $target  = Join-Path $bin 'HardLockWrapper.dll'
    $source  = Join-Path $script:DirMedicine 'HardLockWrapper.dll'
    $iniSrc  = Join-Path $script:DirMedicine 'hardlock.ini'
    # Variant A ships the emulator too. The front-end resolves it by NAME
    # (P/Invoke "hasp_windows.dll"), so it must land in the same bin dir.
    $emuSrc  = Join-Path $script:DirMedicine 'hasp_windows.dll'

    if (-not (Test-Path -LiteralPath $bin)) {
        # In -WhatIf the application step only SIMULATES the MSI, so bin\ does
        # not exist yet. That is not a failure - report it as a skip.
        if ($script:DryRun) {
            Add-Result 'Medicine' 'SKIP' "-WhatIf: bin\ not created yet ($bin)"
            return $true
        }
        Add-Result 'Medicine' 'FAIL' "no bin directory at $bin (application not installed?)"
        return $false
    }
    if (-not (Test-Path -LiteralPath $target)) {
        Add-Result 'Medicine' 'FAIL' "vendor HardLockWrapper.dll not found at $target"
        return $false
    }
    if (-not (Test-Path -LiteralPath $source)) {
        Add-Result 'Medicine' 'FAIL' "replacement DLL missing: $source"
        return $false
    }

    Write-Log '  -- verifying the replacement assembly identity + members'
    if (-not (Test-HardLockAssembly -Path $source -Label 'replacement')) {
        Add-Result 'Medicine' 'FAIL' 'replacement DLL failed identity/member verification - nothing copied'
        return $false
    }
    Write-Log '  -- verifying the vendor DLL identity it must bind in place of'
    $vendorOk = Test-HardLockAssembly -Path $target -Label 'vendor'
    if (-not $vendorOk) {
        Write-Log '    vendor DLL did not present the expected members; continuing (it is being replaced anyway)' 'WARN'
    }

    $srcHash    = Get-FileSha256 -Path $source
    $targetHash = Get-FileSha256 -Path $target
    Write-Log "    replacement sha256 = $srcHash"
    Write-Log "    installed   sha256 = $targetHash"

    if ($srcHash -eq $targetHash) {
        Write-Log '    already patched - no copy needed (idempotent)'
        $script:PatchedHash = $srcHash
        Add-Result 'Medicine' 'OK' "already applied (sha256 $($srcHash.Substring(0,16))...)"
    } else {
        # --- back up the vendor DLL (bytes + .sha256), idempotently ---------
        if (-not (Test-Path -LiteralPath $script:DirBackup)) {
            New-Item -ItemType Directory -Path $script:DirBackup -Force | Out-Null
        }
        $bakName = "HardLockWrapper.dll.$($targetHash.Substring(0,16)).bak"
        $bakPath = Join-Path $script:DirBackup $bakName
        $shPath  = Join-Path $script:DirBackup 'BACKUPS.txt'
        if (Test-Path -LiteralPath $bakPath) {
            Write-Log "    backup already exists: $bakPath"
        } else {
            if ($script:DryRun) {
                Write-Log "    (whatif) would back up $target -> $bakPath"
            } else {
                Copy-Item -LiteralPath $target -Destination $bakPath -Force
                $bakHash = Get-FileSha256 -Path $bakPath
                if ($bakHash -ne $targetHash) {
                    Add-Result 'Medicine' 'FAIL' 'backup copy does not match the original hash - aborting before overwrite'
                    return $false
                }
                [System.IO.File]::AppendAllText($shPath,
                    (('{0}  {1}  {2}  {3}' -f $targetHash, (Get-Date -Format 'o'), $bakName, 'LVSIM-EMS vendor HardLockWrapper.dll') + [System.Environment]::NewLine))
                Write-Log "    backed up -> $bakPath (verified sha256)"
            }
        }

        # --- copy the replacement in -------------------------------------
        # Delegated to the lock-aware copier (08-FileLock.ps1): it tests
        # writability, stops the app pool, force-kills the holding w3wp.exe
        # by PID, and retries. This is what fixes "being used by another
        # process" when IIS is already serving the app.
        $copied  = Copy-ItemWithLockHandling -Source $source -Target $target -MaxAttempts 5 -WaitSeconds 20
        $snapUse = if ($script:LastCopySnapshot) { $script:LastCopySnapshot } else {
                      [pscustomobject]@{ PoolStopped = $false; PoolExisted = $false; PoolWasStarted = $true } }
        Restore-SiteAfterFileUpdate -Snapshot $snapUse
        if (-not $copied) {
            Add-Result 'Medicine' 'FAIL' 'could not overwrite HardLockWrapper.dll after 5 attempts (pool stopped + holding PID force-killed) - see Logs'
            return $false
        }
        $nowHash = Get-FileSha256 -Path $target
        if (-not $script:DryRun -and $nowHash -ne $srcHash) {
            Add-Result 'Medicine' 'FAIL' "post-copy hash mismatch: $nowHash"
            return $false
        }
        $script:PatchedHash = $srcHash
        Add-Result 'Medicine' 'OK' "applied (sha256 $($srcHash.Substring(0,16))...)"
    }

    # --- emulator DLL (Variant A only) --------------------------------
    # Without this file the front-end's P/Invokes cannot resolve and
    # check() returns HASP_NOT_FOUND (7) = NOT licensed.
    if (Test-Path -LiteralPath $emuSrc) {
        $emuDst = Join-Path $bin 'hasp_windows.dll'
        if ($script:DryRun) {
            Write-Log "    (whatif) would copy hasp_windows.dll -> $emuDst"
        } else {
            Copy-Item -LiteralPath $emuSrc -Destination $emuDst -Force
            $emuGot = Get-FileSha256 -Path $emuDst
            $emuExp = Get-FileSha256 -Path $emuSrc
            if ($emuGot -ne $emuExp) {
                Add-Result 'Emulator DLL' 'FAIL' "post-copy hash mismatch: $emuGot"
                return $false
            }
            Write-Log "    hasp_windows.dll -> $emuDst (sha256 verified)"
            Add-Result 'Emulator DLL' 'OK' 'hasp_windows.dll deployed beside HardLockWrapper.dll'
        }
    }

    # --- hardlock.ini ---------------------------------------------------
    # The replacement resolves its config as <dir of the executing assembly>\
    # hardlock.ini, so under ASP.NET shadow-copying that path can be the
    # Temporary ASP.NET Files folder.  With no INI the built-in defaults are
    # already 'permanent' (check()==0, 3650 days), so the licence holds either
    # way.  We still ship the INI next to the DLL (and at the app root) so an
    # operator can switch to trial/disabled mode without a rebuild.
    if (Test-Path -LiteralPath $iniSrc) {
        $iniDst = Join-Path $bin 'hardlock.ini'
        if ($script:DryRun) {
            Write-Log "    (whatif) would copy hardlock.ini -> $iniDst"
        } else {
            Copy-Item -LiteralPath $iniSrc -Destination $iniDst -Force
            Write-Log "    hardlock.ini -> $iniDst"
            $iniRoot = Join-Path $script:InstallDir 'hardlock.ini'
            Copy-Item -LiteralPath $iniSrc -Destination $iniRoot -Force
            Write-Log "    hardlock.ini -> $iniRoot (app root, in case BaseDir resolves there)"
        }
    } else {
        Write-Log '    hardlock.ini not present in Medicine - defaults (permanent) will apply' 'WARN'
    }
    return $true
}

function Restore-MedicineFiles {
    Write-Step 'Medicine - restore the vendor HardLockWrapper.dll'

    $bin    = Join-Path $script:InstallDir 'bin'
    $target = Join-Path $bin 'HardLockWrapper.dll'
    if (-not (Test-Path -LiteralPath $target)) {
        Add-Result 'Restore DLL' 'SKIP' "no DLL at $target"
        return $true
    }
    if (-not (Test-Path -LiteralPath $script:DirBackup)) {
        Add-Result 'Restore DLL' 'SKIP' 'no Medicine\backup directory - nothing was ever replaced'
        return $true
    }
    # Newest backup by write time.
    $bak = Get-ChildItem -LiteralPath $script:DirBackup -Filter 'HardLockWrapper.dll.*.bak' -ErrorAction SilentlyContinue |
           Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($null -eq $bak) {
        Add-Result 'Restore DLL' 'SKIP' 'no HardLockWrapper.dll.*.bak in Medicine\backup'
        return $true
    }
    $expected = $bak.Name -replace '^HardLockWrapper\.dll\.', '' -replace '\.bak$', ''

    if ($script:DryRun) {
        Write-Log "    (whatif) would restore $($bak.FullName) -> $target"
        Add-Result 'Restore DLL' 'SKIP' 'dry run'
        return $true
    }
    Copy-Item -LiteralPath $bak.FullName -Destination $target -Force
    # Remove the Variant-A emulator we deployed, so bin returns to vendor state.
    $emuDeployed = Join-Path $script:InstallDir 'bin\hasp_windows.dll'
    if (Test-Path -LiteralPath $emuDeployed) {
        Remove-Item -LiteralPath $emuDeployed -Force
        Write-Log '    removed deployed hasp_windows.dll'
    }
    $now = Get-FileSha256 -Path $target
    Write-Log "    restored from $($bak.Name)"
    Write-Log "    restored sha256 = $now"
    if ($now.StartsWith($expected, [System.StringComparison]::OrdinalIgnoreCase) -or $now -eq $expected) {
        Add-Result 'Restore DLL' 'OK' "byte-exact restore proven by sha256 $($now.Substring(0,16))..."
        return $true
    }
    Add-Result 'Restore DLL' 'FAIL' "restored hash $now does not match recorded $expected"
    return $false
}

# ---------------------------------------------------------------------------
