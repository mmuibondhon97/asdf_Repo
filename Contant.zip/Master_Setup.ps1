[CmdletBinding()]
param(
    [switch]$Resume,
    [switch]$Force,
    [switch]$SkipRebootPrompt,
    [switch]$KeepAppControl,
    [switch]$NoWdac,
    [bool]$SignPayload = $true
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$Root     = $PSScriptRoot
$AppDir   = 'C:\Program Files (x86)\Festo Didactic\LVSIM-EMS'
$RunKey   = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce'
$StateKey = 'HKLM:\SOFTWARE\Bondhon\LVSIM-EMS'

# ===========================================================================
#  1. Self-Elevate as Administrator
# ===========================================================================
$principal = New-Object Security.Principal.WindowsPrincipal ([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    $argList = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"")
    if ($Resume)           { $argList += '-Resume' }
    if ($Force)            { $argList += '-Force' }
    if ($SkipRebootPrompt) { $argList += '-SkipRebootPrompt' }
    if ($KeepAppControl)   { $argList += '-KeepAppControl' }
    if ($NoWdac)           { $argList += '-NoWdac' }
    if (-not $SignPayload) { $argList += '-SignPayload:$false' }

    try {
        $p = Start-Process -FilePath 'powershell.exe' -ArgumentList $argList -Verb RunAs -Wait -PassThru -ErrorAction Stop
        exit $(if ($p) { $p.ExitCode } else { 1 })
    } catch {
        Write-Host 'Elevation failed.' -ForegroundColor Red
        exit 1
    }
}

# ===========================================================================
#  2. Logging & Minimal Console Helpers
# ===========================================================================
$LogDir = Join-Path $env:ProgramData 'VU-EEE\logs'
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$LogFile = Join-Path $LogDir ('Master_Setup-{0}.log' -f (Get-Date -Format 'yyyyMMdd-HHmmss'))

function Log {
    param([string]$Msg)
    $line = '{0} {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Msg
    Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8 -ErrorAction SilentlyContinue
}

function StepDone {
    param(
        [Parameter(Mandatory)][int]$Num,
        [string]$Tag = 'done',
        [string]$Color = 'Green'
    )
    Log "Step $Num [$Tag]"
    Write-Host "Step $Num [$Tag]" -ForegroundColor $Color
}

function Set-SetupState {
    param([hashtable]$Values)
    if (-not (Test-Path -LiteralPath $StateKey)) {
        New-Item -Path $StateKey -Force | Out-Null
    }
    foreach ($k in $Values.Keys) {
        Set-ItemProperty -Path $StateKey -Name $k -Value $Values[$k]
    }
}

function Fail-Setup {
    param(
        [int]$StepNum = 0,
        [Parameter(Mandatory)][string]$Step,
        [Parameter(Mandatory)][string]$Reason,
        [Parameter(Mandatory)][int]$ExitCode
    )
    Log "FAILED at [$Step]: $Reason (exit $ExitCode)"
    if ($StepNum -gt 0) {
        Write-Host "Step $StepNum [failed]" -ForegroundColor Red
    } else {
        Write-Host 'Setup [failed]' -ForegroundColor Red
    }
    Write-Host "Log: $LogFile" -ForegroundColor DarkGray
    Set-SetupState @{
        FailedStep   = $Step
        LastExitCode = $ExitCode
        LastLog      = $LogFile
    }
    Remove-ItemProperty -Path $RunKey -Name 'BondhonLVSIM' -ErrorAction SilentlyContinue
    exit $ExitCode
}

function Invoke-Logged {
    param(
        [Parameter(Mandatory)][string]$FilePath,
        [string[]]$Arguments = @(),
        [string]$WorkDir = ''
    )
    $prev = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    if ($WorkDir) { Push-Location $WorkDir }
    try {
        $global:LASTEXITCODE = 0
        & $FilePath @Arguments 2>&1 | ForEach-Object {
            $txt = if ($_ -is [System.Management.Automation.ErrorRecord]) { $_.ToString() } else { "$_" }
            if ($txt) { Log "  $txt" }
        }
        return $(if ($null -ne $LASTEXITCODE) { [int]$LASTEXITCODE } else { 0 })
    } finally {
        if ($WorkDir) { Pop-Location }
        $ErrorActionPreference = $prev
    }
}

function Invoke-RebootResume {
    <#
        $Stage records WHERE in the script the reboot happened (e.g.
        'Preflight' vs 'Setup'), not what to skip next time. Each resume
        check below reasons from the stage name + actual on-disk state,
        so two different reboot points are never conflated into one.
    #>
    param(
        [Parameter(Mandatory)][string]$Reason,
        [Parameter(Mandatory)][string]$Stage,
        [int]$ExitCode = 3010
    )
    Set-SetupState @{ ResumeStage = $Stage }

    $cmd = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File "{0}" -Resume -SkipRebootPrompt{1}{2}{3}' -f `
        $PSCommandPath, $(if ($Force) { ' -Force' } else { '' }), $(if ($KeepAppControl) { ' -KeepAppControl' } else { '' }), $(if ($NoWdac) { ' -NoWdac' } else { '' })
    Set-ItemProperty -Path $RunKey -Name 'BondhonLVSIM' -Value $cmd

    Log "REBOOT REQUIRED ($Reason, stage=$Stage). RunOnce scheduled."
    StepDone -Num 1 -Tag 'reboot' -Color 'Yellow'
    if ($ExitCode -eq 1641) { exit 10 }
    if (-not $SkipRebootPrompt -and (Read-Host 'Restart Windows now? [y/N]') -notmatch '^[Yy]') {
        exit 10
    }
    try { Restart-Computer -Force } catch { }
    exit 10
}

function Test-Python {
    param(
        [Parameter(Mandatory)][string]$PyExe,
        [Parameter(Mandatory)][string]$Code
    )
    $prev = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        & $PyExe -c $Code 2>&1 | Out-Null
        return ($LASTEXITCODE -eq 0)
    } catch {
        return $false
    } finally {
        $ErrorActionPreference = $prev
    }
}

function Get-RealPython {
    param([string]$RequiredMajorMinor = '3.14')

    $fromPath = Get-Command python.exe -CommandType Application -ErrorAction SilentlyContinue |
                Where-Object { $_.Source -notlike '*\Microsoft\WindowsApps\*' } |
                Select-Object -First 1 -ExpandProperty Source

    $cands = @(
        'C:\Program Files\Python314\python.exe',
        'C:\Program Files\Python313\python.exe',
        'C:\Program Files\Python312\python.exe',
        'C:\Program Files\Python311\python.exe',
        $fromPath
    ) | Select-Object -Unique

    $parts = $RequiredMajorMinor.Split('.')
    $check = "import sys, struct; assert sys.version_info[:2] == ($($parts[0]), $($parts[1])) and struct.calcsize('P')*8 == 64"

    foreach ($c in $cands) {
        if ($c -and (Test-Path -LiteralPath $c)) {
            if (Test-Python -PyExe $c -Code $check) { return $c }
        }
    }

    return $null
}

# ===========================================================================
#  2b. Application Control Helpers
# ===========================================================================
function Get-AppControlStatus {
    $st = [ordered]@{ SmartAppControl = 'n/a'; WdacPolicies = 0; AppLockerDllRules = 0 }

    $p = 'HKLM:\SYSTEM\CurrentControlSet\Control\CI\Policy'
    try {
        $v = [int](Get-ItemProperty -LiteralPath $p -Name VerifiedAndReputablePolicyState -ErrorAction Stop).VerifiedAndReputablePolicyState
        $st.SmartAppControl = switch ($v) {
            0 { 'off' }
            1 { 'enforcing' }
            2 { 'evaluation' }
            default { "unknown($v)" }
        }
    } catch { }

    $active = Join-Path $env:SystemRoot 'System32\CodeIntegrity\CiPolicies\Active'
    if (Test-Path -LiteralPath $active) {
        $st.WdacPolicies = @(Get-ChildItem -LiteralPath $active -Filter '*.cip' -ErrorAction SilentlyContinue).Count
    }

    try {
        $xml = [xml](Get-AppLockerPolicy -Effective -Xml -ErrorAction Stop)
        $st.AppLockerDllRules = @($xml.AppLockerPolicy.RuleCollection | Where-Object { $_.Type -eq 'Dll' }).Count
    } catch { }

    [pscustomobject]$st
}

function Disable-SmartAppControl {
    $p = 'HKLM:\SYSTEM\CurrentControlSet\Control\CI\Policy'
    New-Item -Path $p -Force | Out-Null
    Set-ItemProperty -LiteralPath $p -Name VerifiedAndReputablePolicyState -Value 0 -Type DWord
}

function Resolve-AppControlBlock {
    param([Parameter(Mandatory)][string]$ProbeDll)

    $st = Get-AppControlStatus
    Log ("App Control: SAC={0} WDACpolicies={1} AppLockerDllRules={2}" -f `
        $st.SmartAppControl, $st.WdacPolicies, $st.AppLockerDllRules)

    # Smart App Control deploys its own .cip into CiPolicies\Active, so it
    # must be checked BEFORE the WDAC-policy-count check, or SAC gets
    # mistaken for a managed WDAC policy and is never turned off.
    if ($st.SmartAppControl -in 'enforcing', 'evaluation') {
        if ($KeepAppControl) { return 'sac-kept' }
        Disable-SmartAppControl
        Log 'Smart App Control enforcement disabled; reboot required before it takes effect.'
        return 'sac-disabled'
    }

    if ($st.WdacPolicies -gt 0 -or $st.AppLockerDllRules -gt 0) {
        Log 'Managed WDAC/AppLocker in force - allow rule will be added in Step 7.'
        return 'managed'
    }

    $sig = Get-AuthenticodeSignature -LiteralPath $ProbeDll
    if ($sig.Status -eq 'Valid') {
        Log "Payload is signed by '$($sig.SignerCertificate.Subject)'; App Control should permit it."
    }
    return 'ok'
}

# ===========================================================================
#  2c. WDAC helper library
# ===========================================================================
$WdacLib = Join-Path $Root 'Medicine\WdacLib.ps1'
$haveWdacLib = Test-Path -LiteralPath $WdacLib
if ($haveWdacLib) {
    . $WdacLib
} else {
    Log "WARN: WdacLib.ps1 missing at $WdacLib - App Control steps will be skipped."
}

function Invoke-WdacAllow {
    param([string[]]$Files, [string[]]$Folders = @(), [switch]$EnforceBasePolicy)
    if (-not $haveWdacLib -or $NoWdac) { return 'skipped' }
    try {
        $res = Add-WdacFileAllow -FilePath $Files -Level FilePath -FolderRule $Folders -EnforceBasePolicy:$EnforceBasePolicy
        Log "WDAC allow-list result: $res"
        return $res
    } catch {
        Log "WDAC allow-list failed: $($_.Exception.Message)"
        return 'failed'
    }
}

try {
    $mainDll = Join-Path $AppDir 'bin\LVSIMWebCs.dll'

    # =======================================================================
    #  2d. Already-Installed Guard
    # =======================================================================
    $alreadyCompleted = $false
    try {
        $regState = Get-ItemProperty -Path $StateKey -ErrorAction Stop
        if ($regState.PSObject.Properties['Installed'] -and [int]$regState.Installed -eq 1) {
            $alreadyCompleted = $true
        }
    } catch { $alreadyCompleted = $false }

    if ($alreadyCompleted -and (Test-Path -LiteralPath $mainDll) -and -not $Force -and -not $Resume) {
        Log 'Already installed (re-run with -Force to reapply).'
        Write-Host 'Already installed.' -ForegroundColor Green
        exit 0
    }

    $resumeStage = $null
    if ($Resume) {
        try {
            $resumeStage = (Get-ItemProperty -Path $StateKey -Name 'ResumeStage' -ErrorAction Stop).ResumeStage
        } catch { $resumeStage = $null }
        Log "Resuming setup (ResumeStage=$resumeStage, Force=$Force)"
    } else {
        Remove-ItemProperty -Path $StateKey -Name 'ResumeStage' -ErrorAction SilentlyContinue
        Remove-ItemProperty -Path $StateKey -Name 'FailedStep'  -ErrorAction SilentlyContinue
    }

    # =======================================================================
    #  3. Verify Payloads
    # =======================================================================
    $SetupExe     = Join-Path $Root 'Setup.exe'
    $PythonExe    = @((Join-Path $Root 'Python\python-3.14.6-amd64.exe'), (Join-Path $Root 'Prerequisites\python-3.14.6-amd64.exe')) |
                    Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
    $PyInstScript = @((Join-Path $Root 'Python\Python3_Installer.ps1'), (Join-Path $Root 'Python\Install-Python-Pillow.ps1')) |
                    Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
    $WheelSearch  = @(
        (Join-Path $Root 'Python\wheels'),
        (Join-Path $Root 'Python'),
        (Join-Path $Root 'Prerequisites\wheels'),
        (Join-Path $Root 'Prerequisites')
    ) | Where-Object { Test-Path -LiteralPath $_ }
    $WheelSearch  = @($WheelSearch)

    $LogoPy       = Join-Path $Root 'LVSIM-EMS Web\setup.py'
    $MedicinePs1  = Join-Path $Root 'Medicine\Medicine.ps1'

    foreach ($req in @($SetupExe, $LogoPy, $MedicinePs1)) {
        if (-not (Test-Path -LiteralPath $req)) {
            Fail-Setup -Step 'preflight' -Reason "MISSING PAYLOAD: $req" -ExitCode 3
        }
    }

    $whl = $null
    foreach ($wd in $WheelSearch) {
        $whl = Get-ChildItem -LiteralPath $wd -Filter 'pillow-*.whl' -ErrorAction SilentlyContinue |
               Where-Object { $_.Length -gt 0 } |
               Sort-Object LastWriteTime -Descending |
               Select-Object -First 1
        if ($whl) { break }
    }
    $wheelPyVer = '3.14'
    if ($whl -and $whl.Name -match '-cp(\d)(\d+)-') {
        $wheelPyVer = "$($Matches[1]).$($Matches[2])"
    }

    # =======================================================================
    #  3b. Code Integrity Preflight
    # =======================================================================
    $probeDll = Join-Path (Split-Path $MedicinePs1) 'hasp_windows.dll'
    if (Test-Path -LiteralPath $probeDll) {
        $acState = Resolve-AppControlBlock -ProbeDll $probeDll
        switch ($acState) {
            'sac-disabled' {
                # Only fires if we have NOT already rebooted for this reason
                # on this resume pass - otherwise a flaky SAC read could loop.
                if (-not ($Resume -and $resumeStage -eq 'Preflight')) {
                    Invoke-RebootResume -Reason 'Smart App Control disabled' -Stage 'Preflight' -ExitCode 3010
                } else {
                    Log 'Already rebooted for Preflight once; SAC still reports non-off - continuing anyway.'
                }
            }
            'managed'  { Log 'WARN: managed App Control detected - allow rule will follow in Step 7.' }
            'sac-kept' { Log 'WARN: SAC left on; payload must be signed or it will be blocked.' }
            default    { }
        }
    } else {
        Log "WARN: no probe DLL at $probeDll - skipping App Control preflight."
    }

    # =======================================================================
    #  4. Step 1 -- Setup.exe /silent
    # =======================================================================
    Log '--- Step 1: Setup.exe /silent ---'

    if (Test-Path -LiteralPath $mainDll) {
        if ($Resume -and $resumeStage -in 'Setup', 'Preflight') {
            Log 'Skipping Setup.exe (main DLL already present after resume).'
        } elseif (-not $Force) {
            Log 'LVSIM-EMS already installed; skipping Setup.exe'
        }
    }

    if (-not (Test-Path -LiteralPath $mainDll) -or $Force) {
        if (Test-Path -LiteralPath $mainDll) {
            Log 'Re-running Setup.exe (-Force).'
        } else {
            Log 'Running Setup.exe /silent ...'
        }
        $p = Start-Process -FilePath $SetupExe -ArgumentList '/silent' `
                           -WorkingDirectory $Root -WindowStyle Hidden -Wait -PassThru
        Log "Setup.exe exited with code $($p.ExitCode)"

        if (-not (Test-Path -LiteralPath $mainDll)) {
            Fail-Setup -StepNum 1 -Step 'Setup.exe' -Reason 'Main application DLL missing after Setup.exe' -ExitCode 4
        }
        if ($p.ExitCode -in 3010, 1641) {
            Invoke-RebootResume -Reason 'Setup.exe requested reboot' -Stage 'Setup' -ExitCode $p.ExitCode
        }
    }
    StepDone 1

    # =======================================================================
    #  5. Step 2 -- Python 3
    # =======================================================================
    Log '--- Step 2: Python ---'
    $py = Get-RealPython -RequiredMajorMinor $wheelPyVer
    if (-not $py -and $PythonExe) {
        Log 'Installing python-3.14.6-amd64.exe silently...'
        $p = Start-Process -FilePath $PythonExe -ArgumentList @(
            '/quiet', 'InstallAllUsers=1', 'PrependPath=1',
            'Include_pip=1', 'Include_launcher=1', 'Include_test=0'
        ) -WindowStyle Hidden -Wait -PassThru
        Log "Python installer exited with code $($p.ExitCode)"
        $py = Get-RealPython -RequiredMajorMinor $wheelPyVer
    }

    if ($py) {
        Log "Python present: $py"
        $pyDir = Split-Path -Parent $py
        $env:PATH = "$pyDir;$(Join-Path $pyDir 'Scripts');$env:PATH"
        StepDone 2
    } else {
        Log 'Python unavailable -- skipping Pillow & logo.'
        StepDone 2 'skipped' 'Yellow'
    }

    # =======================================================================
    #  6. Step 3 -- Python Pillow (offline)
    # =======================================================================
    Log '--- Step 3: Python-Pillow ---'
    $havePil = $false
    if ($py) {
        $havePil = Test-Python -PyExe $py -Code 'import PIL'

        if (-not $havePil) {
            if ($whl) {
                Log "Installing Pillow from $($whl.Name)..."
                $rc = Invoke-Logged -FilePath $py -Arguments @(
                    '-m', 'pip', 'install', '--no-index',
                    '--find-links', $whl.DirectoryName,
                    '--disable-pip-version-check', '--no-warn-script-location',
                    $whl.FullName
                )
                Log "pip exited with code $rc"
            } elseif ($PyInstScript) {
                Log "Running $PyInstScript ..."
                $rc = Invoke-Logged -FilePath 'powershell.exe' -Arguments @(
                    '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $PyInstScript
                ) -WorkDir (Split-Path $PyInstScript)
                Log "$(Split-Path -Leaf $PyInstScript) exited with code $rc"
            }

            $havePil = Test-Python -PyExe $py -Code 'import PIL'
        }

        if ($havePil) { StepDone 3 }
        else          { StepDone 3 'skipped' 'Yellow' }
    } else {
        StepDone 3 'skipped' 'Yellow'
    }

    # =======================================================================
    #  7. Step 4 -- Sentinel HASP driver (Setup.exe normally covers this)
    # =======================================================================
    Log '--- Step 4: HASP driver ---'
    $HaspInst = Join-Path $Root 'HASP Driver\haspdinst.exe'
    if (Get-Service -Name 'hasplms' -ErrorAction SilentlyContinue) {
        Log 'Sentinel driver service already present.'
        StepDone 4
    } elseif (Test-Path -LiteralPath $HaspInst) {
        $p = Start-Process -FilePath $HaspInst -ArgumentList '-i', '-fi', '-nomsg' -WindowStyle Hidden -PassThru
        if (-not $p.WaitForExit(300000)) {
            Log 'WARN: haspdinst.exe timed out after 300s, killing.'
            try { $p.Kill() } catch { }
            StepDone 4 'warn' 'Yellow'
        } else {
            $p.WaitForExit()
            Log "haspdinst.exe exited with code $($p.ExitCode)"
            if (Get-Service -Name 'hasplms' -ErrorAction SilentlyContinue) { StepDone 4 }
            else { StepDone 4 'warn' 'Yellow' }
        }
    } else {
        Log "WARN: no driver at $HaspInst"
        StepDone 4 'skipped' 'Yellow'
    }

    # =======================================================================
    #  8. Step 5 -- LVSIM-EMS Web\setup.py (Logo Manager)
    # =======================================================================
    Log '--- Step 5: LVSIM-EMS Web\setup.py ---'
    if ($py -and $havePil) {
        $imagesDir = Join-Path $AppDir 'images'
        New-Item -ItemType Directory -Force -Path $imagesDir | Out-Null

        $rc = Invoke-Logged -FilePath $py -Arguments @(
            $LogoPy, '--text', 'BONDHON', '--color', '#0875C9',
            '--scale', '3', '--no-svg', '--out', $imagesDir
        ) -WorkDir $imagesDir

        if ($rc -ne 0) { Fail-Setup -StepNum 5 -Step 'setup.py' -Reason "setup.py exited with $rc" -ExitCode 4 }
        if (-not (Test-Path -LiteralPath (Join-Path $imagesDir 'logo_festo.png'))) {
            Fail-Setup -StepNum 5 -Step 'setup.py' -Reason 'logo_festo.png was not produced' -ExitCode 4
        }
        StepDone 5
    } else {
        StepDone 5 'skipped' 'Yellow'
    }

    # =======================================================================
    #  9. Step 6 -- Medicine\Medicine.ps1
    # =======================================================================
    Log '--- Step 6: Medicine.ps1 ---'
    $w3svc = Get-Service -Name 'W3SVC' -ErrorAction SilentlyContinue
    if (-not $w3svc) {
        Log 'WARN: W3SVC (IIS) service not found.'
    } elseif ($w3svc.Status -ne 'Running') {
        try { Start-Service -Name 'W3SVC' -ErrorAction Stop } catch { Log "WARN: W3SVC start: $_" }
    }

    $medArgs = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $MedicinePs1)
    if ($SignPayload) { $medArgs += '-Sign' }
    if ($NoWdac)      { $medArgs += '-NoWdac' }

    $rc = Invoke-Logged -FilePath 'powershell.exe' -Arguments $medArgs -WorkDir (Split-Path $MedicinePs1)

    Log "Medicine.ps1 exited with code $rc"
    if ($rc -ne 0) {
        Fail-Setup -StepNum 6 -Step 'Medicine.ps1' -Reason "Medicine.ps1 returned $rc" -ExitCode 5
    }
    StepDone 6

    # =======================================================================
    #  10. Step 7 -- App Control allow-list for the patched bin folder
    # =======================================================================
    Log '--- Step 7: App Control allow-list ---'
    $binDir = Join-Path $AppDir 'bin'
    if (-not (Test-Path -LiteralPath $binDir)) {
        Log "WARN: bin directory not found: $binDir"
        StepDone 7 'skipped' 'Yellow'
    } elseif (-not $haveWdacLib -or $NoWdac) {
        Log 'WDAC step skipped (library missing or -NoWdac).'
        StepDone 7 'skipped' 'Yellow'
    } else {
        $targets = @(Get-ChildItem -LiteralPath $binDir -File -Recurse -ErrorAction SilentlyContinue |
                     Where-Object { $_.Extension -in '.dll', '.exe', '.sys' } |
                     ForEach-Object { $_.FullName })
        $res = Invoke-WdacAllow -Files $targets -Folders @("$binDir\*") -EnforceBasePolicy
        switch ($res) {
            'not-needed' { StepDone 7 'not-needed' 'Green' }
            'present'    { StepDone 7 }
            'manual'     { StepDone 7 'hash-xml' 'Green' }
            'supplemental' { StepDone 7 'supplemental' 'Green' }
            'base-audit' { Log 'WARN: base policy is audit-only (no Windows template available - this still may not block, but also will not enforce).'; StepDone 7 'audit' 'Yellow' }
            'base-enforced' { StepDone 7 'enforced' 'Green' }
            'skipped'    { StepDone 7 'skipped' 'Yellow' }
            default      { StepDone 7 'warn' 'Yellow' }
        }
    }

    # =======================================================================
    #  11. Step 8 -- Developer Mode
    # =======================================================================
    Log '--- Step 8: Developer Mode ---'
    try {
        $key = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\AppModelUnlock'
        New-Item -Path $key -Force | Out-Null
        Set-ItemProperty -Path $key -Name 'AllowDevelopmentWithoutDevLicense' -Value 1 -Type DWord
        Log 'Developer Mode enabled.'
        StepDone 8
    } catch {
        Log "WARN: Developer Mode: $($_.Exception.Message)"
        StepDone 8 'warn' 'Yellow'
    }

    # =======================================================================
    #  12. Final health re-probe
    # =======================================================================
    Log '--- Final health check ---'
    $probe = 'http://localhost/LVSIMWeb/global.aspx'
    $healthy = $false
    $deadline = (Get-Date).AddSeconds(60)
    while ((Get-Date) -lt $deadline) {
        try {
            $r = Invoke-WebRequest -Uri $probe -UseBasicParsing -TimeoutSec 10 -ErrorAction Stop
            if ($r.Content -notmatch '0x800711C7') { $healthy = $true; break }
        } catch {
            $resp = $_.Exception.Response
            if ($resp) {
                $sr = New-Object IO.StreamReader($resp.GetResponseStream())
                if ($sr.ReadToEnd() -notmatch '0x800711C7') { $healthy = $true; break }
            }
        }
        Start-Sleep -Seconds 5
    }
    if ($healthy) {
        Log 'Site responds.'
    } else {
        Log 'WARN: site still not responding - see App Control events below.'
        if ($haveWdacLib) {
            foreach ($e in Get-WdacBlockEvents) { Log ("  CI {0} {1} {2}" -f $e.TimeCreated, $e.Id, $e.Detail) }
        }
    }

    # =======================================================================
    #  Done
    # =======================================================================
    Remove-ItemProperty -Path $RunKey   -Name 'BondhonLVSIM' -ErrorAction SilentlyContinue
    Remove-ItemProperty -Path $StateKey -Name 'ResumeStage'  -ErrorAction SilentlyContinue
    Remove-ItemProperty -Path $StateKey -Name 'FailedStep'   -ErrorAction SilentlyContinue
    Set-SetupState @{
        Installed   = 1
        CompletedAt = (Get-Date).ToString('o')
        LastLog     = $LogFile
    }
    Log 'ALL STEPS COMPLETED SUCCESSFULLY.'
    exit 0
} catch {
    Fail-Setup -Step 'master' -Reason $_.Exception.Message -ExitCode 1
}