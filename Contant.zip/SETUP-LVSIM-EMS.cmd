@echo off
setlocal EnableExtensions
title Bondhon LVSIM-EMS Master Setup

:: Check for administrative permissions
net session >nul 2>&1
if errorlevel 1 (
    echo Requesting administrative privileges...
    set "ELEV_TARGET=%~f0"
    set "ELEV_ARGS=%*"
    if "%~1"=="" (
        powershell.exe -NoProfile -Command "Start-Process -FilePath $env:ELEV_TARGET -Verb RunAs"
    ) else (
        powershell.exe -NoProfile -Command "Start-Process -FilePath $env:ELEV_TARGET -ArgumentList $env:ELEV_ARGS -Verb RunAs"
    )
    if errorlevel 1 (
        echo [ERROR] Elevation was declined or failed.
        pause
        exit /b 1
    )
    exit /b 0
)

if not exist "%~dp0LVSIM-EMS\Master_Setup.ps1" (
    echo [ERROR] LVSIM-EMS\Master_Setup.ps1 not found next to this file.
    pause
    exit /b 1
)

pushd "%~dp0LVSIM-EMS"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0LVSIM-EMS\Master_Setup.ps1" %*
set "RC=%ERRORLEVEL%"
popd

echo.
if "%RC%"=="0"  echo [DONE] Setup completed successfully.
if "%RC%"=="10" echo [REBOOT] Restart required. Setup will resume automatically after logon.
if not "%RC%"=="0" if not "%RC%"=="10" (
    echo [FAILED] Setup exited with code %RC%.
    echo          Check %%ProgramData%%\VU-EEE\logs\ for details.
)
echo.
pause
exit /b %RC%