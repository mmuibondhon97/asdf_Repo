@echo off
setlocal EnableExtensions
title Python 3 Offline Installer
pushd "%~dp0"

if not exist "%~dp0Python3_Installer.ps1" (
    echo [ERROR] Python3_Installer.ps1 is missing next to this file.
    popd
    pause
    exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Python3_Installer.ps1" %*
set "RC=%ERRORLEVEL%"
popd

echo.
if "%RC%"=="0" (
    echo [DONE] Python 3 setup completed successfully.
) else (
    echo [FAILED] Installer exited with code %RC%.
    echo        Log: %%ProgramData%%\VU-EEE\logs\Python3_Install.log
)
echo.
pause
exit /b %RC%