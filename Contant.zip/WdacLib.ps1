#Requires -Version 5.1
<#
    Shared App Control (WDAC) helper for the Bondhon LVSIM-EMS setup.
    Dot-source only. Creates one supplemental (or base) policy that allow-lists
    specific files by FilePath/FileName/Hash, plus optional folder rules, using
    the ConfigCI cmdlets when available and hand-built hash XML when they are not.

    Policy is rebuilt from a sidecar file list on every call and re-deployed
    under a stable PolicyID, so repeated runs update instead of stacking.
#>

$script:WdacDir     = Join-Path $env:ProgramData 'VU-EEE\WDAC'
$script:WdacLogFile = Join-Path $env:ProgramData 'VU-EEE\logs\Wdac.log'
$script:WdacPolicy  = 'AllowLVSIM-EMS'
$script:WdacXml     = Join-Path $script:WdacDir "$script:WdacPolicy.xml"
$script:WdacCip     = Join-Path $script:WdacDir "$script:WdacPolicy.cip"
$script:WdacList    = Join-Path $script:WdacDir "$script:WdacPolicy.files.json"
$script:WdacIdFile  = Join-Path $script:WdacDir "$script:WdacPolicy.id"

function Write-WdacLog {
    param([string]$Msg, [ValidateSet('INFO','WARN','ERROR','OK')][string]$Level = 'INFO')
    $line = '[{0}] {1,-5} {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, (($Msg -replace '[\r\n]+', ' ').Trim())
    switch ($Level) {
        'OK'    { Write-Host "  $Msg" -ForegroundColor Green }
        'WARN'  { Write-Host "  WARN: $Msg" -ForegroundColor Yellow }
        'ERROR' { Write-Host "  WDAC: $Msg" -ForegroundColor Red }
        default { Write-Host "  WDAC: $Msg" -ForegroundColor DarkGray }
    }
    try {
        $dir = Split-Path -Parent $script:WdacLogFile
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
        Add-Content -LiteralPath $script:WdacLogFile -Value $line -Encoding UTF8 -ErrorAction SilentlyContinue
    } catch { }
}

function Get-WdacProp {
    param($Obj, [string]$Name, $Default = $null)
    if ($null -eq $Obj) { return $Default }
    $p = $Obj.PSObject.Properties[$Name]
    if ($p) { return $p.Value }
    return $Default
}

function Invoke-CiTool {
    param([string[]]$Arguments)
    $prev = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        $global:LASTEXITCODE = 0
        $o = (& CiTool @Arguments 2>&1 | Out-String)
        $c = if ($null -ne $LASTEXITCODE) { [int]$LASTEXITCODE } else { 1 }
    } finally { $ErrorActionPreference = $prev }
    [pscustomobject]@{ Code = $c; Out = $o.Trim() }
}

function Test-WdacTooling {
    [bool](Get-Command CiTool -ErrorAction SilentlyContinue) -and
    [bool](Get-Command New-CIPolicy -ErrorAction SilentlyContinue) -and
    [bool](Get-Command ConvertFrom-CIPolicy -ErrorAction SilentlyContinue)
}

function Test-AppControlActive {
    $p = 'HKLM:\SYSTEM\CurrentControlSet\Control\CI\Policy'
    try {
        $v = [int](Get-ItemProperty -LiteralPath $p -Name VerifiedAndReputablePolicyState -ErrorAction Stop).VerifiedAndReputablePolicyState
        if ($v -in 1, 2) { return $true }
    } catch { }
    $active = Join-Path $env:SystemRoot 'System32\CodeIntegrity\CiPolicies\Active'
    if ((Test-Path -LiteralPath $active) -and
        @(Get-ChildItem -LiteralPath $active -Filter '*.cip' -ErrorAction SilentlyContinue).Count -gt 0) { return $true }
    try {
        $xml = [xml](Get-AppLockerPolicy -Effective -Xml -ErrorAction Stop)
        if (@($xml.AppLockerPolicy.RuleCollection | Where-Object { $_.Type -eq 'Dll' }).Count -gt 0) { return $true }
    } catch { }
    return $false
}

function Get-WdacActivePolicies {
    if (-not (Get-Command CiTool -ErrorAction SilentlyContinue)) { return @() }
    $r = Invoke-CiTool -Arguments @('--list-policies', '--json')
    if (-not $r.Out) { return @() }
    try { return @($r.Out | ConvertFrom-Json | Where-Object { (Get-WdacProp $_ 'PolicyID') }) } catch { return @() }
}

function Get-WdacPolicyId {
    if (-not (Test-Path -LiteralPath $script:WdacIdFile)) { return $null }
    try {
        $v = (Get-Content -LiteralPath $script:WdacIdFile -Raw).Trim().Trim('{', '}')
        if ($v) { return $v }
    } catch { }
    return $null
}

function Get-WdacBasePolicy {
    $mine = Get-WdacPolicyId
    Get-WdacActivePolicies | Where-Object {
        $id = Get-WdacProp $_ 'PolicyID'
        $bp = Get-WdacProp $_ 'BasePolicyID'
        (Get-WdacProp $_ 'IsSystemPolicy' $false) -eq $false -and
        (Get-WdacProp $_ 'FriendlyName' '') -notmatch 'Smart App Control' -and
        $id -and $id -ne $mine -and
        (-not $bp -or $bp -eq $id)
    } | Select-Object -First 1
}

function Get-WdacFileList {
    if (-not (Test-Path -LiteralPath $script:WdacList)) { return @() }
    try {
        $raw = Get-Content -LiteralPath $script:WdacList -Raw
        if ([string]::IsNullOrWhiteSpace($raw)) { return @() }
        return @($raw | ConvertFrom-Json | Where-Object { $_ })
    } catch { return @() }
}

function Save-WdacFileList {
    param([string[]]$Files)
    New-Item -ItemType Directory -Force -Path $script:WdacDir | Out-Null
    ConvertTo-Json -InputObject @($Files) -Depth 3 | Set-Content -LiteralPath $script:WdacList -Encoding UTF8
}

function Get-WdacXmlDoc {
    param([string]$Path)
    $doc = New-Object System.Xml.XmlDocument
    $doc.PreserveWhitespace = $false
    $doc.Load($Path)
    $ns = New-Object System.Xml.XmlNamespaceManager($doc.NameTable)
    $ns.AddNamespace('s', 'urn:schemas-microsoft-com:sipolicy')
    [pscustomobject]@{ Doc = $doc; Ns = $ns }
}

function Set-WdacPolicyOptions {
    param([System.Xml.XmlDocument]$Doc, [System.Xml.XmlNamespaceManager]$Ns, [switch]$Audit)

    $rulesNode = $Doc.SelectSingleNode('/s:SiPolicy/s:Rules', $Ns)
    if (-not $rulesNode) {
        $rulesNode = $Doc.CreateElement('Rules')
        $Doc.DocumentElement.PrependChild($rulesNode) | Out-Null
    }

    $has = { param($opt) [bool]$Doc.SelectSingleNode("/s:SiPolicy/s:Rules/s:Rule[s:Option='$opt']", $Ns) }
    $add = {
        param($opt)
        $r = $Doc.CreateElement('Rule'); $o = $Doc.CreateElement('Option')
        $o.InnerText = $opt
        $r.AppendChild($o) | Out-Null
        $rulesNode.AppendChild($r) | Out-Null
    }

    # NOTE: Enabled:Dynamic Code Security deliberately omitted - it forces CI
    # onto dynamically compiled code, which breaks ASP.NET's Temporary ASP.NET
    # Files directory even when that folder is correctly rule-covered.
    if (-not (& $has 'Enabled:Unsigned System Integrity Policy')) { & $add 'Enabled:Unsigned System Integrity Policy' }
    if (-not (& $has 'Enabled:UMCI'))                          { & $add 'Enabled:UMCI' }

    if ($Audit) {
        if (-not (& $has 'Enabled:Audit Mode')) { & $add 'Enabled:Audit Mode' }
    } else {
        $Doc.SelectNodes("/s:SiPolicy/s:Rules/s:Rule[s:Option='Enabled:Audit Mode']", $Ns) |
            ForEach-Object { $_.ParentNode.RemoveChild($_) | Out-Null }
    }
}

function Set-WdacPolicyIdentity {
    param(
        [System.Xml.XmlDocument]$Doc,
        [System.Xml.XmlNamespaceManager]$Ns,
        [string]$PolicyId,
        [string]$BasePolicyId,
        [switch]$Supplemental
    )

    $root = $Doc.DocumentElement
    if ($Supplemental) { $root.SetAttribute('PolicyType', 'Supplemental Policy') }
    else               { $root.SetAttribute('PolicyType', 'Base Policy') }

    foreach ($pair in @(@('BasePolicyID', $BasePolicyId), @('PolicyID', $PolicyId))) {
        $name = $pair[0]; $val = $pair[1]
        $node = $Doc.SelectSingleNode("/s:SiPolicy/s:$name", $Ns)
        if (-not $node) {
            $node = $Doc.CreateElement($name)
            $root.PrependChild($node) | Out-Null
        }
        $node.InnerText = "{$val}"
    }
}

function New-WdacPolicyManual {
    param([string[]]$Files, [string[]]$FolderRule = @(), [string]$PolicyId, [string]$BasePolicyId, [switch]$Audit, [switch]$Supplemental)

    $esc = { param($s) [System.Security.SecurityElement]::Escape($s) }
    $rules = New-Object System.Text.StringBuilder
    $refs  = New-Object System.Text.StringBuilder

    [void]$rules.AppendLine('    <Rule><Option>Enabled:Unsigned System Integrity Policy</Option></Rule>')
    [void]$rules.AppendLine('    <Rule><Option>Enabled:UMCI</Option></Rule>')
    if ($Audit) { [void]$rules.AppendLine('    <Rule><Option>Enabled:Audit Mode</Option></Rule>') }

    $fileRules = New-Object System.Text.StringBuilder
    $i = 0
    foreach ($f in $Files) {
        $i++
        $name = Split-Path -Leaf $f
        foreach ($alg in 'SHA256', 'SHA1') {
            $h = (Get-FileHash -LiteralPath $f -Algorithm $alg).Hash
            $id = "ID_ALLOW_${alg}_$i"
            [void]$fileRules.AppendLine(('    <Allow ID="{0}" FileName="{1}" Hash="{2}" />' -f $id, (& $esc $name), $h))
            [void]$refs.AppendLine("          <FileRuleRef RuleID=`"$id`" />")
        }
    }
    foreach ($d in $FolderRule) {
        if (-not $d) { continue }
        $i++
        $id = "ID_PATH_$i"
        [void]$fileRules.AppendLine(('    <Allow ID="{0}" FilePath="{1}" />' -f $id, (& $esc $d)))
        [void]$refs.AppendLine("          <FileRuleRef RuleID=`"$id`" />")
    }

    $type = if ($Supplemental) { 'Supplemental Policy' } else { 'Base Policy' }
    $xml = @"
<?xml version="1.0" encoding="utf-8"?>
<SiPolicy xmlns="urn:schemas-microsoft-com:sipolicy" PolicyType="$type">
  <VersionEx>10.0.0.0</VersionEx>
  <BasePolicyID>{$BasePolicyId}</BasePolicyID>
  <PolicyID>{$PolicyId}</PolicyID>
  <PlatformID>{2E07F7E4-194C-4D20-B7C9-6F44A6C5A234}</PlatformID>
  <Rules>
$($rules.ToString().TrimEnd())
  </Rules>
  <EKUs />
  <FileRules>
$($fileRules.ToString().TrimEnd())
  </FileRules>
  <SigningScenarios>
    <SigningScenario Value="12" ID="ID_SIGNINGSCENARIO_WINDOWS" FriendlyName="User Mode Signing">
      <ProductSigners>
        <FileRulesRef>
$($refs.ToString().TrimEnd())
        </FileRulesRef>
      </ProductSigners>
    </SigningScenario>
  </SigningScenarios>
  <CiSigners />
  <HvciOptions>0</HvciOptions>
</SiPolicy>
"@
    New-Item -ItemType Directory -Force -Path $script:WdacDir | Out-Null
    Set-Content -LiteralPath $script:WdacXml -Value $xml -Encoding UTF8
}

function Add-WdacFileAllow {
    <#
        Allow-lists files (and optionally whole folders) against App Control.
        Returns one of:
        not-needed | present | supplemental | base-audit | base-enforced | manual | failed
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string[]]$FilePath,
        [ValidateSet('FilePath', 'FileName', 'Hash')][string]$Level = 'FilePath',
        [string[]]$FolderRule = @(),
        [switch]$Force,
        [switch]$EnforceBasePolicy,
        [switch]$PreferBasePolicy
    )

    if (-not $Force -and -not (Test-AppControlActive)) {
        Write-WdacLog 'App Control not active - no policy needed'
        return 'not-needed'
    }

    $valid = @()
    foreach ($f in $FilePath) {
        if (-not $f) { continue }
        if (-not (Test-Path -LiteralPath $f -PathType Leaf)) { Write-WdacLog "skip (missing): $f" 'WARN'; continue }
        if ((Split-Path -Leaf $f) -notmatch '\.(dll|exe|sys|ocx)$') { Write-WdacLog "skip (not a PE): $f" 'WARN'; continue }
        $valid += (Resolve-Path -LiteralPath $f).ProviderPath
    }
    if ($valid.Count -eq 0 -and $FolderRule.Count -eq 0) { Write-WdacLog 'nothing to allow-list' 'WARN'; return 'failed' }

    $known = @(Get-WdacFileList)
    $new   = @($valid | Where-Object { $known -notcontains $_ })
    $all   = @($known + $new | Select-Object -Unique)
    if ($new.Count -gt 0) { Save-WdacFileList -Files $all }

    $prevId = Get-WdacPolicyId
    $policyId = if ($prevId) { $prevId } else { (New-Guid).Guid }

    $base = if ($PreferBasePolicy) { $null } else { Get-WdacBasePolicy }
    $supplemental = [bool]$base
    $baseId = if ($supplemental) { (Get-WdacProp $base 'PolicyID').Trim('{', '}') } else { $policyId }

    if (-not $supplemental -and $prevId) {
        $wasSupp = $false
        if (Test-Path -LiteralPath $script:WdacXml) {
            try {
                $d = Get-WdacXmlDoc -Path $script:WdacXml
                $wasSupp = ($d.Doc.DocumentElement.GetAttribute('PolicyType') -eq 'Supplemental Policy')
            } catch { }
        }
        if ($wasSupp) { $policyId = (New-Guid).Guid; $baseId = $policyId; Write-WdacLog 'base policy gone - rebuilding as base' 'WARN' }
    }

    $audit = (-not $supplemental) -and (-not $EnforceBasePolicy)
    $tooling = Test-WdacTooling

    # Without ConfigCI there is no way to merge Microsoft's default Windows
    # template, so an enforced *base* policy built only from our allow rules
    # would lock out the OS. Force audit mode in that case.
    if (-not $tooling -and -not $supplemental) { $audit = $true }

    if ($tooling) {
        $rules = @()
        foreach ($f in $all) { $rules += New-CIPolicyRule -DriverFilePath $f -Level $Level -Fallback Hash, FileName }
        foreach ($d in $FolderRule) { if ($d) { $rules += New-CIPolicyRule -FilePathRule $d } }

        $tmp = Join-Path $script:WdacDir "$script:WdacPolicy.new.xml"
        if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Force }
        New-CIPolicy -FilePath $tmp -Rules $rules -UserPEs -MultiplePolicyFormat | Out-Null

        if (-not $supplemental) {
            # A *base* policy must contain Microsoft's default Windows rules
            # or enforcing it will block the OS itself, not just our app.
            $tpl = Join-Path $env:SystemRoot 'schemas\CodeIntegrity\ExamplePolicies\DefaultWindows_Enforced.xml'
            if (Test-Path -LiteralPath $tpl) {
                $tmp2 = Join-Path $script:WdacDir "$script:WdacPolicy.merged.xml"
                Merge-CIPolicy -PolicyPaths $tmp, $tpl -OutputFilePath $tmp2 | Out-Null
                Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
                Move-Item -LiteralPath $tmp2 -Destination $tmp -Force
            } else {
                Write-WdacLog 'Windows default-policy template missing - forcing audit mode to avoid locking out the OS' 'WARN'
                $audit = $true
            }
        }

        $x = Get-WdacXmlDoc -Path $tmp
        Set-WdacPolicyOptions -Doc $x.Doc -Ns $x.Ns -Audit:$audit
        Set-WdacPolicyIdentity -Doc $x.Doc -Ns $x.Ns -PolicyId $policyId -BasePolicyId $baseId -Supplemental:$supplemental
        $x.Doc.Save($script:WdacXml)
        Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
    } else {
        Write-WdacLog 'ConfigCI cmdlets unavailable - using hash XML fallback' 'WARN'
        New-WdacPolicyManual -Files $all -FolderRule $FolderRule -PolicyId $policyId -BasePolicyId $baseId -Audit:$audit -Supplemental:$supplemental
    }

    Set-Content -LiteralPath $script:WdacIdFile -Value $policyId -Encoding ASCII
    if (Test-Path -LiteralPath $script:WdacCip) { Remove-Item -LiteralPath $script:WdacCip -Force }

    if ($tooling) {
        ConvertFrom-CIPolicy -XmlFilePath $script:WdacXml -BinaryFilePath $script:WdacCip | Out-Null
    }

    $mode = if ($supplemental) { 'supplemental' } elseif ($audit) { 'base-audit' } else { 'base-enforced' }

    $deploy = if (Test-Path -LiteralPath $script:WdacCip) {
        Invoke-CiTool -Arguments @('--update-policy', $script:WdacCip)
    } else {
        Invoke-CiTool -Arguments @('--update-policy', $script:WdacXml)
    }
    Write-WdacLog "deploy ($mode, $($all.Count) file(s), $($FolderRule.Count) folder rule(s)) rc=$($deploy.Code) $($deploy.Out)" $(if ($deploy.Code -eq 0) { 'OK' } else { 'ERROR' })

    if ($deploy.Code -ne 0 -and $supplemental) {
        Write-WdacLog 'supplemental rejected - retrying as base policy' 'WARN'
        $base = $null; $supplemental = $false
        $policyId = (New-Guid).Guid; $baseId = $policyId
        $audit = -not $EnforceBasePolicy
        Set-Content -LiteralPath $script:WdacIdFile -Value $policyId -Encoding ASCII

        if ($tooling) {
            $tpl = Join-Path $env:SystemRoot 'schemas\CodeIntegrity\ExamplePolicies\DefaultWindows_Enforced.xml'
            if (-not (Test-Path -LiteralPath $tpl)) { $audit = $true }

            $x = Get-WdacXmlDoc -Path $script:WdacXml
            Set-WdacPolicyOptions -Doc $x.Doc -Ns $x.Ns -Audit:$audit
            Set-WdacPolicyIdentity -Doc $x.Doc -Ns $x.Ns -PolicyId $policyId -BasePolicyId $baseId
            $x.Doc.Save($script:WdacXml)
            ConvertFrom-CIPolicy -XmlFilePath $script:WdacXml -BinaryFilePath $script:WdacCip | Out-Null
        } else {
            $audit = $true
            New-WdacPolicyManual -Files $all -FolderRule $FolderRule -PolicyId $policyId -BasePolicyId $baseId -Audit:$audit
        }
        $deploy = Invoke-CiTool -Arguments @('--update-policy', $script:WdacCip)
        $mode = if ($audit) { 'base-audit' } else { 'base-enforced' }
        Write-WdacLog "deploy fallback ($mode) rc=$($deploy.Code) $($deploy.Out)" $(if ($deploy.Code -eq 0) { 'OK' } else { 'ERROR' })
    }

    if ($deploy.Code -ne 0) { return 'failed' }

    Invoke-CiTool -Arguments @('--refresh-policy', "{$policyId}") | Out-Null
    if (-not $tooling) { return 'manual' }
    return $mode
}

function Test-WdacPolicyApplied {
    param([string]$PolicyId = (Get-WdacPolicyId))
    if (-not $PolicyId) { return $false }
    $id = $PolicyId.Trim('{', '}')
    $hit = Get-WdacActivePolicies | Where-Object { (Get-WdacProp $_ 'PolicyID') -eq $id }
    return [bool]$hit
}

function Remove-WdacPolicy {
    $id = Get-WdacPolicyId
    if ($id) {
        $r = Invoke-CiTool -Arguments @('--remove-policy', "{$id}")
        Write-WdacLog "remove-policy {$id} rc=$($r.Code) $($r.Out)" $(if ($r.Code -eq 0) { 'OK' } else { 'WARN' })
    }
    foreach ($p in $script:WdacCip, $script:WdacXml, $script:WdacList, $script:WdacIdFile) {
        Remove-Item -LiteralPath $p -Force -ErrorAction SilentlyContinue
    }
}

function Get-WdacBlockEvents {
    param([int]$Max = 25)
    try {
        Get-WinEvent -FilterHashtable @{
            LogName      = 'Microsoft-Windows-CodeIntegrity/Operational'
            Id           = 3077, 3082, 3033
            StartTime    = (Get-Date).AddHours(-2)
        } -MaxEvents $Max -ErrorAction Stop |
            Select-Object TimeCreated, Id, @{ n = 'Detail'; e = { ($_.Message -split "`n" | Select-Object -First 6) -join ' | ' } }
    } catch { @() }
}