#Requires -Version 5.0
<#
.SYNOPSIS
   Applies or reverts the HASP Hardlock patch for LVSIM-EMS.
.DESCRIPTION
   Stages payload files, optionally code-signs them with a local self-signed
   certificate, then backs up and overwrites the target bin directory. If
   signing, ALSO re-signs every other unsigned/untrusted binary already in
   bin\ (e.g. Festo's CalculsWrapper.dll) with the same certificate, since
   ASP.NET loads the entire bin\ directory on app-domain init and App Control
   can block any file there, not just the ones this script replaces.
   Allow-lists the patched files against App Control, verifies the site
   afterwards and returns non-zero if it is still broken.
.PARAMETER Restore
   Replaces patched files with the backed-up .vendor originals and removes the
   App Control allow-list policy.
.PARAMETER Sign
   Sign staged payloads and the rest of bin\, and trust the signer in Root +
   TrustedPublisher.
.PARAMETER PayloadNames
   Explicit list of files to install. Defaults to every non-excluded file.
.PARAMETER InstallDir
   Path to the LVSIM-EMS installation directory.
.PARAMETER SourceDir
   Path to the folder containing the payload files. Default: Script's own directory.
.PARAMETER NoWdac
   Do not create or remove any App Control policy.
.EXAMPLE
   .\Medicine.ps1 -Sign
.EXAMPLE
   .\Medicine.ps1 -Restore
#>
[CmdletBinding()]
param(
    [string]$InstallDir = "C:\Program Files (x86)\Festo Didactic\LVSIM-EMS",
    [string]$SourceDir = "",
    [switch]$Restore,
    [switch]$Sign,
    [switch]$NoWdac,
    [string[]]$PayloadNames = @(),
    [string]$AppPoolName = "LVSIMWebAppPool",
    [string]$SiteName = "LVSIMWeb"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

if ([string]::IsNullOrEmpty($SourceDir)) {
    if ($PSScriptRoot) {
        $SourceDir = $PSScriptRoot
    } else {
        $SourceDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
    }
}

Write-Host "DEBUG: SourceDir resolved to: [$SourceDir]" -ForegroundColor Cyan

# --- Shared App Control library ---
$WdacLib = Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Definition) 'WdacLib.ps1'
if (-not (Test-Path -LiteralPath $WdacLib) -and $PSScriptRoot) {
    $WdacLib = Join-Path $PSScriptRoot 'WdacLib.ps1'
}
$haveWdacLib = (Test-Path -LiteralPath $WdacLib) -and (-not $NoWdac)
if ($haveWdacLib) {
    . $WdacLib
} else {
    Write-Host 'NOTE: WdacLib.ps1 not loaded - App Control allow-list disabled.' -ForegroundColor Yellow
}

# --- Helper Functions ---

function Write-Log {
    param([string]$Message, [string]$Color = "White")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "$timestamp - $Message" -ForegroundColor $Color
}

function Ensure-Dir {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Force -Path $Path | Out-Null
        Write-Log "Created directory: $Path" "Green"
    }
}

function Backup-File {
    param(
        [string]$SourcePath,
        [string]$BackupDir
    )
    if ([string]::IsNullOrEmpty($SourcePath)) {
        throw "SourcePath is empty in Backup-File"
    }
    if (-not (Test-Path -LiteralPath $SourcePath)) {
        return
    }

    $fileName   = Split-Path -Leaf $SourcePath
    $backupPath = Join-Path $BackupDir "${fileName}.vendor"

    try {
        Copy-Item -LiteralPath $SourcePath -Destination $backupPath -Force
        Write-Log "Backed up: $fileName -> ${fileName}.vendor" "Green"
    } catch {
        Write-Log "Failed to backup $fileName : $_" "Red"
        throw
    }
}

function Restore-File {
    param(
        [string]$TargetPath,
        [string]$BackupDir
    )
    if ([string]::IsNullOrEmpty($TargetPath)) {
        throw "TargetPath is empty in Restore-File"
    }

    $fileName   = Split-Path -Leaf $TargetPath
    $backupPath = Join-Path $BackupDir "${fileName}.vendor"

    if (-not (Test-Path -LiteralPath $backupPath)) {
        throw "No backup found for $fileName at $backupPath"
    }

    try {
        Copy-Item -LiteralPath $backupPath -Destination $TargetPath -Force
        Write-Log "Restored: $fileName from backup" "Green"
    } catch {
        Write-Log "Failed to restore $fileName : $_" "Red"
        throw
    }
}

function Get-AppControlStatus {
    $st = [ordered]@{ SmartAppControl = 'n/a'; WdacPolicies = 0; AppLockerDllRules = 0 }

    $p = 'HKLM:\SYSTEM\CurrentControlSet\Control\CI\Policy'
    try {
        $v = [int](Get-ItemProperty -LiteralPath $p -Name VerifiedAndReputablePolicyState -ErrorAction Stop).VerifiedAndReputablePolicyState
        $st.SmartAppControl = switch ($v) {
            0 { 'off' }
            1 { 'enforcing' }
            2 { 'evaluation' }
            default { "unknown($v)" }
        }
    } catch { }

    $active = Join-Path $env:SystemRoot 'System32\CodeIntegrity\CiPolicies\Active'
    if (Test-Path -LiteralPath $active) {
        $st.WdacPolicies = @(Get-ChildItem -LiteralPath $active -Filter '*.cip' -ErrorAction SilentlyContinue).Count
    }

    try {
        $xml = [xml](Get-AppLockerPolicy -Effective -Xml -ErrorAction Stop)
        $st.AppLockerDllRules = @($xml.AppLockerPolicy.RuleCollection | Where-Object { $_.Type -eq 'Dll' }).Count
    } catch { }

    [pscustomobject]$st
}

function New-PayloadSigner {
    $subject  = 'CN=Bondhon LVSIM Payload'
    $existing = Get-ChildItem Cert:\LocalMachine\My -ErrorAction SilentlyContinue |
                Where-Object { $_.Subject -eq $subject -and $_.HasPrivateKey } |
                Select-Object -First 1
    if ($existing) { return $existing }

    New-SelfSignedCertificate -Type CodeSigningCert -Subject $subject `
        -CertStoreLocation 'Cert:\LocalMachine\My' -KeyUsage DigitalSignature `
        -HashAlgorithm SHA256 -NotAfter (Get-Date).AddYears(10)
}

function Register-SignerTrust {
    param([Parameter(Mandatory)]$Cert)
    $cer = Join-Path $env:TEMP "$($Cert.Thumbprint).cer"
    Export-Certificate -Cert $Cert -FilePath $cer -Type CERT | Out-Null
    Import-Certificate -FilePath $cer -CertStoreLocation 'Cert:\LocalMachine\Root'             | Out-Null
    Import-Certificate -FilePath $cer -CertStoreLocation 'Cert:\LocalMachine\TrustedPublisher' | Out-Null
    Remove-Item -LiteralPath $cer -Force -ErrorAction SilentlyContinue
    Write-Log "Signer trusted: $($Cert.Thumbprint)" "Green"
}

function Sign-Payload {
    param([Parameter(Mandatory)][string]$Dir)

    $cert = New-PayloadSigner
    Register-SignerTrust -Cert $cert

    $targets = @(Get-ChildItem -LiteralPath $Dir -File |
                 Where-Object { $_.Extension -in '.dll', '.exe' })
    if ($targets.Count -eq 0) {
        Write-Log "No signable files in $Dir" "Yellow"
        return $cert
    }

    foreach ($t in $targets) {
        try {
            Set-AuthenticodeSignature -LiteralPath $t.FullName -Certificate $cert -HashAlgorithm SHA256 | Out-Null
            Write-Log "Signed: $($t.Name)" "Green"
        } catch {
            Write-Log "Warning: could not sign $($t.Name): $_" "Yellow"
        }
    }
    return $cert
}

function Sign-BinFolder {
    <#
        ASP.NET loads EVERY dll in bin\ at app-domain init (BuildManager
        LoadAllAssembliesFromAppDomainBinDirectory), so a Festo-shipped file
        we never touch - like CalculsWrapper.dll - can still trip App Control.
        Re-sign every file in bin\ that isn't already validly signed.
    #>
    param([Parameter(Mandatory)]$Cert, [Parameter(Mandatory)][string]$Dir)

    $files = @(Get-ChildItem -LiteralPath $Dir -File -Recurse -ErrorAction SilentlyContinue |
               Where-Object { $_.Extension -in '.dll', '.exe', '.ocx' })
    $signed = 0
    $skipped = 0
    foreach ($f in $files) {
        $s = Get-AuthenticodeSignature -LiteralPath $f.FullName
        if ($s.Status -eq 'Valid') { $skipped++; continue }
        try {
            Set-AuthenticodeSignature -LiteralPath $f.FullName -Certificate $Cert -HashAlgorithm SHA256 | Out-Null
            $signed++
        } catch {
            Write-Log "Could not sign $($f.Name): $_" "Yellow"
        }
    }
    Write-Log "bin\ signing: $signed file(s) signed, $skipped already validly signed." "Green"
}

function Start-AppPool {
    param([string]$Name)
    $appcmd = Join-Path $env:SystemRoot 'System32\inetsrv\appcmd.exe'
    if (Test-Path -LiteralPath $appcmd) {
        & $appcmd start apppool "/apppool.name:$Name" 2>&1 | Out-Null
    }
}

function Recycle-AppPool {
    param([string]$Name)
    $appcmd = Join-Path $env:SystemRoot 'System32\inetsrv\appcmd.exe'
    if (Test-Path -LiteralPath $appcmd) {
        & $appcmd recycle apppool "/apppool.name:$Name" 2>&1 | Out-Null
    }
}

function Test-SiteHealth {
    param([string]$Url)
    $deadline = (Get-Date).AddSeconds(90)
    while ((Get-Date) -lt $deadline) {
        try {
            $r = Invoke-WebRequest -Uri $Url -UseBasicParsing -TimeoutSec 15 -ErrorAction Stop
            if ($r.Content -notmatch '0x800711C7') { return $true }
        } catch {
            $resp = $_.Exception.Response
            if ($resp) {
                $stream = $resp.GetResponseStream()
                if ($stream) {
                    $sr = New-Object IO.StreamReader($stream)
                    $body = $sr.ReadToEnd()
                    if ($body -notmatch '0x800711C7') { return $true }
                }
            }
        }
        Start-Sleep -Seconds 5
    }
    return $false
}

function Invoke-PostFlight {
    param([string]$BinDir)

    Write-Log "Restarting IIS services..." "Yellow"
    try { & iisreset /start } catch { Write-Log "Warning: could not start IIS cleanly." "Yellow" }

    Start-AppPool -Name $AppPoolName

    $probe = "http://localhost/$SiteName/global.aspx"
    Write-Log "Probing $probe ..." "Yellow"

    if (Test-SiteHealth -Url $probe) {
        Write-Log "Site responds. Operation completed successfully." "Green"
        return 0
    }

    Write-Log "Site still returning 0x800711C7 - App Control is blocking the payload." "Red"

    $blocked = @(Get-ChildItem -LiteralPath $BinDir -File -Recurse -ErrorAction SilentlyContinue |
                 Where-Object { $_.Extension -in '.dll', '.exe', '.sys' } |
                 ForEach-Object { $_.FullName })

    if ($haveWdacLib -and $blocked.Count -gt 0) {
        Write-Log "Adding App Control allow rule for $($blocked.Count) file(s) in bin\ ..." "Yellow"
        try {
            $res = Add-WdacFileAllow -FilePath $blocked -Level FilePath -FolderRule @("$BinDir\*") -Force
            Write-Log "Allow-list result: $res" "Yellow"
            if ($res -notin 'failed', 'not-needed') {
                Recycle-AppPool -Name $AppPoolName
                Start-Sleep -Seconds 5
                if (Test-SiteHealth -Url $probe) {
                    Write-Log "Site responds after allow rule. Operation completed successfully." "Green"
                    return 0
                }
            }
        } catch {
            Write-Log "Allow-list failed: $($_.Exception.Message)" "Red"
        }
    }

    foreach ($f in $blocked) {
        $sig = Get-AuthenticodeSignature -LiteralPath $f
        if ($sig.Status -ne 'Valid') { Write-Log "unsigned/blocked candidate: $(Split-Path -Leaf $f) ($($sig.Status))" "Red" }
    }

    $st = Get-AppControlStatus
    Write-Log ("App Control: SAC={0} WDACpolicies={1} AppLockerDllRules={2}" -f `
        $st.SmartAppControl, $st.WdacPolicies, $st.AppLockerDllRules) "Red"
    if ($st.SmartAppControl -in 'enforcing', 'evaluation') {
        Write-Log "Smart App Control is $($st.SmartAppControl) - no WDAC policy can override it. Disable it (and reboot) or re-run Medicine.ps1 -Sign." "Red"
    }

    if ($haveWdacLib) {
        foreach ($e in Get-WdacBlockEvents) { Write-Log ("CI {0} {1} {2}" -f $e.TimeCreated, $e.Id, $e.Detail) "Red" }
    }

    Write-Log "Fix: re-run with -Sign (now signs all of bin\, not just the patch files), disable Smart App Control, or have IT approve the publisher." "Red"
    return 1
}

# --- Main Logic ---

$staging = $null
try {
    if (-not (Test-Path -LiteralPath $InstallDir)) {
        throw "Installation directory not found: $InstallDir"
    }

    $BinDir = Join-Path $InstallDir "bin"
    if (-not (Test-Path -LiteralPath $BinDir)) {
        throw "Bin directory not found: $BinDir"
    }

    $BackupDir = Join-Path $BinDir "backup-vendor"
    Ensure-Dir -Path $BackupDir

    if ($Restore) {
        Write-Log "RESTORE MODE: restoring vendor files..." "Cyan"

        $backups = @(Get-ChildItem -LiteralPath $BackupDir -File -Filter "*.vendor" -ErrorAction SilentlyContinue)
        if ($backups.Count -eq 0) {
            throw "No .vendor backup files found in $BackupDir"
        }

        Write-Log "Stopping IIS services..." "Yellow"
        try { & iisreset /stop; Start-Sleep -Seconds 5 } catch { Write-Log "Warning: could not stop IIS cleanly." "Yellow" }

        foreach ($backup in $backups) {
            $originalName = $backup.Name -replace '\.vendor$', ''
            $targetFile   = Join-Path $BinDir $originalName
            try {
                Restore-File -TargetPath $targetFile -BackupDir $BackupDir
            } catch {
                Write-Log "Warning: failed to restore $originalName : $_" "Yellow"
            }
        }

        if ($haveWdacLib) {
            Write-Log "Removing App Control allow-list policy..." "Yellow"
            try { Remove-WdacPolicy } catch { Write-Log "Warning: policy removal failed: $_" "Yellow" }
        }

        exit (Invoke-PostFlight -BinDir $BinDir)
    }

    Write-Log "APPLY MODE: applying HASP patch..." "Cyan"

    if (-not (Test-Path -LiteralPath $SourceDir)) {
        throw "Source directory not found: $SourceDir"
    }

    if ($PayloadNames.Count -gt 0) {
        $payloadFiles = @()
        foreach ($n in $PayloadNames) {
            $candidate = Join-Path $SourceDir $n
            if (Test-Path -LiteralPath $candidate) {
                $payloadFiles += Get-Item -LiteralPath $candidate
            } else {
                Write-Log "Warning: listed payload missing: $n" "Yellow"
            }
        }
    } else {
        $payloadFiles = @(Get-ChildItem -LiteralPath $SourceDir -File |
                          Where-Object {
                              $_.Name -ne "Medicine.ps1" -and
                              $_.Name -ne "WdacLib.ps1" -and
                              $_.Name -ne "Master_Setup.bat" -and
                              $_.Name -notmatch "^\.|^backup"
                          })
    }

    if ($payloadFiles.Count -eq 0) {
        throw "No payload files found in $SourceDir."
    }

    Write-Log "Found $($payloadFiles.Count) files to install." "Green"

    $staging = Join-Path $env:TEMP ("lvsimport_{0}" -f ([Guid]::NewGuid().ToString('N').Substring(0, 8)))
    Ensure-Dir -Path $staging
    foreach ($payload in $payloadFiles) {
        Copy-Item -LiteralPath $payload.FullName -Destination (Join-Path $staging $payload.Name) -Force
    }

    $signerCert = $null
    if ($Sign) {
        Write-Log "Signing staged payload..." "Cyan"
        $signerCert = Sign-Payload -Dir $staging
    }

    Write-Log "Stopping IIS services..." "Yellow"
    try { & iisreset /stop; Start-Sleep -Seconds 5 } catch { Write-Log "Warning: could not stop IIS cleanly." "Yellow" }

    foreach ($payload in $payloadFiles) {
        $targetFile = Join-Path $BinDir $payload.Name
        Backup-File -SourcePath $targetFile -BackupDir $BackupDir
        try {
            Copy-Item -LiteralPath (Join-Path $staging $payload.Name) -Destination $targetFile -Force
            Write-Log "Installed: $($payload.Name)" "Green"
        } catch {
            Write-Log "Failed to install $($payload.Name): $_" "Red"
            throw
        }
    }

    # Sign the REST of bin\ (e.g. Festo's own CalculsWrapper.dll) only after
    # the patch files are in place and only now that $BinDir is final, so the
    # hashes allow-listed below match what's actually on disk.
    if ($Sign -and $signerCert) {
        Write-Log "Signing remaining binaries in bin\ (vendor files included)..." "Cyan"
        Sign-BinFolder -Cert $signerCert -Dir $BinDir
    }

    if ($haveWdacLib) {
        Write-Log "Allow-listing bin\ against App Control..." "Cyan"
        $installed = @(Get-ChildItem -LiteralPath $BinDir -File -Recurse -ErrorAction SilentlyContinue |
                       Where-Object { $_.Extension -in '.dll', '.exe', '.sys' } |
                       ForEach-Object { $_.FullName })
        try {
            $res = Add-WdacFileAllow -FilePath $installed -Level FilePath -FolderRule @("$BinDir\*") -EnforceBasePolicy
            Write-Log "Allow-list result: $res" $(if ($res -eq 'failed') { 'Red' } else { 'Green' })
        } catch {
            Write-Log "Warning: allow-list failed: $($_.Exception.Message)" "Yellow"
        }
    }

    exit (Invoke-PostFlight -BinDir $BinDir)
} catch {
    Write-Log "FAILED: $_" "Red"
    try { & iisreset /start 2>$null } catch { }
    exit 1
} finally {
    if ($staging -and (Test-Path -LiteralPath $staging)) {
        Remove-Item -LiteralPath $staging -Recurse -Force -ErrorAction SilentlyContinue
    }
}