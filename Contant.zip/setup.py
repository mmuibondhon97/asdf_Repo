#!/usr/bin/env python3
"""
setup.py (logo manager)
Generates a custom Festo-style extended geometric vector font logo as SVG
and crisp PNG (zero transparent dark-edge fringe, 8x BOX supersampling).

Requirements:
    pip install pillow        (or pip install cairosvg)
"""

import argparse
import io
import json
import os
import re
import shutil
import sys
from typing import Dict, List, Optional, Tuple

# ── Brand & Output Constants ─────────────────────────────────────────────────
FESTO_BLUE   = "#0091DC"   # Corporate Festo cyan-blue [0,145,220]
BONDHON_BLUE = "#0875C9"   # Deeper Bondhon blue [8,117,201]

DEFAULT_OUT_DIR   = r"C:\Program Files (x86)\Festo Didactic\LVSIM-EMS\images"
DEFAULT_OUT_NAME  = "logo_festo.png"

CAP_UNITS    = 100.0       # Internal glyph design grid height
CORNER_K     = 0.64        # Superellipse Bezier tension
TRACKING     = 9.0         # Inter-character spacing in glyph units

DEFAULT_BASE_H    = 60     # Fallback canvas height at 1x (px)
DEFAULT_CAP_PX    = 34.5   # Fallback letter height at 1x (px)
DEFAULT_PAD_X_PX  = 8.7    # Fallback horizontal margin at 1x (px)


# ── Geometric Path Builders (CW outer, CCW inner for fill-rule="nonzero") ───
def corner_arc(
    x0: float, y0: float,
    cx: float, cy: float,
    x1: float, y1: float,
    k: float = CORNER_K,
) -> str:
    c1x = x0 + (cx - x0) * k
    c1y = y0 + (cy - y0) * k
    c2x = x1 + (cx - x1) * k
    c2y = y1 + (cy - y1) * k
    return f"C {c1x:.2f} {c1y:.2f} {c2x:.2f} {c2y:.2f} {x1:.2f} {y1:.2f}"


def super_rect(
    x: float, y: float, w: float, h: float,
    rtl: float = 0, rtr: float = 0, rbr: float = 0, rbl: float = 0,
    k: float = CORNER_K, ccw: bool = False,
) -> str:
    """Superelliptical rectangle. CW (default) for outer shapes, CCW for cutouts."""
    parts: List[str] = []
    if not ccw:
        parts.append(f"M {x + rtl:.2f} {y:.2f}")
        parts.append(f"L {x + w - rtr:.2f} {y:.2f}")
        if rtr > 0:
            parts.append(corner_arc(x + w - rtr, y, x + w, y, x + w, y + rtr, k))
        parts.append(f"L {x + w:.2f} {y + h - rbr:.2f}")
        if rbr > 0:
            parts.append(corner_arc(x + w, y + h - rbr, x + w, y + h, x + w - rbr, y + h, k))
        parts.append(f"L {x + rbl:.2f} {y + h:.2f}")
        if rbl > 0:
            parts.append(corner_arc(x + rbl, y + h, x, y + h, x, y + h - rbl, k))
        parts.append(f"L {x:.2f} {y + rtl:.2f}")
        if rtl > 0:
            parts.append(corner_arc(x, y + rtl, x, y, x + rtl, y, k))
        parts.append("Z")
    else:
        parts.append(f"M {x + rtl:.2f} {y:.2f}")
        if rtl > 0:
            parts.append(corner_arc(x + rtl, y, x, y, x, y + rtl, k))
        parts.append(f"L {x:.2f} {y + h - rbl:.2f}")
        if rbl > 0:
            parts.append(corner_arc(x, y + h - rbl, x, y + h, x + rbl, y + h, k))
        parts.append(f"L {x + w - rbr:.2f} {y + h:.2f}")
        if rbr > 0:
            parts.append(corner_arc(x + w - rbr, y + h, x + w, y + h, x + w, y + h - rbr, k))
        parts.append(f"L {x + w:.2f} {y + rtr:.2f}")
        if rtr > 0:
            parts.append(corner_arc(x + w, y + rtr, x + w, y, x + w - rtr, y, k))
        parts.append("Z")
    return " ".join(parts)


# ── Custom Festo-Style Extended Geometric Font (100-unit Cap Height) ─────────
def build_glyphs() -> Dict[str, Tuple[float, str]]:
    g: Dict[str, Tuple[float, str]] = {}

    g["A"] = (
        122.0,
        "M 43 0 L 79 0 L 122 100 L 96 100 L 86.54 78 L 35.46 78 L 26 100 L 0 100 Z "
        "M 61 18.60 L 43.20 60 L 78.80 60 Z",
    )
    g["B"] = (
        120.0,
        " ".join([
            "M 0 0 L 92 0",
            corner_arc(92, 0, 115, 0, 115, 22),
            "L 115 29",
            corner_arc(115, 29, 115, 46, 103, 49),
            corner_arc(103, 49, 120, 52, 120, 71),
            "L 120 78",
            corner_arc(120, 78, 120, 100, 96, 100),
            "L 0 100 Z",
            super_rect(24, 18, 67, 23, 0, 6, 6, 0, ccw=True),
            super_rect(24, 59, 72, 23, 0, 6, 6, 0, ccw=True),
        ]),
    )
    g["C"] = (
        122.0,
        " ".join([
            "M 120 34 L 96 34 L 96 27",
            corner_arc(96, 27, 96, 20, 89, 20),
            "L 31 20",
            corner_arc(31, 20, 24, 20, 24, 27),
            "L 24 73",
            corner_arc(24, 73, 24, 80, 31, 80),
            "L 89 80",
            corner_arc(89, 80, 96, 80, 96, 73),
            "L 96 66 L 120 66 L 120 75",
            corner_arc(120, 75, 120, 100, 95, 100),
            "L 25 100",
            corner_arc(25, 100, 0, 100, 0, 75),
            "L 0 25",
            corner_arc(0, 25, 0, 0, 25, 0),
            "L 95 0",
            corner_arc(95, 0, 120, 0, 120, 25),
            "Z",
        ]),
    )
    g["D"] = (
        124.0,
        " ".join([
            super_rect(0, 0, 124, 100, 0, 25, 25, 0),
            super_rect(24, 20, 76, 60, 0, 7, 7, 0, ccw=True),
        ]),
    )
    g["E"] = (
        110.0,
        "M 0 0 L 110 0 L 110 20 L 24 20 L 24 40 L 92 40 L 92 60 L 24 60 L 24 80 L 110 80 L 110 100 L 0 100 Z",
    )
    g["F"] = (
        108.0,
        "M 0 0 L 108 0 L 108 20 L 24 20 L 24 40 L 90 40 L 90 60 L 24 60 L 24 100 L 0 100 Z",
    )
    g["G"] = (
        124.0,
        " ".join([
            "M 120 32 L 96 32 L 96 27",
            corner_arc(96, 27, 96, 20, 89, 20),
            "L 31 20",
            corner_arc(31, 20, 24, 20, 24, 27),
            "L 24 73",
            corner_arc(24, 73, 24, 80, 31, 80),
            "L 100 80 L 100 65 L 64 65 L 64 48 L 124 48 L 124 100 L 25 100",
            corner_arc(25, 100, 0, 100, 0, 75),
            "L 0 25",
            corner_arc(0, 25, 0, 0, 25, 0),
            "L 95 0",
            corner_arc(95, 0, 120, 0, 120, 25),
            "Z",
        ]),
    )
    g["H"] = (
        118.0,
        "M 0 0 L 24 0 L 24 40 L 94 40 L 94 0 L 118 0 L 118 100 L 94 100 L 94 60 L 24 60 L 24 100 L 0 100 Z",
    )
    g["I"] = (26.0, "M 0 0 L 26 0 L 26 100 L 0 100 Z")
    g["J"] = (
        102.0,
        " ".join([
            "M 78 0 L 102 0 L 102 75",
            corner_arc(102, 75, 102, 100, 77, 100),
            "L 25 100",
            corner_arc(25, 100, 0, 100, 0, 75),
            "L 0 62 L 24 62 L 24 73",
            corner_arc(24, 73, 24, 80, 31, 80),
            "L 71 80",
            corner_arc(71, 80, 78, 80, 78, 73),
            "Z",
        ]),
    )
    g["K"] = (
        118.0,
        "M 0 0 L 24 0 L 24 43 L 85 0 L 117 0 L 56 48 L 118 100 L 84 100 L 36 60 L 24 69 L 24 100 L 0 100 Z",
    )
    g["L"] = (104.0, "M 0 0 L 24 0 L 24 80 L 104 80 L 104 100 L 0 100 Z")
    g["M"] = (
        138.0,
        "M 0 0 L 34 0 L 69 62 L 104 0 L 138 0 L 138 100 L 114 100 L 114 34 L 79 92 L 59 92 L 24 34 L 24 100 L 0 100 Z",
    )
    g["N"] = (
        120.0,
        "M 0 0 L 33 0 L 96 73 L 96 0 L 120 0 L 120 100 L 87 100 L 24 27 L 24 100 L 0 100 Z",
    )
    g["O"] = (
        128.0,
        " ".join([
            super_rect(0, 0, 128, 100, 25, 25, 25, 25),
            super_rect(24, 20, 80, 60, 7, 7, 7, 7, ccw=True),
        ]),
    )
    g["P"] = (
        116.0,
        " ".join([
            "M 0 0 L 92 0",
            corner_arc(92, 0, 116, 0, 116, 24),
            "L 116 38",
            corner_arc(116, 38, 116, 62, 92, 62),
            "L 24 62 L 24 100 L 0 100 Z",
            super_rect(24, 19, 68, 24, 0, 6, 6, 0, ccw=True),
        ]),
    )
    g["Q"] = (
        128.0,
        " ".join([
            super_rect(0, 0, 128, 100, 25, 25, 25, 25),
            super_rect(24, 20, 80, 60, 7, 7, 7, 7, ccw=True),
            "M 76 70 L 100 70 L 128 106 L 104 106 Z",
        ]),
    )
    g["R"] = (
        120.0,
        " ".join([
            "M 0 0 L 94 0",
            corner_arc(94, 0, 118, 0, 118, 24),
            "L 118 34",
            corner_arc(118, 34, 118, 56, 95, 58),
            "L 120 100 L 91 100 L 66 58 L 24 58 L 24 100 L 0 100 Z",
            super_rect(24, 18, 70, 22, 0, 6, 6, 0, ccw=True),
        ]),
    )
    g["S"] = (
        122.0,
        " ".join([
            "M 118 0 L 118 20 L 31 20",
            corner_arc(31, 20, 24, 20, 24, 27),
            "L 24 33",
            corner_arc(24, 33, 24, 40, 31, 40),
            "L 97 40",
            corner_arc(97, 40, 122, 40, 122, 65),
            "L 122 75",
            corner_arc(122, 75, 122, 100, 97, 100),
            "L 4 100 L 4 80 L 91 80",
            corner_arc(91, 80, 98, 80, 98, 73),
            "L 98 67",
            corner_arc(98, 67, 98, 60, 91, 60),
            "L 25 60",
            corner_arc(25, 60, 0, 60, 0, 35),
            "L 0 25",
            corner_arc(0, 25, 0, 0, 25, 0),
            "Z",
        ]),
    )
    g["T"] = (116.0, "M 0 0 L 116 0 L 116 20 L 70 20 L 70 100 L 46 100 L 46 20 L 0 20 Z")
    g["U"] = (
        120.0,
        " ".join([
            "M 0 0 L 24 0 L 24 73",
            corner_arc(24, 73, 24, 80, 31, 80),
            "L 89 80",
            corner_arc(89, 80, 96, 80, 96, 73),
            "L 96 0 L 120 0 L 120 75",
            corner_arc(120, 75, 120, 100, 95, 100),
            "L 25 100",
            corner_arc(25, 100, 0, 100, 0, 75),
            "Z",
        ]),
    )
    g["V"] = (122.0, "M 0 0 L 27 0 L 61 79 L 95 0 L 122 0 L 76 100 L 46 100 Z")
    g["W"] = (
        154.0,
        "M 0 0 L 26 0 L 45 74 L 66 12 L 88 12 L 109 74 L 128 0 L 154 0 L 124 100 L 98 100 L 77 38 L 56 100 L 30 100 Z",
    )
    g["X"] = (
        120.0,
        "M 0 0 L 32 0 L 60 35 L 88 0 L 120 0 L 76 50 L 120 100 L 88 100 L 60 65 L 32 100 L 0 100 L 44 50 Z",
    )
    g["Y"] = (118.0, "M 0 0 L 30 0 L 59 40 L 88 0 L 118 0 L 71 56 L 71 100 L 47 100 L 47 56 Z")
    g["Z"] = (116.0, "M 0 0 L 116 0 L 116 20 L 34 80 L 116 80 L 116 100 L 0 100 L 0 80 L 82 20 L 0 20 Z")

    # Digits 0-9
    g["0"] = (
        120.0,
        " ".join([
            super_rect(0, 0, 120, 100, 25, 25, 25, 25),
            super_rect(24, 20, 72, 60, 7, 7, 7, 7, ccw=True),
        ]),
    )
    g["1"] = (78.0, "M 14 0 L 62 0 L 62 100 L 38 100 L 38 20 L 14 20 Z")
    g["2"] = (
        116.0,
        " ".join([
            "M 0 25",
            corner_arc(0, 25, 0, 0, 25, 0),
            "L 91 0",
            corner_arc(91, 0, 116, 0, 116, 25),
            "L 116 37",
            corner_arc(116, 37, 116, 60, 93, 60),
            "L 31 60",
            corner_arc(31, 60, 24, 60, 24, 67),
            "L 24 80 L 116 80 L 116 100 L 0 100 L 0 65",
            corner_arc(0, 65, 0, 40, 25, 40),
            "L 85 40",
            corner_arc(85, 40, 92, 40, 92, 33),
            "L 92 27",
            corner_arc(92, 27, 92, 20, 85, 20),
            "L 24 20 L 24 30 L 0 30 Z",
        ]),
    )
    g["3"] = (
        116.0,
        " ".join([
            "M 4 0 L 91 0",
            corner_arc(91, 0, 116, 0, 116, 25),
            "L 116 31",
            corner_arc(116, 31, 116, 48, 98, 50),
            corner_arc(98, 50, 116, 52, 116, 69),
            "L 116 75",
            corner_arc(116, 75, 116, 100, 91, 100),
            "L 4 100 L 4 80 L 85 80",
            corner_arc(85, 80, 92, 80, 92, 73),
            "L 92 67",
            corner_arc(92, 67, 92, 60, 85, 60),
            "L 38 60 L 38 40 L 85 40",
            corner_arc(85, 40, 92, 40, 92, 33),
            "L 92 27",
            corner_arc(92, 27, 92, 20, 85, 20),
            "L 4 20 Z",
        ]),
    )
    g["4"] = (
        120.0,
        "M 62 0 L 102 0 L 102 60 L 120 60 L 120 80 L 102 80 L 102 100 L 78 100 L 78 80 L 0 80 L 0 60 Z "
        "M 78 18 L 32 60 L 78 60 Z",
    )
    g["5"] = (
        116.0,
        " ".join([
            "M 0 0 L 112 0 L 112 20 L 24 20 L 24 40 L 91 40",
            corner_arc(91, 40, 116, 40, 116, 65),
            "L 116 75",
            corner_arc(116, 75, 116, 100, 91, 100),
            "L 4 100 L 4 80 L 85 80",
            corner_arc(85, 80, 92, 80, 92, 73),
            "L 92 67",
            corner_arc(92, 67, 92, 60, 85, 60),
            "L 0 60 Z",
        ]),
    )
    g["6"] = (
        118.0,
        " ".join([
            "M 25 0 L 112 0 L 112 20 L 31 20",
            corner_arc(31, 20, 24, 20, 24, 27),
            "L 24 40 L 93 40",
            corner_arc(93, 40, 118, 40, 118, 65),
            "L 118 75",
            corner_arc(118, 75, 118, 100, 93, 100),
            "L 25 100",
            corner_arc(25, 100, 0, 100, 0, 75),
            "L 0 25",
            corner_arc(0, 25, 0, 0, 25, 0),
            "Z",
            super_rect(24, 60, 70, 20, 0, 7, 7, 0, ccw=True),
        ]),
    )
    g["7"] = (114.0, "M 0 0 L 114 0 L 114 20 L 48 100 L 18 100 L 84 20 L 0 20 Z")
    g["8"] = (
        118.0,
        " ".join([
            "M 25 0 L 93 0",
            corner_arc(93, 0, 118, 0, 118, 25),
            "L 118 31",
            corner_arc(118, 31, 118, 46, 104, 49),
            corner_arc(104, 49, 118, 52, 118, 69),
            "L 118 75",
            corner_arc(118, 75, 118, 100, 93, 100),
            "L 25 100",
            corner_arc(25, 100, 0, 100, 0, 75),
            "L 0 69",
            corner_arc(0, 69, 0, 52, 14, 49),
            corner_arc(14, 49, 0, 46, 0, 31),
            "L 0 25",
            corner_arc(0, 25, 0, 0, 25, 0),
            "Z",
            super_rect(24, 18, 70, 23, 6, 6, 6, 6, ccw=True),
            super_rect(24, 59, 70, 23, 6, 6, 6, 6, ccw=True),
        ]),
    )
    g["9"] = (
        118.0,
        " ".join([
            "M 25 0 L 93 0",
            corner_arc(93, 0, 118, 0, 118, 25),
            "L 118 75",
            corner_arc(118, 75, 118, 100, 93, 100),
            "L 6 100 L 6 80 L 87 80",
            corner_arc(87, 80, 94, 80, 94, 73),
            "L 94 60 L 25 60",
            corner_arc(25, 60, 0, 60, 0, 35),
            "L 0 25",
            corner_arc(0, 25, 0, 0, 25, 0),
            "Z",
            super_rect(24, 20, 70, 20, 7, 0, 0, 7, ccw=True),
        ]),
    )

    # Punctuation
    g["-"] = (68.0, "M 0 40 L 68 40 L 68 60 L 0 60 Z")
    g["_"] = (78.0, "M 0 82 L 78 82 L 78 100 L 0 100 Z")
    g["."] = (26.0, "M 0 76 L 26 76 L 26 100 L 0 100 Z")
    g[" "] = (52.0, "")
    return g


GLYPHS = build_glyphs()


# ── Layout Helper ────────────────────────────────────────────────────────────
def compute_layout(
    text: str,
    tracking: float = TRACKING,
    base_h: int = DEFAULT_BASE_H,
    cap_px: float = DEFAULT_CAP_PX,
    pad_x: float = DEFAULT_PAD_X_PX,
    target_w: Optional[int] = None,
    target_h: Optional[int] = None,
    fit_height: bool = False,
) -> Tuple[str, int, int, float, float, float, List[Tuple[float, str]]]:
    text_upper = text.upper()
    unsupported = [ch for ch in text_upper if ch not in GLYPHS]
    if unsupported:
        raise ValueError(f"Unsupported character(s): {''.join(sorted(set(unsupported)))}")

    cursor_x = 0.0
    placed: List[Tuple[float, str]] = []
    for idx, ch in enumerate(text_upper):
        adv_w, d = GLYPHS[ch]
        if d:
            placed.append((cursor_x, d))
        cursor_x += adv_w
        if idx < len(text_upper) - 1:
            cursor_x += tracking

    if fit_height and target_h is not None:
        base_h = max(1, target_h)
        cap_used = max(1, round(base_h * 0.84))
        scale = cap_used / CAP_UNITS
        text_w_px = cursor_x * scale
        pad_x_px = max(2.0, base_h * 0.14)
        base_w = max(1, round(text_w_px + 2.0 * pad_x_px))
        offset_x = (base_w - text_w_px) / 2.0
        offset_y = float((base_h - cap_used) // 2)
    elif target_w is not None and target_h is not None:
        base_w = max(1, target_w)
        base_h = max(1, target_h)
        avail_w = max(1.0, base_w * 0.94)
        avail_h = max(1.0, base_h * 0.84)
        scale = min(avail_w / max(1.0, cursor_x), avail_h / CAP_UNITS)
        cap_used = scale * CAP_UNITS
        text_w_px = cursor_x * scale
        offset_x = (base_w - text_w_px) / 2.0
        offset_y = (base_h - cap_used) / 2.0
    else:
        scale = cap_px / CAP_UNITS
        text_w_px = cursor_x * scale
        base_w = max(1, round(text_w_px + 2 * pad_x))
        offset_x = (base_w - text_w_px) / 2.0
        offset_y = (base_h - cap_px) / 2.0

    return text_upper, base_w, base_h, offset_x, offset_y, scale, placed


def build_svg(
    text: str,
    color: str = FESTO_BLUE,
    bg: str = "white",
    target_w: Optional[int] = None,
    target_h: Optional[int] = None,
    fit_height: bool = False,
) -> Tuple[str, int, int]:
    _, base_w, base_h, offset_x, offset_y, scale, placed = compute_layout(
        text, target_w=target_w, target_h=target_h, fit_height=fit_height
    )

    path_elements = [
        f'    <path d="{d}" transform="translate({gx:.2f},0)" '
        f'fill="{color}" fill-rule="nonzero"/>'
        for gx, d in placed
    ]
    bg_rect = "" if bg.lower() == "transparent" else f'  <rect width="{base_w}" height="{base_h}" fill="{bg}"/>\n'
    paths_block = "\n".join(path_elements)

    svg = (
        f'<svg xmlns="http://www.w3.org/2000/svg"\n'
        f'     viewBox="0 0 {base_w} {base_h}"\n'
        f'     width="{base_w}" height="{base_h}">\n'
        f'{bg_rect}'
        f'  <g transform="translate({offset_x:.2f},{offset_y:.2f}) scale({scale:.6f})">\n'
        f'{paths_block}\n'
        f'  </g>\n'
        f'</svg>\n'
    )
    return svg, base_w, base_h


# ── Pure-Python Pillow Vector Rasterizer (8x BOX Supersampling) ──────────────
def parse_svg_path(d: str, bezier_steps: int = 24) -> List[List[Tuple[float, float]]]:
    tokens = re.findall(r"[MLCZmlcz]|[-+]?(?:\d*\.\d+|\d+)", d)
    subpaths: List[List[Tuple[float, float]]] = []
    pts: List[Tuple[float, float]] = []
    cur = (0.0, 0.0)
    cmd = ""
    i = 0

    while i < len(tokens):
        tok = tokens[i]
        if tok in ("M", "L", "C", "Z", "m", "l", "c", "z"):
            cmd = tok.upper()
            i += 1
            if cmd == "Z":
                if pts:
                    subpaths.append(pts)
                    pts = []
                continue
        if cmd == "M":
            if pts:
                subpaths.append(pts)
                pts = []
            x, y = float(tokens[i]), float(tokens[i + 1])
            i += 2
            cur = (x, y)
            pts.append(cur)
            cmd = "L"
        elif cmd == "L":
            x, y = float(tokens[i]), float(tokens[i + 1])
            i += 2
            cur = (x, y)
            pts.append(cur)
        elif cmd == "C":
            x1, y1 = float(tokens[i]), float(tokens[i + 1])
            x2, y2 = float(tokens[i + 2]), float(tokens[i + 3])
            x3, y3 = float(tokens[i + 4]), float(tokens[i + 5])
            i += 6
            x0, y0 = cur
            for s in range(1, bezier_steps + 1):
                t = s / bezier_steps
                u = 1.0 - t
                px = u**3 * x0 + 3 * u**2 * t * x1 + 3 * u * t**2 * x2 + t**3 * x3
                py = u**3 * y0 + 3 * u**2 * t * y1 + 3 * u * t**2 * y2 + t**3 * y3
                pts.append((px, py))
            cur = (x3, y3)
        else:
            i += 1

    if pts:
        subpaths.append(pts)
    return subpaths


def signed_area(pts: List[Tuple[float, float]]) -> float:
    n = len(pts)
    if n < 3:
        return 0.0
    return 0.5 * sum(
        pts[i][0] * pts[(i + 1) % n][1] - pts[(i + 1) % n][0] * pts[i][1]
        for i in range(n)
    )


def render_png_pillow(
    text: str,
    color: str,
    bg: str,
    scale: int,
    out_path: str,
    flatten_rgb: bool,
    target_w: Optional[int] = None,
    target_h: Optional[int] = None,
    fit_height: bool = False,
    supersample: int = 8,
) -> None:
    from PIL import Image, ImageColor, ImageDraw

    _, base_w, base_h, offset_x, offset_y, cap_scale, placed = compute_layout(
        text, target_w=target_w, target_h=target_h, fit_height=fit_height
    )
    out_w = base_w * scale
    out_h = base_h * scale
    hi_w = out_w * supersample
    hi_h = out_h * supersample

    mask = Image.new("L", (hi_w, hi_h), 0)
    draw = ImageDraw.Draw(mask)

    for gx, d in placed:
        for sub in parse_svg_path(d):
            if len(sub) < 3:
                continue
            hi_pts = [
                (
                    (offset_x + (gx + x) * cap_scale) * scale * supersample,
                    (offset_y + y * cap_scale) * scale * supersample,
                )
                for x, y in sub
            ]
            fill_val = 255 if signed_area(sub) >= 0 else 0
            draw.polygon(hi_pts, fill=fill_val)

    resample_cls = getattr(Image, "Resampling", Image)
    aa_mask = mask.resize((out_w, out_h), resample=resample_cls.BOX)

    fg_rgb = ImageColor.getrgb(color)[:3]

    if bg.lower() == "transparent":
        r_band = Image.new("L", (out_w, out_h), fg_rgb[0])
        g_band = Image.new("L", (out_w, out_h), fg_rgb[1])
        b_band = Image.new("L", (out_w, out_h), fg_rgb[2])
        out = Image.merge("RGBA", (r_band, g_band, b_band, aa_mask))
        out.save(out_path, format="PNG")
    else:
        bg_rgb = ImageColor.getrgb(bg)[:3]
        mode = "RGB" if flatten_rgb else "RGBA"
        bg_color = bg_rgb if flatten_rgb else (*bg_rgb, 255)
        out = Image.new(mode, (out_w, out_h), bg_color)
        out.paste(fg_rgb, (0, 0), aa_mask)
        out.save(out_path, format="PNG")


def export_png(
    svg_source: str,
    text: str,
    color: str,
    bg: str,
    out_path: str,
    scale: int,
    flatten_rgb: bool,
    target_w: Optional[int] = None,
    target_h: Optional[int] = None,
    fit_height: bool = False,
) -> str:
    try:
        import cairosvg
        png_bytes = cairosvg.svg2png(bytestring=svg_source.encode("utf-8"), scale=scale)
        if flatten_rgb:
            try:
                from PIL import Image
                img = Image.open(io.BytesIO(png_bytes))
                if img.mode == "RGBA":
                    bg_img = Image.new("RGB", img.size, (255, 255, 255))
                    bg_img.paste(img, mask=img.split()[3])
                    bg_img.save(out_path, format="PNG")
                    return "cairosvg+pil"
            except ImportError:
                pass
        with open(out_path, "wb") as f:
            f.write(png_bytes)
        return "cairosvg"
    except (ImportError, OSError):
        pass

    try:
        render_png_pillow(
            text=text,
            color=color,
            bg=bg,
            scale=scale,
            out_path=out_path,
            flatten_rgb=flatten_rgb,
            target_w=target_w,
            target_h=target_h,
            fit_height=fit_height,
        )
        return "pillow-8x-box"
    except ImportError:
        print("Error: install Pillow (pip install pillow) to export PNGs.")
        sys.exit(1)


def inspect_existing_png(path: str) -> Tuple[Optional[int], Optional[int], Optional[str], bool]:
    if not os.path.isfile(path):
        return None, None, None, False
    try:
        from PIL import Image
        with Image.open(path) as img:
            has_alpha = img.mode in ("RGBA", "LA") or ("transparency" in img.info)
            return img.width, img.height, img.mode, has_alpha
    except Exception:
        return None, None, None, False


def load_reference(
    ref_json: str, backup: str, primary: str
) -> Tuple[Optional[int], Optional[int], Optional[str], bool]:
    if os.path.isfile(ref_json):
        try:
            with open(ref_json, "r", encoding="utf-8") as f:
                d = json.load(f)
            return int(d["w"]), int(d["h"]), d.get("mode"), bool(d.get("alpha"))
        except (OSError, ValueError, KeyError, TypeError):
            pass
    for p in (backup, primary):
        w, h, m, a = inspect_existing_png(p)
        if w and h:
            return w, h, m, a
    return None, None, None, False


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Generate custom Festo-style SVG & crisp PNG logo."
    )
    parser.add_argument(
        "--text", default="BONDHON",
        help="Wordmark text to render (default: BONDHON; try FESTO)",
    )
    parser.add_argument(
        "--color", default=FESTO_BLUE,
        help=f"Fill hex color (default: {FESTO_BLUE}; Bondhon ref: {BONDHON_BLUE})",
    )
    parser.add_argument(
        "--bg", default="auto",
        help="Background color, 'transparent', or 'auto' (default: auto)",
    )
    parser.add_argument(
        "--out", default=DEFAULT_OUT_DIR, metavar="DIR",
        help=f"Output directory (default: {DEFAULT_OUT_DIR})",
    )
    parser.add_argument(
        "--name", default=DEFAULT_OUT_NAME,
        help=f"Output PNG filename (default: {DEFAULT_OUT_NAME})",
    )
    parser.add_argument(
        "--scale", type=int, default=1, metavar="N",
        help="Resolution multiplier applied directly to output PNG (try --scale 4 for sharp zoom)",
    )
    parser.add_argument(
        "--ref", default=None, metavar="WxH",
        help="Pin the canvas size explicitly, e.g. --ref 332x60 (overrides matching)",
    )
    parser.add_argument(
        "--fit-height", action="store_true",
        help="Match original height only and expand width so long text stays tall & sharp",
    )
    parser.add_argument(
        "--no-match", action="store_true",
        help="Ignore existing PNG dimensions and use 332x60 default canvas",
    )
    parser.add_argument(
        "--no-svg", action="store_true",
        help="Skip saving the .svg file",
    )
    parser.add_argument(
        "--rgb24", action="store_true",
        help="Force 24-bit RGB PNG when background is opaque",
    )
    args = parser.parse_args()

    if args.scale < 1:
        parser.error("--scale must be >= 1")

    stem = os.path.splitext(args.name)[0]
    primary_png = os.path.join(args.out, f"{stem}.png")
    backup_path = os.path.join(args.out, f"{stem}_backup.png")
    ref_json = os.path.join(args.out, f"{stem}_ref.json")

    target_w: Optional[int] = None
    target_h: Optional[int] = None
    bg = args.bg
    flatten_rgb = args.rgb24

    if args.ref:
        parts = args.ref.lower().split("x", 1)
        if len(parts) != 2:
            parser.error("--ref must be in WxH format, e.g. 332x60")
        try:
            rw, rh = int(parts[0]), int(parts[1])
        except ValueError:
            parser.error("--ref must be in WxH format, e.g. 332x60")
        if rw < 1 or rh < 1:
            parser.error("--ref dimensions must be positive integers")
        target_w, target_h = rw, rh
        print(f"  Reference pinned -> {rw}x{rh} px")
    elif not args.no_match:
        ew, eh, emode, has_alpha = load_reference(ref_json, backup_path, primary_png)
        if ew and eh:
            target_w, target_h = ew, eh
            print(f"  Matched reference -> {ew}x{eh} px (mode: {emode})")
            if bg == "auto":
                bg = "transparent" if has_alpha else "white"
            if emode == "RGB" and bg.lower() != "transparent":
                flatten_rgb = True
            if not os.path.exists(ref_json):
                os.makedirs(args.out, exist_ok=True)
                if os.path.isfile(primary_png) and not os.path.exists(backup_path):
                    shutil.copy2(primary_png, backup_path)
                    print("  Backup saved.")
                with open(ref_json, "w", encoding="utf-8") as f:
                    json.dump({"w": ew, "h": eh, "mode": emode, "alpha": has_alpha}, f)

    if bg == "auto":
        bg = "white"

    try:
        os.makedirs(args.out, exist_ok=True)
        svg_source, base_w, base_h = build_svg(
            text=args.text,
            color=args.color,
            bg=bg,
            target_w=target_w,
            target_h=target_h,
            fit_height=args.fit_height,
        )

        flatten_rgb = flatten_rgb and bg.lower() != "transparent"

        if not args.no_match and not args.ref and not os.path.exists(ref_json):
            ref_alpha = bg.lower() == "transparent"
            ref_mode = "RGB" if (flatten_rgb and not ref_alpha) else "RGBA"
            with open(ref_json, "w", encoding="utf-8") as f:
                json.dump({"w": base_w, "h": base_h, "mode": ref_mode, "alpha": ref_alpha}, f)

        if not args.no_svg:
            svg_path = os.path.join(args.out, f"{stem}.svg")
            with open(svg_path, "w", encoding="utf-8") as f:
                f.write(svg_source)
            print("  SVG saved.")

        backend_used = export_png(
            svg_source=svg_source,
            text=args.text,
            color=args.color,
            bg=bg,
            out_path=primary_png,
            scale=args.scale,
            flatten_rgb=flatten_rgb,
            target_w=target_w,
            target_h=target_h,
            fit_height=args.fit_height,
        )
        print(f"  PNG ({args.scale}x)         ({base_w*args.scale}x{base_h*args.scale} px) saved.")
        print(f"Done (renderer: {backend_used}).")

    except PermissionError:
        print("\nPermission denied writing to output directory.")
        print("Fix: Right-click Command Prompt / PowerShell -> 'Run as administrator', then re-run.")
        sys.exit(1)


if __name__ == "__main__":
    main()