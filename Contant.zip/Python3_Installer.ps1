<#
.SYNOPSIS
    Standalone offline installer for Python 3 + optional local Pillow wheel.
.DESCRIPTION
    Zero external dependencies. Self-elevates if needed, stages the bundled
    python-*.exe to %TEMP% for network/UNC safety, installs silently for all
    users with pip and PATH enabled, then installs pillow-*.whl offline when a
    wheel is present in wheels\ or beside this script. Enables Developer Mode
    at the end so locally signed payloads are not blocked.
.PARAMETER Force
    Reinstall Python and Pillow even if a matching install already exists.
.PARAMETER SkipPillow
    Install Python only.
#>
[CmdletBinding()]
param(
    [switch]$Force,
    [switch]$SkipPillow
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ===========================================================================
#  1. Self-Elevate as Administrator
# ===========================================================================
$identity  = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal $identity

if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    $argList = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"")
    if ($Force)      { $argList += '-Force' }
    if ($SkipPillow) { $argList += '-SkipPillow' }

    Write-Host 'Requesting administrator privileges...' -ForegroundColor Yellow
    try {
        $p = Start-Process -FilePath 'powershell.exe' -ArgumentList $argList -Verb RunAs -Wait -PassThru -ErrorAction Stop
        exit $(if ($p) { $p.ExitCode } else { 1 })
    } catch {
        Write-Host 'Administrator elevation was declined or failed.' -ForegroundColor Red
        exit 1
    }
}

# ===========================================================================
#  2. Paths & Writable Log Setup
# ===========================================================================
$ScriptDir = if ($PSScriptRoot -and $PSScriptRoot -ne '') {
    $PSScriptRoot
} else {
    Split-Path -Parent $MyInvocation.MyCommand.Definition
}

$LogFile = Join-Path $ScriptDir 'Python3_Install.log'
try {
    Set-Content -LiteralPath $LogFile -Value '' -Encoding UTF8 -ErrorAction Stop
} catch {
    $fallbackDir = Join-Path $env:ProgramData 'VU-EEE\logs'
    try {
        New-Item -Path $fallbackDir -ItemType Directory -Force -ErrorAction Stop | Out-Null
        $LogFile = Join-Path $fallbackDir 'Python3_Install.log'
        Set-Content -LiteralPath $LogFile -Value '' -Encoding UTF8 -ErrorAction Stop
    } catch {
        $LogFile = Join-Path $env:TEMP 'Python3_Install.log'
        Set-Content -LiteralPath $LogFile -Value '' -Encoding UTF8 -ErrorAction SilentlyContinue
    }
}

function Write-Log {
    param(
        [Parameter(Mandatory)][string]$Message,
        [ValidateSet('INFO','WARN','ERROR','STEP','RESULT')][string]$Level = 'INFO'
    )
    $ts   = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $line = "[$ts][$Level] $Message"

    if ($LogFile) {
        try { Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8 -ErrorAction SilentlyContinue } catch { }
    }

    switch ($Level) {
        'STEP'   { Write-Host "`n$Message" -ForegroundColor Yellow }
        'RESULT' { Write-Host "   $Message" -ForegroundColor Green }
        'WARN'   { Write-Host "   WARN: $Message" -ForegroundColor Yellow }
        'ERROR'  { Write-Host "`n   ERROR: $Message" -ForegroundColor Red }
        default  { Write-Host "   $Message" -ForegroundColor Gray }
    }
}

function Test-Python {
    param(
        [Parameter(Mandatory)][string]$PyExe,
        [Parameter(Mandatory)][string]$Code
    )
    $prev = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        & $PyExe -c $Code 2>&1 | Out-Null
        return ($LASTEXITCODE -eq 0)
    } catch {
        return $false
    } finally {
        $ErrorActionPreference = $prev
    }
}

function Get-PythonVersionString {
    param([Parameter(Mandatory)][string]$PyExe)
    $prev = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        $v = & $PyExe -c "import sys; print('%d.%d.%d' % sys.version_info[:3])" 2>$null
        if ($LASTEXITCODE -eq 0 -and $v) { return ($v | Select-Object -First 1).ToString().Trim() }
    } catch { }
    finally { $ErrorActionPreference = $prev }
    return 'unknown'
}

function Find-InstalledPython {
    param([string]$RequiredMajorMinor = '')

    $fromPath = Get-Command python.exe -CommandType Application -ErrorAction SilentlyContinue |
                Where-Object { $_.Source -notlike '*\Microsoft\WindowsApps\*' } |
                Select-Object -First 1 -ExpandProperty Source

    $pfDirs = @()
    if (Test-Path -LiteralPath 'C:\Program Files') {
        $pfDirs = @(Get-ChildItem -LiteralPath 'C:\Program Files' -Directory -Filter 'Python*' -ErrorAction SilentlyContinue |
                    Sort-Object Name -Descending |
                    ForEach-Object { Join-Path $_.FullName 'python.exe' })
    }

    $cands = @($pfDirs + @($fromPath)) | Where-Object { $_ } | Select-Object -Unique

    if ($RequiredMajorMinor) {
        $parts = $RequiredMajorMinor.Split('.')
        $check = "import sys, struct; assert sys.version_info[:2] == ($($parts[0]), $($parts[1])) and struct.calcsize('P')*8 == 64"
        foreach ($c in $cands) {
            if ((Test-Path -LiteralPath $c) -and (Test-Python -PyExe $c -Code $check)) {
                return $c
            }
        }
        return $null
    }

    foreach ($c in $cands) {
        if ((Test-Path -LiteralPath $c) -and (Test-Python -PyExe $c -Code 'import sys; assert sys.version_info[0] == 3')) {
            return $c
        }
    }
    return $null
}

# ===========================================================================
#  3. Discover Bundled Installer & Optional Pillow Wheel
# ===========================================================================
if (-not [Environment]::Is64BitOperatingSystem) {
    Write-Log '32-bit Windows detected; the bundled x64 installer will not run.' 'ERROR'
    exit 1
}

# Prefer the arch/version-qualified name, fall back to any python*.exe.
$Installer = @(Get-ChildItem -LiteralPath $ScriptDir -File -ErrorAction SilentlyContinue |
               Where-Object { $_.Name -imatch '^python-\d.*(amd64|x86_64).*\.exe$' -and $_.Length -gt 0 } |
               Sort-Object LastWriteTime -Descending) | Select-Object -First 1

if (-not $Installer) {
    $Installer = @(Get-ChildItem -LiteralPath $ScriptDir -File -ErrorAction SilentlyContinue |
                   Where-Object { $_.Name -imatch '^python.*\.exe$' -and $_.Length -gt 0 } |
                   Sort-Object LastWriteTime -Descending) | Select-Object -First 1
}

if (-not $Installer) {
    Write-Log "No python*.exe installer found in '$ScriptDir'." 'ERROR'
    exit 1
}

$WheelDirs = @((Join-Path $ScriptDir 'wheels'), $ScriptDir) | Where-Object { Test-Path -LiteralPath $_ }
$WheelDirs = @($WheelDirs)
$Wheel = $null
foreach ($wd in $WheelDirs) {
    $Wheel = Get-ChildItem -LiteralPath $wd -Filter 'pillow-*.whl' -File -ErrorAction SilentlyContinue |
             Where-Object { $_.Length -gt 0 } |
             Sort-Object LastWriteTime -Descending |
             Select-Object -First 1
    if ($Wheel) { break }
}

$RequiredPyVer = ''
if ($Installer.Name -match 'python-(\d+\.\d+)') {
    $RequiredPyVer = $Matches[1]
} elseif ($Wheel -and $Wheel.Name -match '-cp(\d)(\d+)-') {
    $RequiredPyVer = "$($Matches[1]).$($Matches[2])"
}

$DoPillow = (-not $SkipPillow) -and [bool]$Wheel
$TotalSteps = if ($DoPillow) { 3 } else { 2 }

Write-Host ''
Write-Host '====================================================' -ForegroundColor Cyan
Write-Host '  Python 3 Offline Installer' -ForegroundColor Cyan
Write-Host '====================================================' -ForegroundColor Cyan
Write-Host "  Script dir : $ScriptDir"
Write-Host ("  Installer  : {0} ({1:N2} MB)" -f $Installer.Name, ($Installer.Length / 1MB))
if ($Wheel) {
    Write-Host ("  Pillow whl : {0} ({1:N2} MB)" -f $Wheel.Name, ($Wheel.Length / 1MB))
    if ($Wheel.Name -notmatch 'win_amd64') {
        Write-Host '  WARN: wheel tag is not win_amd64 - Pill